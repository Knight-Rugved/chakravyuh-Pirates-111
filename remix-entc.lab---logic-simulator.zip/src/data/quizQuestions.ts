import { QuizGameQuestion } from '../types';

export const EASY_QUIZ_POOL: QuizGameQuestion[] = [
  {
    id: 'ez_1',
    question: 'Which logic gate outputs 1 only when ALL of its inputs are 1?',
    options: ['AND Gate', 'OR Gate', 'XOR Gate', 'NOR Gate'],
    correctIndex: 0,
    difficulty: 'easy',
    category: 'Basic Gates',
    explanation: 'An AND gate is a conjunction gate requiring every single input to be 1 to produce an active 1 output.'
  },
  {
    id: 'ez_2',
    question: 'What is the output of an inverter (NOT gate) when the input is 0?',
    options: ['0', '1', 'High-Z', 'Indeterminate'],
    correctIndex: 1,
    difficulty: 'easy',
    category: 'Basic Gates',
    explanation: 'A NOT gate inverts binary 0 into binary 1.'
  },
  {
    id: 'ez_3',
    question: 'Which gate outputs 1 when AT LEAST ONE input is 1?',
    options: ['AND Gate', 'NAND Gate', 'OR Gate', 'XNOR Gate'],
    correctIndex: 2,
    difficulty: 'easy',
    category: 'Basic Gates',
    explanation: 'The OR gate performs disjunction: 0 + 1 = 1, 1 + 0 = 1, 1 + 1 = 1.'
  },
  {
    id: 'ez_4',
    question: 'What is the binary sum of 1 + 0 in digital logic?',
    options: ['0', '1', '10', '11'],
    correctIndex: 1,
    difficulty: 'easy',
    category: 'Binary Math',
    explanation: '1 + 0 = 1 with zero carry.'
  },
  {
    id: 'ez_5',
    question: 'Which two gates are known as "Universal Gates"?',
    options: ['AND & OR', 'NAND & NOR', 'XOR & XNOR', 'NOT & BUFFER'],
    correctIndex: 1,
    difficulty: 'easy',
    category: 'Universal Gates',
    explanation: 'Both NAND and NOR are functionally complete and can implement any Boolean function by themselves.'
  },
  {
    id: 'ez_6',
    question: 'What is the output of a 2-input XOR gate when inputs are A = 1 and B = 1?',
    options: ['1', '0', '2', 'High-Z'],
    correctIndex: 1,
    difficulty: 'easy',
    category: 'Special Gates',
    explanation: 'XOR outputs 1 for DIFFERENT inputs. For identical inputs (1 and 1), the XOR output is 0.'
  },
  {
    id: 'ez_7',
    question: 'What is the standard TTL chip number for Quad 2-input NAND gates?',
    options: ['7400', '7408', '7432', '7486'],
    correctIndex: 0,
    difficulty: 'easy',
    category: 'TTL ICs',
    explanation: '7400 is the industry standard Quad 2-input NAND IC.'
  },
  {
    id: 'ez_8',
    question: 'In a 2-to-1 Multiplexer, how many select lines are present?',
    options: ['1 select line', '2 select lines', '4 select lines', '8 select lines'],
    correctIndex: 0,
    difficulty: 'easy',
    category: 'Multiplexers',
    explanation: '2^1 = 2 inputs, so exactly 1 select line controls which of the 2 inputs is chosen.'
  },
  {
    id: 'ez_9',
    question: 'What is the value of Boolean identity: A · 0?',
    options: ['A', '1', '0', '~A'],
    correctIndex: 2,
    difficulty: 'easy',
    category: 'Boolean Laws',
    explanation: 'Anything ANDed with 0 is always 0 (Null element of AND).'
  },
  {
    id: 'ez_10',
    question: 'What is the value of Boolean identity: A + 1?',
    options: ['A', '1', '0', '~A'],
    correctIndex: 1,
    difficulty: 'easy',
    category: 'Boolean Laws',
    explanation: 'Anything ORed with 1 is always 1 (Dominance law of OR).'
  },
  {
    id: 'ez_11',
    question: 'A Half Adder has two outputs. What are their names?',
    options: ['Sum and Carry', 'Quotient and Remainder', 'High and Low', 'Input and Output'],
    correctIndex: 0,
    difficulty: 'easy',
    category: 'Adders',
    explanation: 'A Half Adder produces a Sum bit (A ⊕ B) and a Carry bit (A · B).'
  },
  {
    id: 'ez_12',
    question: 'In digital electronics, what logic voltage usually represents binary 1 in 5V TTL?',
    options: ['0 Volts', '5 Volts (HIGH)', '-5 Volts', '12 Volts'],
    correctIndex: 1,
    difficulty: 'easy',
    category: 'Electrical',
    explanation: 'Standard 5V TTL considers 2.4V to 5.0V as logic HIGH (1).'
  }
];

export const HARD_QUIZ_POOL: QuizGameQuestion[] = [
  {
    id: 'hd_1',
    question: 'According to De Morgan\'s Law, the dual expression for ~(A · B · C) is:',
    options: ['~A · ~B · ~C', '~A + ~B + ~C', '~(A + B + C)', 'A + B + C'],
    correctIndex: 1,
    difficulty: 'hard',
    category: 'Boolean Theorems',
    explanation: 'De Morgan: Complement of product is sum of individual complements: ~(A·B·C) = ~A + ~B + ~C.'
  },
  {
    id: 'hd_2',
    question: 'In a 1-bit Full Adder with A = 1, B = 0, C_in = 1, what are the values of (Sum, C_out)?',
    options: ['(0, 1)', '(1, 0)', '(1, 1)', '(0, 0)'],
    correctIndex: 0,
    difficulty: 'hard',
    category: 'Computer Arithmetic',
    explanation: '1 + 0 + 1 = 2 (binary 10). Sum = 1 ⊕ 0 ⊕ 1 = 0, and C_out = (1·0 + 0·1 + 1·1) = 1.'
  },
  {
    id: 'hd_3',
    question: 'Simplify the Boolean equation: Y = A · B + A · ~B + ~A · B',
    options: ['A + B', 'A · B', '~(A · B)', 'A ⊕ B'],
    correctIndex: 0,
    difficulty: 'hard',
    category: 'Minimization',
    explanation: 'A·B + A·~B = A(B + ~B) = A. Then A + ~A·B = (A + ~A)(A + B) = 1 · (A + B) = A + B.'
  },
  {
    id: 'hd_4',
    question: 'What is the minimum number of 2-input NAND gates required to build a 2-input XOR gate?',
    options: ['3', '4', '5', '6'],
    correctIndex: 1,
    difficulty: 'hard',
    category: 'Universal Synthesis',
    explanation: 'A 2-input XOR gate can be synthesized with exactly 4 two-input NAND gates.'
  },
  {
    id: 'hd_5',
    question: 'What is the output of the Boolean Consensus Theorem: A·B + ~A·C + B·C ?',
    options: ['B · C', 'A·B + ~A·C', 'A · C', 'A ⊕ B ⊕ C'],
    correctIndex: 1,
    difficulty: 'hard',
    category: 'Boolean Theorems',
    explanation: 'In AB + ~AC + BC, the term BC is the redundant consensus term and drops out, leaving AB + ~AC.'
  },
  {
    id: 'hd_6',
    question: 'What is the Boolean expression for the Carry-Out of a 3-input Majority Gate?',
    options: ['Y = A ⊕ B ⊕ C', 'Y = A·B + B·C + A·C', 'Y = (A+B)·(B+C)', 'Y = ~(A·B·C)'],
    correctIndex: 1,
    difficulty: 'hard',
    category: 'Majority & TMR',
    explanation: 'The Majority function outputs 1 when 2 or more inputs are 1: Y = AB + BC + AC.'
  },
  {
    id: 'hd_7',
    question: 'How many bits can a 4-to-16 line decoder select simultaneously when enabled?',
    options: ['1 line out of 16', '4 lines out of 16', '8 lines out of 16', 'All 16 lines'],
    correctIndex: 0,
    difficulty: 'hard',
    category: 'Decoders',
    explanation: 'A binary decoder activates exactly one unique output corresponding to the 4-bit binary code.'
  },
  {
    id: 'hd_8',
    question: 'If an XOR gate has 5 inputs and three of them are 1 while two are 0, what is the output?',
    options: ['0', '1', 'High-Z', 'Indeterminate'],
    correctIndex: 1,
    difficulty: 'hard',
    category: 'Parity Detection',
    explanation: 'Multi-input XOR is an odd-function: it outputs 1 if the number of 1-inputs is ODD. Since 3 is odd, output is 1.'
  },
  {
    id: 'hd_9',
    question: 'Which logic circuit is used to generate 2\'s complement of a binary number?',
    options: ['Invert all bits and add 1', 'Add 1 and shift left', 'Invert MSB only', 'XOR with 0'],
    correctIndex: 0,
    difficulty: 'hard',
    category: 'Arithmetic Circuits',
    explanation: '2\'s complement is formed by taking 1\'s complement (NOT all bits) and adding 1 to the least significant bit.'
  },
  {
    id: 'hd_10',
    question: 'In Karnaugh Maps (K-Maps), what is the maximum number of minterm cells grouped together?',
    options: ['Any integer', 'Must be a power of 2 (1, 2, 4, 8, 16...)', 'Must be an odd number', 'Multiples of 3'],
    correctIndex: 1,
    difficulty: 'hard',
    category: 'K-Maps',
    explanation: 'K-map groupings must always be contiguous rectangles or toroids sized in powers of 2 (2^k).'
  },
  {
    id: 'hd_11',
    question: 'What is the propagation delay penalty in a 32-bit Ripple Carry Adder compared to Carry Lookahead?',
    options: ['Linear O(n) delay vs logarithmic O(log n) delay', 'Identical delay', 'RCA is faster', 'Constant delay'],
    correctIndex: 0,
    difficulty: 'hard',
    category: 'Advanced Computer Architecture',
    explanation: 'In RCA, each stage waits for carry to ripple through (O(n)), whereas Carry Lookahead computes carries in parallel (O(log n)).'
  },
  {
    id: 'hd_12',
    question: 'What is the output of ~(A ⊕ B)?',
    options: ['A ⊙ B (XNOR)', 'A · B', 'A + B', 'A ⊕ ~B'],
    correctIndex: 0,
    difficulty: 'hard',
    category: 'Logic Equivalence',
    explanation: 'Complemented XOR is XNOR (Equivalence Gate), symbolized by ⊙.'
  }
];

export const getTenQuizQuestions = (difficulty: 'easy' | 'hard'): QuizGameQuestion[] => {
  const pool = difficulty === 'easy' ? [...EASY_QUIZ_POOL] : [...HARD_QUIZ_POOL];
  // Shuffle array
  for (let i = pool.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [pool[i], pool[j]] = [pool[j], pool[i]];
  }
  return pool.slice(0, 10);
};
