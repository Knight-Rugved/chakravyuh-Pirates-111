import { Chapter } from '../types';

export const CHAPTERS_DATA: Chapter[] = [
  {
    id: 'ch1_basic_gates',
    number: 1,
    title: 'Basic Logic Gates',
    subtitle: 'AND, OR & NOT — The Elementary Atoms of Computation',
    category: 'Fundamental Gates',
    badge: 'Core Foundation',
    defaultEquation: 'Y = A * B + C',
    theory: {
      summary: 'Basic logic gates are the foundational building blocks of all digital integrated circuits. Every computer processor and memory cell is composed of billions of these microscopic switches.',
      bulletPoints: [
        'AND Gate: Outputs HIGH (1) if and only if ALL inputs are 1. Boolean expression: Y = A · B',
        'OR Gate: Outputs HIGH (1) if AT LEAST ONE input is 1. Boolean expression: Y = A + B',
        'NOT Gate (Inverter): Outputs the complement of the input (0 becomes 1, 1 becomes 0). Boolean expression: Y = ~A or A\'',
        'Standard TTL IC chips: 7408 (Quad 2-input AND), 7432 (Quad 2-input OR), 7404 (Hex Inverter NOT)',
        'Logic Levels: In standard 5V TTL logic, HIGH corresponds to 2.4V - 5.0V (Binary 1), and LOW corresponds to 0V - 0.8V (Binary 0).'
      ],
      icNumbers: ['7408 (AND)', '7432 (OR)', '7404 (NOT)'],
      truthTableHeaders: ['A', 'B', 'A · B (AND)', 'A + B (OR)', '~A (NOT A)'],
      truthTableRows: [
        [0, 0, 0, 0, 1],
        [0, 1, 0, 1, 1],
        [1, 0, 0, 1, 0],
        [1, 1, 1, 1, 0]
      ],
      booleanFormula: 'Y = A · B (AND), Y = A + B (OR), Y = ~A (NOT)'
    },
    eli7: {
      storyTitle: 'The Ice Cream Shop & The Opposite Robot',
      story: `Imagine you want to buy your favorite triple-chocolate ice cream! 🍨
      
• The AND Gate is like having two strict parents: You can ONLY get ice cream if Dad says YES **AND** Mom says YES. If either one says NO, you get zero ice cream!

• The OR Gate is like having super chill grandparents: You get ice cream if Grandpa says YES **OR** Grandma says YES. Even if only one says YES, you are enjoying that ice cream!

• The NOT Gate is a funny little robot named "Opposite Robot" 🤖. Whatever you tell it, it does the exact reverse! If you say "Jump!", it ducks. If you give it a 1 (ON), it gives you back a 0 (OFF). If you give it a 0, it shines a 1!`,
      keyTakeaway: 'AND needs everyone to agree. OR is happy with just one yes. NOT turns everything upside down!',
      funFact: 'A modern smartphone chip has over 15 BILLION of these tiny gates squeezed onto a chip smaller than your fingernail!'
    },
    flashcards: [
      {
        id: 'fc_1_1',
        category: 'Chapter 1: Basic Gates',
        question: 'What is the output of an AND gate when input A = 1 and input B = 0?',
        answer: 'Output Y = 0 (LOW). An AND gate requires ALL inputs to be 1 to produce a 1.',
        hint: 'Both inputs must be true.'
      },
      {
        id: 'fc_1_2',
        category: 'Chapter 1: Basic Gates',
        question: 'What is the TTL IC chip number for a Quad 2-input AND gate?',
        answer: 'IC 7408. It contains 4 independent two-input AND gates inside a single 14-pin DIP package.',
        hint: 'Starts with 740...'
      },
      {
        id: 'fc_1_3',
        category: 'Chapter 1: Basic Gates',
        question: 'If an OR gate has 4 inputs and only one input is 1 while the other three are 0, what is the output?',
        answer: 'Output Y = 1 (HIGH). For an OR gate, if any single input is 1, the output is guaranteed to be 1.',
        hint: 'Does OR require all inputs or at least one?'
      },
      {
        id: 'fc_1_4',
        category: 'Chapter 1: Basic Gates',
        question: 'What is the Boolean inversion law for double negation ~(~A)?',
        answer: 'Double Inversion Law: ~(~A) = A. Inverting a signal twice returns it to its original logic state.',
        hint: 'Opposite of opposite.'
      }
    ],
    quiz: [
      {
        id: 'q_1_1',
        question: 'Which logic gate produces a 1 ONLY when both of its inputs are 1?',
        options: ['OR gate', 'AND gate', 'NOT gate', 'NOR gate'],
        correctIndex: 1,
        explanation: 'The AND gate implements logical conjunction: it yields 1 only when both inputs are simultaneously 1.'
      },
      {
        id: 'q_1_2',
        question: 'What is the output of an inverter (NOT gate) when the input is binary 0?',
        options: ['0', '1', 'High Impedance (Z)', 'Undefined'],
        correctIndex: 1,
        explanation: 'NOT 0 = 1. An inverter complements its single input logic level.'
      },
      {
        id: 'q_1_3',
        question: 'Which standard 74xx series IC contains four 2-input OR gates?',
        options: ['7400', '7408', '7432', '7486'],
        correctIndex: 2,
        explanation: '7432 is the standard TTL IC containing four 2-input OR gates.'
      },
      {
        id: 'q_1_4',
        question: 'Evaluate the expression Y = A + B · C when A = 0, B = 1, C = 1.',
        options: ['0', '1', 'Ambiguous', '-1'],
        correctIndex: 1,
        explanation: 'B · C = 1 · 1 = 1. Then A + 1 = 0 + 1 = 1.'
      }
    ]
  },
  {
    id: 'ch2_universal_gates',
    number: 2,
    title: 'Universal Gates',
    subtitle: 'NAND & NOR — The Magic Keys to Building Any Circuit',
    category: 'Universal Logic',
    badge: 'Industry Standard',
    defaultEquation: 'Y = ~(A * B)',
    theory: {
      summary: 'A universal gate is a logic gate that can implement any Boolean function without needing any other gate type. Both NAND and NOR are functionally complete universal gates.',
      bulletPoints: [
        'NAND Gate: NOT-AND. Output is 0 ONLY when both inputs are 1. Boolean expression: Y = ~(A · B)',
        'NOR Gate: NOT-OR. Output is 1 ONLY when both inputs are 0. Boolean expression: Y = ~(A + B)',
        'Functional Completeness: By tying inputs together, a NAND gate becomes an inverter: ~(A · A) = ~A.',
        'AND from NAND: Connect a NAND followed by a NAND inverter: ~(~(A · B)) = A · B.',
        'OR from NAND: Invert inputs and pass to NAND: ~(~A · ~B) = A + B (by De Morgan\'s Law).',
        'Standard TTL ICs: 7400 (Quad 2-input NAND), 7402 (Quad 2-input NOR).'
      ],
      icNumbers: ['7400 (NAND)', '7402 (NOR)'],
      truthTableHeaders: ['A', 'B', 'NAND ~(A·B)', 'NOR ~(A+B)'],
      truthTableRows: [
        [0, 0, 1, 1],
        [0, 1, 1, 0],
        [1, 0, 1, 0],
        [1, 1, 0, 0]
      ],
      booleanFormula: 'NAND: Y = ~(A · B) = ~A + ~B  |  NOR: Y = ~(A + B) = ~A · ~B'
    },
    eli7: {
      storyTitle: 'The Magic Master LEGO Brick',
      story: `Imagine you have a giant toy chest with hundreds of different shaped pieces: wheels, wings, windows, and gears. 
      
Now imagine a master toy inventor says: *"Throw all those away. I give you ONE single magical shape brick. Using only this ONE brick, you can click them together to make wings, cars, houses, or spaceships!"* 🚀
      
That is exactly what a **NAND gate** is in computer chips!
• If you tie its two wires together, it becomes a NOT gate.
• If you stick two of them back-to-back, it becomes an AND gate.
• If you arrange three of them, presto! It transforms into an OR gate.
Because chip factories only need to stamp this one single pattern millions of times, it is super cheap, super fast, and super powerful!`,
      keyTakeaway: 'You don\'t need 10 different gate types to build a supercomputer. You can build every single thing using only NAND gates!',
      funFact: 'The Apollo Guidance Computer that flew astronauts to the Moon in 1969 was built entirely out of 5,600 identical 3-input NOR gates!'
    },
    flashcards: [
      {
        id: 'fc_2_1',
        category: 'Chapter 2: Universal Gates',
        question: 'Why are NAND and NOR called "Universal Gates"?',
        answer: 'Because any Boolean logic circuit (AND, OR, NOT, XOR, adders, processors) can be built exclusively using only NAND gates or only NOR gates.',
        hint: 'They can build every other gate.'
      },
      {
        id: 'fc_2_2',
        category: 'Chapter 2: Universal Gates',
        question: 'How do you turn a 2-input NAND gate into an inverter (NOT gate)?',
        answer: 'Connect both inputs (A and B) together to the same input signal. Since A · A = A, ~(A · A) = ~A.',
        hint: 'Tie the two input pins together.'
      },
      {
        id: 'fc_2_3',
        category: 'Chapter 2: Universal Gates',
        question: 'How many 2-input NAND gates are needed to construct a 2-input OR gate?',
        answer: 'Three NAND gates! Two are used to invert inputs A and B (~A, ~B), and the third computes ~(~A · ~B) = A + B.',
        hint: 'Use De Morgan\'s Law.'
      },
      {
        id: 'fc_2_4',
        category: 'Chapter 2: Universal Gates',
        question: 'What is the TTL IC number for Quad 2-input NAND gates?',
        answer: 'IC 7400. It is the most famous and widely manufactured digital logic chip in history.',
        hint: 'Round numbers starting with 74...'
      }
    ],
    quiz: [
      {
        id: 'q_2_1',
        question: 'Which of the following gates is functionally complete (universal)?',
        options: ['AND gate', 'OR gate', 'NAND gate', 'XOR gate'],
        correctIndex: 2,
        explanation: 'NAND (and NOR) is functionally complete and can implement any arbitrary Boolean function without other gates.'
      },
      {
        id: 'q_2_2',
        question: 'What is the output of a 2-input NOR gate when inputs are A = 0 and B = 1?',
        options: ['1', '0', 'Toggle', 'Undefined'],
        correctIndex: 1,
        explanation: 'NOR is NOT-OR: ~(0 + 1) = ~(1) = 0.'
      },
      {
        id: 'q_2_3',
        question: 'How many NAND gates are required to implement a standard 2-input AND gate?',
        options: ['1', '2', '3', '4'],
        correctIndex: 1,
        explanation: 'Two NAND gates: The first produces ~(A·B), and the second inverts it back: ~(~(A·B)) = A·B.'
      },
      {
        id: 'q_2_4',
        question: 'What historical computer was built entirely out of NOR logic gates?',
        options: ['ENIAC', 'Apollo Guidance Computer (AGC)', 'Commodore 64', 'Deep Blue'],
        correctIndex: 1,
        explanation: 'The Apollo Guidance Computer used thousands of integrated NOR gates for ultimate space-grade reliability.'
      }
    ]
  },
  {
    id: 'ch3_specialized_gates',
    number: 3,
    title: 'Specialized Gates: XOR & XNOR',
    subtitle: 'Exclusive-OR & Parity Detectors — The Heart of Arithmetic & Cryptography',
    category: 'Arithmetic & Parity',
    badge: 'Crucial for Math',
    defaultEquation: 'Y = A ⊕ B',
    theory: {
      summary: 'XOR (Exclusive-OR) and XNOR (Equivalence) gates are specialized combinational gates critical for binary addition, inequality testing, parity generation, and digital cryptography.',
      bulletPoints: [
        'XOR Gate: Outputs 1 when the inputs are DIFFERENT (one is 1 and the other is 0). Boolean expression: Y = A ⊕ B = A·~B + ~A·B',
        'XNOR Gate: Outputs 1 when inputs are the SAME (both 0 or both 1). Also called an Equivalence gate. Expression: Y = ~(A ⊕ B) = A·B + ~A·~B',
        'Odd Function: For multiple inputs, XOR outputs 1 if an ODD number of inputs are 1. This makes it ideal for parity bit generation.',
        'Modulo-2 Addition: XOR is mathematically identical to binary addition without carry (0+0=0, 0+1=1, 1+0=1, 1+1=0).',
        'Controlled Inverter: If one input of an XOR is tied to 1, the other input is inverted (A ⊕ 1 = ~A). If tied to 0, it passes unchanged (A ⊕ 0 = A).'
      ],
      icNumbers: ['7486 (Quad 2-input XOR)', '74266 (Quad 2-input XNOR)'],
      truthTableHeaders: ['A', 'B', 'A ⊕ B (XOR)', 'A ⊙ B (XNOR)'],
      truthTableRows: [
        [0, 0, 0, 1],
        [0, 1, 1, 0],
        [1, 0, 1, 0],
        [1, 1, 0, 1]
      ],
      booleanFormula: 'XOR: Y = A·~B + ~A·B  |  XNOR: Y = A·B + ~A·~B'
    },
    eli7: {
      storyTitle: 'The Seesaw Game & Twin Detectives',
      story: `Have you ever played on a playground seesaw? 🎠
      
• The **XOR Gate** is like a seesaw: It is only fun and working when one person is UP and the other person is DOWN! If both kids try to sit on the ground (0 and 0), nothing happens (Output 0). If both kids jump up at once (1 and 1), they crash (Output 0). But when one is up and the other is down, the seesaw is balanced and active (Output 1)!

• The **XNOR Gate** is the "Twin Detector": It wears shiny detective glasses 🔍. It only smiles and rings its bell (Output 1) if both people are wearing the exact same socks! Either both wear red (1 and 1) or both wear blue (0 and 0). If their socks don't match, it sounds an alarm!`,
      keyTakeaway: 'XOR gives 1 for differences. XNOR gives 1 for identical twins.',
      funFact: 'XOR is used in almost every secret code and encrypted message sent over WhatsApp and Wi-Fi because scrambling and unscrambling with XOR is super fast!'
    },
    flashcards: [
      {
        id: 'fc_3_1',
        category: 'Chapter 3: XOR & XNOR',
        question: 'What is the Boolean expression for a 2-input XOR gate in sum-of-products (SOP) form?',
        answer: 'Y = A·~B + ~A·B (A AND NOT B, OR NOT A AND B).',
        hint: 'One input true while the other is false.'
      },
      {
        id: 'fc_3_2',
        category: 'Chapter 3: XOR & XNOR',
        question: 'What happens when you XOR any binary variable A with 1 (A ⊕ 1)?',
        answer: 'A ⊕ 1 = ~A (Inversion). It acts as a controlled inverter or NOT gate.',
        hint: 'If A=0, 0 ⊕ 1 = 1. If A=1, 1 ⊕ 1 = 0.'
      },
      {
        id: 'fc_3_3',
        category: 'Chapter 3: XOR & XNOR',
        question: 'What is A ⊕ A for any logic value A?',
        answer: 'A ⊕ A = 0. XORing any variable with itself always produces 0 because both inputs are identical.',
        hint: 'Can identical inputs yield 1 in XOR?'
      },
      {
        id: 'fc_3_4',
        category: 'Chapter 3: XOR & XNOR',
        question: 'Which TTL IC contains four 2-input XOR gates?',
        answer: 'IC 7486 (Quad 2-input Exclusive-OR Gate).',
        hint: 'Starts with 748...'
      }
    ],
    quiz: [
      {
        id: 'q_3_1',
        question: 'What is the output of 1 ⊕ 1?',
        options: ['0', '1', '2', 'High Impedance'],
        correctIndex: 0,
        explanation: 'In XOR, when both inputs are 1, they are identical, so output is 0 (modulo-2 sum: 1 + 1 = 0 with carry 1).'
      },
      {
        id: 'q_3_2',
        question: 'Which gate is also known as an "Equivalence Gate" or "Comparator"?',
        options: ['XOR', 'XNOR', 'NAND', 'OR'],
        correctIndex: 1,
        explanation: 'XNOR produces 1 when inputs are equivalent (both 0 or both 1), functioning as a 1-bit equality comparator.'
      },
      {
        id: 'q_3_3',
        question: 'If A = 1, B = 0, C = 1, what is the value of A ⊕ B ⊕ C?',
        options: ['0', '1', 'Undefined', 'Cannot determine'],
        correctIndex: 0,
        explanation: '(1 ⊕ 0) = 1. Then (1 ⊕ 1) = 0. An even number of 1s yields 0.'
      },
      {
        id: 'q_3_4',
        question: 'What is the sum output of a 1-bit binary adder for inputs A and B?',
        options: ['Sum = A · B', 'Sum = A + B', 'Sum = A ⊕ B', 'Sum = ~(A ⊕ B)'],
        correctIndex: 2,
        explanation: 'Binary addition modulo-2 produces Sum = A ⊕ B and Carry = A · B.'
      }
    ]
  },
  {
    id: 'ch4_combinational_boolean',
    number: 4,
    title: 'Combinational Logic & Boolean Algebra',
    subtitle: 'De Morgan\'s Theorems, SOP/POS & Circuit Simplification',
    category: 'Boolean Theorems',
    badge: 'Essential Theory',
    defaultEquation: 'Y = ~A*B + A*~B',
    theory: {
      summary: 'Combinational logic circuits have outputs determined solely by the current combination of inputs, with no memory of past states. Boolean algebra provides the mathematical rules to simplify circuits, saving silicon area, power, and cost.',
      bulletPoints: [
        'De Morgan\'s First Law: The complement of a product is the sum of complements: ~(A · B) = ~A + ~B',
        'De Morgan\'s Second Law: The complement of a sum is the product of complements: ~(A + B) = ~A · ~B',
        'Idempotent Laws: A · A = A and A + A = A',
        'Absorption Law: A + A · B = A (terms with extra variables drop out)',
        'Consensus Theorem: AB + ~AC + BC = AB + ~AC (the term BC is redundant)',
        'SOP (Sum of Products): Minimized OR of AND terms (e.g. AB + CD)',
        'POS (Product of Sums): Minimized AND of OR terms (e.g. (A+B)(C+D))'
      ],
      icNumbers: ['7410 (Triple 3-input NAND)', '7420 (Dual 4-input NAND)'],
      truthTableHeaders: ['A', 'B', '~(A · B)', '~A + ~B', 'Equal?'],
      truthTableRows: [
        [0, 0, 1, 1, 'YES'],
        [0, 1, 1, 1, 'YES'],
        [1, 0, 1, 1, 'YES'],
        [1, 1, 0, 0, 'YES']
      ],
      booleanFormula: 'De Morgan: ~(A · B) = ~A + ~B  and  ~(A + B) = ~A · ~B'
    },
    eli7: {
      storyTitle: 'The Detective\'s Secret Shortcut Recipe',
      story: `Imagine a chef giving you a giant, confusing recipe that takes 10 pages and 50 pots to make one sandwich! 🥪
      
Then a clever master detective steps in and says: *"Look closely! You wrote 'add cheese, and also add cheese again if the sun is shining, but if you don't add cheese then put nothing.' That is just silly! All you really need is: ADD CHEESE!"*
      
That is what **Boolean Algebra** does for computers!
Engineers use secret math tricks called **De Morgan's Laws** to turn a giant tangle of 100 wires and 20 noisy power-hungry chips into just 3 neat gates that do the exact same job, run 10x faster, and never overheat your computer!`,
      keyTakeaway: 'Boolean algebra is the art of turning big, messy circuits into tiny, super-fast circuits without changing the answer!',
      funFact: 'George Boole invented Boolean Algebra in 1847 to describe human logical thinking — almost 100 years before the first electronic computer was ever built!'
    },
    flashcards: [
      {
        id: 'fc_4_1',
        category: 'Chapter 4: Boolean Algebra',
        question: 'State De Morgan’s First Law in Boolean Algebra.',
        answer: '~(A · B) = ~A + ~B. The complement of an AND operation is equivalent to the OR of the inverted inputs.',
        hint: 'Break the line, change the sign!'
      },
      {
        id: 'fc_4_2',
        category: 'Chapter 4: Boolean Algebra',
        question: 'Simplify the expression: A + A · B',
        answer: 'A (Absorption Law). Since A · (1 + B) = A · 1 = A, the term A·B is completely absorbed.',
        hint: 'Factor out variable A.'
      },
      {
        id: 'fc_4_3',
        category: 'Chapter 4: Boolean Algebra',
        question: 'What is the result of A + ~A according to the Law of Complementarity?',
        answer: '1 (HIGH). Since one variable is guaranteed to be 1, ORing anything with 1 yields 1.',
        hint: 'Either A is 1 or ~A is 1.'
      },
      {
        id: 'fc_4_4',
        category: 'Chapter 4: Boolean Algebra',
        question: 'What does SOP stand for in digital circuit design?',
        answer: 'Sum of Products. It represents an OR gate taking outputs from multiple AND gates (e.g., Y = AB + CD).',
        hint: 'Addition of multiplications.'
      }
    ],
    quiz: [
      {
        id: 'q_4_1',
        question: 'According to De Morgan\'s Law, what does ~(A + B) equal?',
        options: ['~A + ~B', '~A · ~B', 'A · B', '~(A · B)'],
        correctIndex: 1,
        explanation: 'De Morgan: The complement of an OR is the AND of the complements: ~(A + B) = ~A · ~B.'
      },
      {
        id: 'q_4_2',
        question: 'Simplify the Boolean expression: X · (X + Y)',
        options: ['X + Y', 'X · Y', 'X', 'Y'],
        correctIndex: 2,
        explanation: 'By distribution: X·X + X·Y = X + X·Y = X(1 + Y) = X(1) = X.'
      },
      {
        id: 'q_4_3',
        question: 'What is the dual of the Boolean identity A + 0 = A?',
        options: ['A · 1 = A', 'A · 0 = 0', 'A + 1 = 1', '~A + 0 = ~A'],
        correctIndex: 0,
        explanation: 'Duality principle: swap + with · and swap 0 with 1, giving A · 1 = A.'
      },
      {
        id: 'q_4_4',
        question: 'In a Karnaugh Map (K-Map), adjacent cells differ by how many binary bits?',
        options: ['Exactly 1 bit (Gray code)', '2 bits', 'Any number', '4 bits'],
        correctIndex: 0,
        explanation: 'K-maps use Gray code ordering so adjacent squares differ by only one variable bit, allowing visual grouping.'
      }
    ]
  },
  {
    id: 'ch5_arithmetic_adders',
    number: 5,
    title: 'Arithmetic Circuits: Half & Full Adders',
    subtitle: 'From Modulo Sums to Ripple-Carry Binary Calculators',
    category: 'Computer Arithmetic',
    badge: 'ALU Heart',
    defaultEquation: 'Y = A*B + B*C + A*C',
    theory: {
      summary: 'Addition is the most critical operation in a digital computer\'s Arithmetic Logic Unit (ALU). Multiplication, division, subtraction (via 2\'s complement), and address generation all rely on binary adder circuits.',
      bulletPoints: [
        'Half Adder (HA): Adds two 1-bit inputs (A and B). Produces two outputs: Sum (S) and Carry (C).',
        'HA Equations: Sum = A ⊕ B, Carry = A · B. It cannot accept a carry from a previous stage.',
        'Full Adder (FA): Adds three 1-bit inputs: A, B, and Carry-In (C_in) from a preceding lower bit stage.',
        'FA Sum Equation: Sum = A ⊕ B ⊕ C_in',
        'FA Carry-Out Equation: C_out = A·B + B·C_in + A·C_in (Majority function)',
        'Full Adder from Half Adders: A Full Adder can be constructed from two Half Adders and one OR gate.',
        'Ripple Carry Adder (RCA): Cascading n Full Adders produces an n-bit adder, where carry propagates from LSB to MSB.'
      ],
      icNumbers: ['74283 (4-bit Binary Full Adder with Fast Carry)', '7483 (4-bit Binary Adder)'],
      truthTableHeaders: ['A', 'B', 'C_in', 'Sum (S)', 'C_out'],
      truthTableRows: [
        [0, 0, 0, 0, 0],
        [0, 0, 1, 1, 0],
        [0, 1, 0, 1, 0],
        [0, 1, 1, 0, 1],
        [1, 0, 0, 1, 0],
        [1, 0, 1, 0, 1],
        [1, 1, 0, 0, 1],
        [1, 1, 1, 1, 1]
      ],
      booleanFormula: 'Sum = A ⊕ B ⊕ C_in  |  C_out = A·B + C_in·(A ⊕ B)'
    },
    eli7: {
      storyTitle: 'The Monster Piggy Bank with the Carry Attic',
      story: `How do humans count? If you have 9 pennies and someone hands you 1 more, your hands are completely full! You write 0 and "carry the 1" over to the tens column to make 10! 🪙
      
Computers do the exact same thing, but in binary (base-2), their hands get full at just **1**!
• When a computer adds 1 + 1, it cannot say 2 because binary only knows 0 and 1.
• So it puts down a **0 in the Sum box**, and kicks a **1 upstairs into the Carry Attic**! That makes "10" in binary (which means 2 in our human numbers).
• A **Half Adder** can only add two coins. But if there is already an old carried coin from earlier, it gets confused!
• A **Full Adder** is the champion: it has three slots! It takes coin A, coin B, AND the carried coin from your friend, adds all three smoothly, and passes any extra coin to the next friend in line!`,
      keyTakeaway: 'Binary addition puts the remainder in SUM and passes the overflow coin forward in CARRY!',
      funFact: 'When you play a high-definition 3D video game at 120 frames per second, your graphics card uses millions of these adders to calculate billions of pixel coordinates every second!'
    },
    flashcards: [
      {
        id: 'fc_5_1',
        category: 'Chapter 5: Adders',
        question: 'What is the primary difference between a Half Adder and a Full Adder?',
        answer: 'A Half Adder only adds two 1-bit numbers (A and B). A Full Adder adds three 1-bit numbers: A, B, and a Carry-In (C_in) from a previous column.',
        hint: 'Look at the number of inputs.'
      },
      {
        id: 'fc_5_2',
        category: 'Chapter 5: Adders',
        question: 'What gates are needed to build a single Half Adder?',
        answer: 'One 2-input XOR gate (for the Sum: A ⊕ B) and one 2-input AND gate (for the Carry: A · B).',
        hint: 'One for difference, one for both.'
      },
      {
        id: 'fc_5_3',
        category: 'Chapter 5: Adders',
        question: 'What is the Boolean expression for the Carry-Out (C_out) of a Full Adder?',
        answer: 'C_out = A·B + B·C_in + A·C_in (or A·B + C_in·(A ⊕ B)). It is the Majority function of the three inputs.',
        hint: 'Active whenever 2 or more inputs are 1.'
      },
      {
        id: 'fc_5_4',
        category: 'Chapter 5: Adders',
        question: 'How do you perform subtraction (A - B) using an adder circuit?',
        answer: 'By taking the 2\'s complement of B (inverting all bits with NOT/XOR gates and adding 1 via C_in) and then feeding it into the standard adder: A + (~B + 1).',
        hint: '2\'s complement method.'
      }
    ],
    quiz: [
      {
        id: 'q_5_1',
        question: 'In a Half Adder, what is the output when A = 1 and B = 1?',
        options: ['Sum = 0, Carry = 1', 'Sum = 1, Carry = 0', 'Sum = 1, Carry = 1', 'Sum = 0, Carry = 0'],
        correctIndex: 0,
        explanation: '1 + 1 in binary is 10 (decimal 2). Sum = 1 ⊕ 1 = 0; Carry = 1 · 1 = 1.'
      },
      {
        id: 'q_5_2',
        question: 'How many Half Adders and OR gates are needed to make one Full Adder?',
        options: ['1 Half Adder + 1 OR gate', '2 Half Adders + 1 OR gate', '3 Half Adders + 0 OR gates', '2 Half Adders + 2 OR gates'],
        correctIndex: 1,
        explanation: 'Two Half Adders and one OR gate: The first HA adds A and B, the second HA adds the result to C_in, and the OR gate combines their carries.'
      },
      {
        id: 'q_5_3',
        question: 'For a Full Adder with inputs A = 1, B = 1, C_in = 1, what are Sum and C_out?',
        options: ['Sum = 0, C_out = 1', 'Sum = 1, C_out = 1', 'Sum = 1, C_out = 0', 'Sum = 0, C_out = 0'],
        correctIndex: 1,
        explanation: '1 + 1 + 1 = 3 in decimal, which is binary 11. Sum = 1 and C_out = 1.'
      },
      {
        id: 'q_5_4',
        question: 'What is the main speed bottleneck in a simple Ripple Carry Adder?',
        options: ['XOR gate delay', 'Carry propagation delay rippling from LSB to MSB', 'Clock frequency', 'Input bounce'],
        correctIndex: 1,
        explanation: 'Each subsequent stage must wait for the carry bit to ripple through from the preceding bit, creating propagation latency.'
      }
    ]
  },
  {
    id: 'ch6_multiplexers_routing',
    number: 6,
    title: 'Data Routing: Multiplexers & Decoders',
    subtitle: 'Digital Traffic Controllers — Directing Millions of Signals',
    category: 'Data Routing',
    badge: 'Bus Architecture',
    defaultEquation: 'Y = A*~S + B*S',
    theory: {
      summary: 'A Multiplexer (MUX), or data selector, is a combinational circuit that selects binary information from one of many input lines and routes it to a single output line, guided by selection control inputs.',
      bulletPoints: [
        '2-to-1 Multiplexer: Has two data inputs (I0, I1), one select line (S), and one output (Y).',
        '2:1 MUX Equation: Y = I0 · ~S + I1 · S. When S = 0, Y = I0. When S = 1, Y = I1.',
        '4-to-1 Multiplexer: 4 data lines (I0-I3), 2 select lines (S1, S0). Equation: Y = I0~S1~S0 + I1~S1S0 + I2S1~S0 + I3S1S0.',
        'Demultiplexer (DEMUX): Performs the reverse operation: takes a single input data line and routes it to one of 2^n output lines.',
        'Decoder: Converts an n-bit binary code into at most 2^n unique output lines (e.g. 3-to-8 decoder, 7-segment display decoder).',
        'Universal Logic Implementer: Any Boolean function of n variables can be implemented directly using an n-to-1 MUX without any extra logic gates.'
      ],
      icNumbers: ['74151 (8-to-1 Data Selector/Multiplexer)', '74138 (3-to-8 Line Decoder/Demultiplexer)'],
      truthTableHeaders: ['Select (S)', 'Input A (I0)', 'Input B (I1)', 'Output (Y)'],
      truthTableRows: [
        [0, 0, 0, 0],
        [0, 1, 0, 1],
        [0, 1, 1, 1],
        [1, 0, 0, 0],
        [1, 0, 1, 1],
        [1, 1, 1, 1]
      ],
      booleanFormula: '2:1 MUX: Y = A · ~S + B · S'
    },
    eli7: {
      storyTitle: 'The Great Train Track Switcher',
      story: `Imagine a magical toy railway station with two train tracks: Track A has a blue passenger train 🚂, and Track B has a red circus train 🎪!
      
Both tracks lead toward one single bridge across a river.
There is a smart conductor sitting at a control lever labeled **S (Select)**:
• If the conductor keeps the lever pushed to **0**, Track A connects to the bridge, and the blue train speeds across!
• If the conductor flips the lever to **1**, CLICK! The rails slide over, Track B connects to the bridge, and the circus train speeds across!

That is a **Multiplexer (MUX)**! It is the traffic cop of computer chips, deciding which voice call, movie stream, or camera image gets through to your screen!`,
      keyTakeaway: 'A Multiplexer has many doors in, but only one door out. The Select lever chooses who gets through!',
      funFact: 'Your home Wi-Fi router uses fast multiplexing millions of times every second so your phone, laptop, and TV can share a single internet cable without colliding!'
    },
    flashcards: [
      {
        id: 'fc_6_1',
        category: 'Chapter 6: Multiplexers',
        question: 'How many select lines are required for an 8-to-1 Multiplexer?',
        answer: '3 select lines (since 2^3 = 8). The 3 binary select bits select one of the 8 inputs.',
        hint: '2 to the power of n.'
      },
      {
        id: 'fc_6_2',
        category: 'Chapter 6: Multiplexers',
        question: 'What is the Boolean equation for a 2:1 MUX with inputs A, B and select bit S?',
        answer: 'Y = A · ~S + B · S (If S=0, Y=A; if S=1, Y=B).',
        hint: 'AND with complement of S and S.'
      },
      {
        id: 'fc_6_3',
        category: 'Chapter 6: Multiplexers',
        question: 'What is the reverse circuit of a Multiplexer called?',
        answer: 'A Demultiplexer (DEMUX). It takes 1 input line and directs it to one of multiple outputs.',
        hint: 'Opposite of MUX.'
      },
      {
        id: 'fc_6_4',
        category: 'Chapter 6: Multiplexers',
        question: 'Which TTL IC is a popular 3-to-8 line decoder/demultiplexer?',
        answer: 'IC 74138. It decodes 3 binary inputs into 8 mutually exclusive active-low outputs.',
        hint: 'Starts with 7413...'
      }
    ],
    quiz: [
      {
        id: 'q_6_1',
        question: 'In a 2-to-1 MUX with inputs A and B, if select line S = 0, what is the output Y?',
        options: ['Always 0', 'Always 1', 'Equal to input A', 'Equal to input B'],
        correctIndex: 2,
        explanation: 'When S = 0, ~S = 1, so Y = A · 1 + B · 0 = A.'
      },
      {
        id: 'q_6_2',
        question: 'How many select lines are needed to address a 16-to-1 Multiplexer?',
        options: ['2', '4', '8', '16'],
        correctIndex: 1,
        explanation: '2^n = 16, so n = 4 select lines.'
      },
      {
        id: 'q_6_3',
        question: 'What is another common name for a Multiplexer in digital systems?',
        options: ['Data Selector', 'Parity Checker', 'Accumulator', 'Frequency Divider'],
        correctIndex: 0,
        explanation: 'Multiplexers are universally known as Data Selectors because they select one data channel among many.'
      },
      {
        id: 'q_6_4',
        question: 'Can any 3-variable Boolean function be implemented using an 8-to-1 MUX without extra logic gates?',
        options: ['No, extra inverters are always needed', 'Yes, directly by connecting inputs to 0 or 1', 'Only if the function is symmetric', 'Only for POS expressions'],
        correctIndex: 1,
        explanation: 'Yes! Connect the 3 variables to select lines S2, S1, S0 and tie each of the 8 data inputs directly to Vcc (1) or Ground (0) according to the truth table.'
      }
    ]
  },
  {
    id: 'ch7_majority_tmr',
    number: 7,
    title: 'Advanced Logic: Majority Gate & TMR',
    subtitle: 'Triple Modular Redundancy & Mission-Critical Fault Tolerance',
    category: 'Fault-Tolerant Computing',
    badge: 'Spacecraft Tech',
    defaultEquation: 'Y = A*B + B*C + A*C',
    theory: {
      summary: 'The Majority Gate is a decision-making circuit whose output is HIGH if and only if more than half of its inputs are HIGH. In aerospace and nuclear systems, it forms the voting core of Triple Modular Redundancy (TMR) to prevent system crashes caused by cosmic rays or hardware faults.',
      bulletPoints: [
        '3-Input Majority Function: Y = A·B + B·C + A·C',
        'Operating Principle: Output is 1 whenever 2 or 3 inputs are 1. Output is 0 when 0 or 1 input is 1.',
        'Gate Stage 1: Three 2-input AND gates calculating all pair combinations (A·B, B·C, A·C).',
        'Gate Stage 2: A 3-input OR gate that sums the pair products.',
        'Triple Modular Redundancy (TMR): Three identical processors run in parallel computing the same flight calculations. The majority voter compares all three: even if cosmic radiation flips a bit in one computer, the other two outvote it 2-to-1!',
        'Connection to Full Adders: The Majority Gate equation Y = AB + BC + AC is identical to the Carry-Out (C_out) logic of a 1-bit full adder!'
      ],
      icNumbers: ['7411 (Triple 3-input AND)', '7427 (Triple 3-input NOR)'],
      truthTableHeaders: ['A', 'B', 'C', '1s Count', 'Output Y (Majority)'],
      truthTableRows: [
        [0, 0, 0, 0, 0],
        [0, 0, 1, 1, 0],
        [0, 1, 0, 1, 0],
        [0, 1, 1, 2, 1],
        [1, 0, 0, 1, 0],
        [1, 0, 1, 2, 1],
        [1, 1, 0, 2, 1],
        [1, 1, 1, 3, 1]
      ],
      booleanFormula: 'Y = A·B + B·C + A·C'
    },
    eli7: {
      storyTitle: 'The Three Pirate Captains on Treasure Island',
      story: `Three pirate captains (Captain Anne, Captain Blackbeard, and Captain Cook) find a mysterious treasure map on an island! 🏴‍☠️
      
They made a rule so they don't fight:
*"We only dig for treasure if the MAJORITY votes YES!"*
• If only Captain Cook says yes, but the other two say no: 1 against 2. No digging (Output 0)!
• If Captain Anne says yes AND Captain Blackbeard says yes: that is 2 against 1! Majority wins! They grab their shovels and start digging (Output 1)!
• If all 3 vote yes: 3 against 0! Super digging (Output 1)!

NASA spaceships do the exact same thing when flying to Mars! They put three computers on board. If space dust temporarily shocks one computer, the other two computers outvote it 2-to-1, keeping the astronauts completely safe!`,
      keyTakeaway: 'The Majority gate asks: "Are more than half saying YES?" If yes, it outputs 1!',
      funFact: 'SpaceX Falcon 9 rockets and Dragon space capsules use Triple Modular Redundancy computers with voting logic on every launch!'
    },
    flashcards: [
      {
        id: 'fc_7_1',
        category: 'Chapter 7: Majority Logic',
        question: 'What is the Boolean equation for a 3-input Majority Gate?',
        answer: 'Y = A·B + B·C + A·C (Outputs 1 if 2 or more inputs are 1).',
        hint: 'Sum of all 2-variable product pairs.'
      },
      {
        id: 'fc_7_2',
        category: 'Chapter 7: Majority Logic',
        question: 'What does TMR stand for in computer architecture?',
        answer: 'Triple Modular Redundancy. A fault-tolerant architecture with three redundant systems and a majority voter.',
        hint: 'Three modules voting.'
      },
      {
        id: 'fc_7_3',
        category: 'Chapter 7: Majority Logic',
        question: 'Which component of a Full Adder shares the exact same Boolean equation as the Majority gate?',
        answer: 'The Carry-Out (C_out) bit! Both require at least two of the three bits (A, B, C_in) to be 1.',
        hint: 'Carry or Sum?'
      },
      {
        id: 'fc_7_4',
        category: 'Chapter 7: Majority Logic',
        question: 'If a cosmic ray causes one computer in a TMR trio to output a 0 while the other two output 1, what does the voter output?',
        answer: 'The voter outputs 1! The single fault is masked by the 2-to-1 majority vote.',
        hint: 'Two out of three.'
      }
    ],
    quiz: [
      {
        id: 'q_7_1',
        question: 'In a 3-input Majority Gate, what is the output when A = 0, B = 1, C = 1?',
        options: ['0', '1', 'High Impedance', 'Oscillating'],
        correctIndex: 1,
        explanation: 'There are two 1s (B and C). Since 2 >= 2, the majority is 1: B·C = 1, so Y = 1.'
      },
      {
        id: 'q_7_2',
        question: 'What is the primary benefit of Triple Modular Redundancy in aerospace systems?',
        options: ['Higher clock speed', 'Single-event upset / fault masking without interruption', 'Lower battery consumption', 'Simpler PCB routing'],
        correctIndex: 1,
        explanation: 'TMR masks hardware failures and radiation-induced bit flips seamlessly through majority voting.'
      },
      {
        id: 'q_7_3',
        question: 'How many 2-input AND gates and OR gates are needed for a canonical two-level 3-input Majority circuit?',
        options: ['2 AND gates + 1 OR gate', '3 AND gates + 1 OR gate', '4 AND gates + 2 OR gates', '1 AND gate + 3 OR gates'],
        correctIndex: 1,
        explanation: 'Three 2-input AND gates compute A·B, B·C, A·C, and one 3-input OR gate sums them together.'
      },
      {
        id: 'q_7_4',
        question: 'What is the minimum number of inputs required to build a non-trivial majority logic voter?',
        options: ['2 inputs', '3 inputs', '4 inputs', '5 inputs'],
        correctIndex: 1,
        explanation: '3 is the lowest odd number that produces an unambiguous strictly democratic majority (2 out of 3).'
      }
    ]
  }
];
