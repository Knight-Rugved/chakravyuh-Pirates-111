export type NodeType = 'INPUT' | 'OUTPUT' | 'AND' | 'OR' | 'NOT' | 'XOR';

export interface CircuitNode {
  id: string;
  type: NodeType;
  label: string;
  value: number;
  x: number;
  y: number;
}

export interface Connection {
  from: string;
  to: string;
}

export interface ChatMessage {
  id: string;
  sender: 'ai' | 'user';
  text: string;
  timestamp: string;
}

export interface Flashcard {
  id: string;
  question: string;
  answer: string;
  hint?: string;
  category: string;
}

export interface ChapterQuizQuestion {
  id: string;
  question: string;
  options: string[];
  correctIndex: number;
  explanation: string;
}

export interface Chapter {
  id: string;
  number: number;
  title: string;
  subtitle: string;
  category: string;
  badge: string;
  defaultEquation: string;
  theory: {
    summary: string;
    bulletPoints: string[];
    icNumbers: string[];
    truthTableHeaders: string[];
    truthTableRows: (string | number)[][];
    booleanFormula: string;
  };
  eli7: {
    storyTitle: string;
    story: string;
    keyTakeaway: string;
    funFact: string;
  };
  flashcards: Flashcard[];
  quiz: ChapterQuizQuestion[];
}

export interface QuizGameQuestion {
  id: string;
  question: string;
  options: string[];
  correctIndex: number;
  difficulty: 'easy' | 'hard';
  category: string;
  explanation: string;
}

export interface LeaderboardRecord {
  id: string;
  name: string;
  score: number;
  totalQuestions: number;
  correctCount: number;
  wrongCount: number;
  timeSpentSec: number;
  difficulty: 'easy' | 'hard';
  durationLimitMin: number;
  timestamp: number;
  avatarSeed: string;
}
