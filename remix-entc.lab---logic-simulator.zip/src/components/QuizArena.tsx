import React, { useState, useEffect, useRef } from 'react';
import { QuizGameQuestion, LeaderboardRecord } from '../types';
import { getTenQuizQuestions } from '../data/quizQuestions';
import { 
  Trophy, Timer, Zap, CheckCircle2, AlertTriangle, ArrowRight, 
  RotateCcw, Volume2, VolumeX, ShieldCheck, Play, Award, 
  BrainCircuit, ChevronRight, Sparkles, TrendingUp, TrendingDown 
} from 'lucide-react';

interface Props {
  onSaveToLeaderboard: (record: Omit<LeaderboardRecord, 'id' | 'timestamp'>) => void;
  onNavigateToLeaderboard: () => void;
  defaultDifficulty?: 'easy' | 'hard';
}

export const QuizArena: React.FC<Props> = ({ 
  onSaveToLeaderboard, 
  onNavigateToLeaderboard,
  defaultDifficulty = 'easy'
}) => {
  // Game Setup State
  const [gameState, setGameState] = useState<'lobby' | 'playing' | 'gameover'>('lobby');
  const [difficulty, setDifficulty] = useState<'easy' | 'hard'>(defaultDifficulty);
  const [durationLimitMin, setDurationLimitMin] = useState<1 | 10>(1);
  const [soundEnabled, setSoundEnabled] = useState(true);

  // Active Game State
  const [questions, setQuestions] = useState<QuizGameQuestion[]>([]);
  const [currentIdx, setCurrentIdx] = useState(0);
  const [selectedAnswers, setSelectedAnswers] = useState<Record<number, number>>({});
  const [submittedAnswers, setSubmittedAnswers] = useState<Record<number, boolean>>({});
  const [score, setScore] = useState(0);
  const [lastScoreDelta, setLastScoreDelta] = useState<{ amount: number; id: number } | null>(null);
  const [timeRemaining, setTimeRemaining] = useState(60);
  const [playerName, setPlayerName] = useState('ENTC Cadet');
  const [isSavedToLeaderboard, setIsSavedToLeaderboard] = useState(false);

  const timerRef = useRef<NodeJS.Timeout | null>(null);

  // Web Audio Synthesizer for retro game sound effects
  const playSound = (type: 'correct' | 'wrong' | 'start' | 'over') => {
    if (!soundEnabled) return;
    try {
      const AudioCtx = window.AudioContext || (window as any).webkitAudioContext;
      if (!AudioCtx) return;
      const ctx = new AudioCtx();
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.connect(gain);
      gain.connect(ctx.destination);

      const now = ctx.currentTime;
      if (type === 'correct') {
        osc.type = 'triangle';
        osc.frequency.setValueAtTime(523.25, now); // C5
        osc.frequency.exponentialRampToValueAtTime(880, now + 0.15); // A5
        gain.gain.setValueAtTime(0.18, now);
        gain.gain.exponentialRampToValueAtTime(0.01, now + 0.25);
        osc.start(now);
        osc.stop(now + 0.25);
      } else if (type === 'wrong') {
        osc.type = 'sawtooth';
        osc.frequency.setValueAtTime(220, now); // A3
        osc.frequency.exponentialRampToValueAtTime(110, now + 0.25); // A2
        gain.gain.setValueAtTime(0.2, now);
        gain.gain.exponentialRampToValueAtTime(0.01, now + 0.3);
        osc.start(now);
        osc.stop(now + 0.3);
      } else if (type === 'start') {
        osc.type = 'sine';
        osc.frequency.setValueAtTime(440, now);
        osc.frequency.exponentialRampToValueAtTime(659.25, now + 0.2);
        gain.gain.setValueAtTime(0.15, now);
        gain.gain.exponentialRampToValueAtTime(0.01, now + 0.3);
        osc.start(now);
        osc.stop(now + 0.3);
      } else if (type === 'over') {
        osc.type = 'sine';
        osc.frequency.setValueAtTime(392, now);
        osc.frequency.setValueAtTime(523.25, now + 0.15);
        gain.gain.setValueAtTime(0.2, now);
        gain.gain.exponentialRampToValueAtTime(0.01, now + 0.5);
        osc.start(now);
        osc.stop(now + 0.5);
      }
    } catch {
      // Audio might be blocked before user interaction
    }
  };

  // Start the Game
  const startGame = () => {
    const qList = getTenQuizQuestions(difficulty);
    setQuestions(qList);
    setCurrentIdx(0);
    setSelectedAnswers({});
    setSubmittedAnswers({});
    setScore(0);
    setLastScoreDelta(null);
    setIsSavedToLeaderboard(false);

    const initialSeconds = durationLimitMin * 60;
    setTimeRemaining(initialSeconds);
    setGameState('playing');
    playSound('start');
  };

  // Timer Tick
  useEffect(() => {
    if (gameState !== 'playing') {
      if (timerRef.current) clearInterval(timerRef.current);
      return;
    }

    timerRef.current = setInterval(() => {
      setTimeRemaining((prev) => {
        if (prev <= 1) {
          clearInterval(timerRef.current!);
          endGame();
          return 0;
        }
        return prev - 1;
      });
    }, 1000);

    return () => {
      if (timerRef.current) clearInterval(timerRef.current);
    };
  }, [gameState]);

  const endGame = () => {
    if (timerRef.current) clearInterval(timerRef.current);
    setGameState('gameover');
    playSound('over');
  };

  const handleSelectOption = (optionIndex: number) => {
    if (submittedAnswers[currentIdx]) return;
    setSelectedAnswers((prev) => ({ ...prev, [currentIdx]: optionIndex }));
  };

  const handleSubmitCurrentAnswer = () => {
    const choice = selectedAnswers[currentIdx];
    if (choice === undefined || submittedAnswers[currentIdx]) return;

    const currentQ = questions[currentIdx];
    const isCorrect = choice === currentQ.correctIndex;

    setSubmittedAnswers((prev) => ({ ...prev, [currentIdx]: true }));

    if (isCorrect) {
      setScore((prev) => prev + 1); // +1 point
      setLastScoreDelta({ amount: 1, id: Date.now() });
      playSound('correct');
    } else {
      setScore((prev) => prev - 2); // -2 points deduction!
      setLastScoreDelta({ amount: -2, id: Date.now() });
      playSound('wrong');
    }
  };

  const handleNextQuestion = () => {
    if (currentIdx + 1 < questions.length) {
      setCurrentIdx((prev) => prev + 1);
    } else {
      endGame();
    }
  };

  // Calculations for stats
  const totalAttempted = Object.keys(submittedAnswers).length;
  let correctCount = 0;
  let wrongCount = 0;

  Object.entries(submittedAnswers).forEach(([qIdxStr, isSub]) => {
    if (isSub) {
      const idx = parseInt(qIdxStr, 10);
      if (selectedAnswers[idx] === questions[idx]?.correctIndex) {
        correctCount++;
      } else {
        wrongCount++;
      }
    }
  });

  const accuracy = totalAttempted > 0 ? Math.round((correctCount / totalAttempted) * 100) : 0;
  const timeSpentSec = durationLimitMin * 60 - timeRemaining;

  const handleSaveScore = () => {
    if (isSavedToLeaderboard) return;
    onSaveToLeaderboard({
      name: playerName.trim() || 'ENTC Student',
      score,
      totalQuestions: 10,
      correctCount,
      wrongCount,
      timeSpentSec,
      difficulty,
      durationLimitMin,
      avatarSeed: Math.random().toString(36).substring(7)
    });
    setIsSavedToLeaderboard(true);
  };

  const currentQ = questions[currentIdx];
  const isCurrentSubmitted = submittedAnswers[currentIdx];
  const selectedChoice = selectedAnswers[currentIdx];

  // Helper format time
  const formatTime = (secs: number) => {
    const m = Math.floor(secs / 60);
    const s = secs % 60;
    return `${m}:${s < 10 ? '0' : ''}${s}`;
  };

  return (
    <div className="w-full max-w-4xl mx-auto h-full flex flex-col justify-center items-center py-4 relative z-10">
      
      {/* 1. LOBBY STATE */}
      {gameState === 'lobby' && (
        <div className="bg-slate-900/90 border border-slate-700/80 rounded-2xl p-6 sm:p-8 max-w-xl w-full shadow-2xl backdrop-blur-md animate-fadeIn">
          <div className="text-center mb-6">
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-cyan-950/70 border border-cyan-800/50 text-cyan-400 text-xs font-mono font-bold uppercase tracking-wider mb-3">
              <Zap size={14} /> High-Stakes Logic Arena
            </div>
            <h2 className="text-3xl font-extrabold text-white tracking-tight">
              ENTC Circuit Quiz Challenge
            </h2>
            <p className="text-slate-400 text-xs mt-2 leading-relaxed">
              10 fast-paced Boolean & logic circuit questions. Accuracy and speed determine your rank on the ENTC global leaderboard!
            </p>
          </div>

          {/* Game Rules Card */}
          <div className="bg-slate-950/80 border border-slate-800 rounded-xl p-4 mb-6">
            <h4 className="text-xs font-mono font-bold uppercase tracking-wider text-slate-400 mb-3 flex items-center gap-2">
              <ShieldCheck size={16} className="text-cyan-400" /> Official Scoring Rules
            </h4>
            <div className="grid grid-cols-2 gap-3 text-xs">
              <div className="bg-emerald-950/40 border border-emerald-500/30 rounded-lg p-2.5 flex items-center gap-2">
                <div className="w-7 h-7 rounded bg-emerald-500/20 text-emerald-400 flex items-center justify-center font-bold font-mono">
                  +1
                </div>
                <div>
                  <div className="font-bold text-emerald-300">Correct Answer</div>
                  <div className="text-[10px] text-slate-400">Awards +1 Point</div>
                </div>
              </div>
              <div className="bg-red-950/40 border border-red-500/30 rounded-lg p-2.5 flex items-center gap-2">
                <div className="w-7 h-7 rounded bg-red-500/20 text-red-400 flex items-center justify-center font-bold font-mono">
                  -2
                </div>
                <div>
                  <div className="font-bold text-red-300">Wrong Answer</div>
                  <div className="text-[10px] text-slate-400">Deducts 2 Points!</div>
                </div>
              </div>
            </div>
          </div>

          {/* Configuration */}
          <div className="space-y-4 mb-8">
            {/* Difficulty Selector */}
            <div>
              <label className="block text-xs font-semibold text-slate-300 uppercase tracking-wider mb-2">
                Select Difficulty Level:
              </label>
              <div className="grid grid-cols-2 gap-3">
                <button
                  type="button"
                  onClick={() => setDifficulty('easy')}
                  className={`p-3 rounded-xl border text-left transition-all cursor-pointer ${
                    difficulty === 'easy'
                      ? 'bg-cyan-950/80 border-cyan-500 text-cyan-200 ring-2 ring-cyan-500/30 shadow-lg'
                      : 'bg-slate-850 hover:bg-slate-800 border-slate-700/80 text-slate-400'
                  }`}
                >
                  <div className="font-bold text-sm">🟢 Easy Level</div>
                  <div className="text-[11px] text-slate-400 mt-0.5">
                    Gate logic, truth tables, basic TTL chips
                  </div>
                </button>
                <button
                  type="button"
                  onClick={() => setDifficulty('hard')}
                  className={`p-3 rounded-xl border text-left transition-all cursor-pointer ${
                    difficulty === 'hard'
                      ? 'bg-purple-950/80 border-purple-500 text-purple-200 ring-2 ring-purple-500/30 shadow-lg'
                      : 'bg-slate-850 hover:bg-slate-800 border-slate-700/80 text-slate-400'
                  }`}
                >
                  <div className="font-bold text-sm">🔥 Hard Level</div>
                  <div className="text-[11px] text-slate-400 mt-0.5">
                    Adders, De Morgan, K-Maps & propagation
                  </div>
                </button>
              </div>
            </div>

            {/* Duration Selector */}
            <div>
              <label className="block text-xs font-semibold text-slate-300 uppercase tracking-wider mb-2">
                Select Timer Duration:
              </label>
              <div className="grid grid-cols-2 gap-3">
                <button
                  type="button"
                  onClick={() => setDurationLimitMin(1)}
                  className={`p-3 rounded-xl border text-left transition-all cursor-pointer ${
                    durationLimitMin === 1
                      ? 'bg-amber-950/80 border-amber-500 text-amber-200 ring-2 ring-amber-500/30 shadow-lg'
                      : 'bg-slate-850 hover:bg-slate-800 border-slate-700/80 text-slate-400'
                  }`}
                >
                  <div className="font-bold text-sm flex items-center gap-1.5">
                    <Timer size={16} /> 1 Minute (Speed Blitz)
                  </div>
                  <div className="text-[11px] text-slate-400 mt-0.5">
                    Fast 6 seconds per question sprint!
                  </div>
                </button>
                <button
                  type="button"
                  onClick={() => setDurationLimitMin(10)}
                  className={`p-3 rounded-xl border text-left transition-all cursor-pointer ${
                    durationLimitMin === 10
                      ? 'bg-blue-950/80 border-blue-500 text-blue-200 ring-2 ring-blue-500/30 shadow-lg'
                      : 'bg-slate-850 hover:bg-slate-800 border-slate-700/80 text-slate-400'
                  }`}
                >
                  <div className="font-bold text-sm flex items-center gap-1.5">
                    <Timer size={16} /> 10 Minutes (Deep Study)
                  </div>
                  <div className="text-[11px] text-slate-400 mt-0.5">
                    Ample time for Boolean scratch calculation
                  </div>
                </button>
              </div>
            </div>
          </div>

          {/* Sound & Action */}
          <div className="flex items-center justify-between pt-4 border-t border-slate-800">
            <button
              onClick={() => setSoundEnabled(!soundEnabled)}
              className="text-xs text-slate-400 hover:text-slate-200 flex items-center gap-1.5 cursor-pointer"
            >
              {soundEnabled ? <Volume2 size={16} className="text-cyan-400" /> : <VolumeX size={16} />}
              <span>Sound: {soundEnabled ? 'ON' : 'OFF'}</span>
            </button>

            <button
              onClick={startGame}
              className="bg-gradient-to-r from-cyan-600 to-blue-600 hover:from-cyan-500 hover:to-blue-500 active:scale-95 text-white font-bold text-sm px-7 py-3 rounded-xl shadow-xl shadow-cyan-600/25 transition-all flex items-center gap-2 cursor-pointer"
            >
              <Play size={17} fill="currentColor" /> Start 10-Question Game
            </button>
          </div>
        </div>
      )}

      {/* 2. PLAYING STATE */}
      {gameState === 'playing' && currentQ && (
        <div className="bg-slate-900/90 border border-slate-700/80 rounded-2xl w-full max-w-2xl shadow-2xl backdrop-blur-md overflow-hidden flex flex-col animate-fadeIn">
          {/* Top Game Bar */}
          <div className="px-6 py-3.5 bg-slate-950/90 border-b border-slate-800 flex items-center justify-between">
            <div className="flex items-center gap-4">
              <span className="text-xs font-mono font-bold text-cyan-400 bg-cyan-950/80 border border-cyan-800/60 px-3 py-1 rounded-full">
                Question {currentIdx + 1} / 10
              </span>
              <span className="text-xs text-slate-400 uppercase tracking-wider font-semibold">
                {difficulty} mode
              </span>
            </div>

            {/* Live Score Counter with Animated Delta */}
            <div className="flex items-center gap-3">
              <div className="relative flex items-center gap-1 px-3 py-1 rounded-lg bg-slate-800 border border-slate-700">
                <span className="text-xs text-slate-400">Score:</span>
                <span
                  className={`font-mono font-bold text-sm ${
                    score > 0 ? 'text-emerald-400' : score < 0 ? 'text-red-400' : 'text-slate-200'
                  }`}
                >
                  {score > 0 ? `+${score}` : score}
                </span>

                {lastScoreDelta && (
                  <span
                    key={lastScoreDelta.id}
                    className={`absolute -top-3.5 right-0 text-xs font-mono font-bold animate-bounce ${
                      lastScoreDelta.amount > 0 ? 'text-emerald-400' : 'text-red-400'
                    }`}
                  >
                    {lastScoreDelta.amount > 0 ? `+${lastScoreDelta.amount}` : lastScoreDelta.amount}
                  </span>
                )}
              </div>

              {/* Countdown Timer */}
              <div
                className={`flex items-center gap-1.5 px-3 py-1 rounded-lg font-mono text-sm font-bold border transition-colors ${
                  timeRemaining <= 15
                    ? 'bg-red-950/80 border-red-500 text-red-300 animate-pulse'
                    : 'bg-slate-800 border-slate-700 text-cyan-300'
                }`}
              >
                <Timer size={15} />
                <span>{formatTime(timeRemaining)}</span>
              </div>
            </div>
          </div>

          {/* Time Progress Bar */}
          <div className="w-full bg-slate-800 h-1.5">
            <div
              className={`h-full transition-all duration-1000 ${
                timeRemaining <= 15
                  ? 'bg-red-500'
                  : 'bg-gradient-to-r from-cyan-500 via-blue-500 to-purple-500'
              }`}
              style={{ width: `${(timeRemaining / (durationLimitMin * 60)) * 100}%` }}
            />
          </div>

          {/* Question Body */}
          <div className="p-6 flex-1 flex flex-col justify-between">
            <div>
              <div className="text-[11px] font-mono text-cyan-400 uppercase tracking-widest mb-1.5">
                {currentQ.category}
              </div>
              <h3 className="text-xl font-bold text-white mb-6 leading-snug">
                {currentQ.question}
              </h3>

              {/* 4 Options */}
              <div className="space-y-3">
                {currentQ.options.map((opt, idx) => {
                  let btnStyle = 'bg-slate-850 hover:bg-slate-800 border-slate-700/80 text-slate-200';

                  if (selectedChoice === idx) {
                    btnStyle = 'bg-cyan-950/80 border-cyan-500 text-cyan-200 ring-2 ring-cyan-500/40';
                  }

                  if (isCurrentSubmitted) {
                    if (idx === currentQ.correctIndex) {
                      btnStyle = 'bg-emerald-950/90 border-emerald-500 text-emerald-200 ring-2 ring-emerald-500/50';
                    } else if (selectedChoice === idx && idx !== currentQ.correctIndex) {
                      btnStyle = 'bg-red-950/90 border-red-500 text-red-200 ring-2 ring-red-500/50';
                    } else {
                      btnStyle = 'bg-slate-900/50 border-slate-800 text-slate-500 opacity-50';
                    }
                  }

                  return (
                    <button
                      key={idx}
                      type="button"
                      disabled={isCurrentSubmitted}
                      onClick={() => handleSelectOption(idx)}
                      className={`w-full text-left p-4 rounded-xl border transition-all text-sm font-medium flex items-center justify-between cursor-pointer ${btnStyle}`}
                    >
                      <div className="flex items-center gap-3">
                        <span className="w-7 h-7 rounded-lg bg-slate-800 text-slate-300 font-mono font-bold text-xs flex items-center justify-center shrink-0">
                          {String.fromCharCode(65 + idx)}
                        </span>
                        <span className="text-sm font-semibold">{opt}</span>
                      </div>
                      {isCurrentSubmitted && idx === currentQ.correctIndex && (
                        <span className="flex items-center gap-1 text-emerald-400 font-bold text-xs">
                          <CheckCircle2 size={16} /> +1 pt
                        </span>
                      )}
                      {isCurrentSubmitted && selectedChoice === idx && idx !== currentQ.correctIndex && (
                        <span className="flex items-center gap-1 text-red-400 font-bold text-xs">
                          <AlertTriangle size={16} /> -2 pts
                        </span>
                      )}
                    </button>
                  );
                })}
              </div>

              {/* Instant feedback explanation */}
              {isCurrentSubmitted && (
                <div
                  className={`mt-5 p-3.5 rounded-xl border text-xs leading-relaxed animate-fadeIn ${
                    selectedChoice === currentQ.correctIndex
                      ? 'bg-emerald-950/40 border-emerald-500/30 text-emerald-300'
                      : 'bg-red-950/30 border-red-500/30 text-slate-300'
                  }`}
                >
                  <span className="font-bold block mb-1">
                    {selectedChoice === currentQ.correctIndex
                      ? '✅ Target Locked! (+1 point awarded)'
                      : '❌ Logic Error! (-2 points deducted)'}
                  </span>
                  <span>{currentQ.explanation}</span>
                </div>
              )}
            </div>

            {/* Bottom Actions */}
            <div className="mt-8 pt-4 border-t border-slate-800 flex items-center justify-between">
              <button
                onClick={endGame}
                className="text-xs text-slate-400 hover:text-red-400 transition-colors cursor-pointer"
              >
                Quit Game
              </button>

              <div>
                {!isCurrentSubmitted ? (
                  <button
                    onClick={handleSubmitCurrentAnswer}
                    disabled={selectedChoice === undefined}
                    className={`px-6 py-2.5 rounded-xl text-xs font-bold transition-all cursor-pointer ${
                      selectedChoice !== undefined
                        ? 'bg-gradient-to-r from-cyan-600 to-blue-600 hover:from-cyan-500 hover:to-blue-500 text-white shadow-lg shadow-cyan-600/20 active:scale-95'
                        : 'bg-slate-800 text-slate-500 cursor-not-allowed'
                    }`}
                  >
                    Lock In Answer
                  </button>
                ) : (
                  <button
                    onClick={handleNextQuestion}
                    className="bg-cyan-600 hover:bg-cyan-500 active:scale-95 text-white px-6 py-2.5 rounded-xl text-xs font-bold transition-all flex items-center gap-2 cursor-pointer shadow-lg shadow-cyan-600/20"
                  >
                    {currentIdx + 1 < questions.length ? 'Next Question' : 'View Final Score'}{' '}
                    <ArrowRight size={15} />
                  </button>
                )}
              </div>
            </div>
          </div>
        </div>
      )}

      {/* 3. GAME OVER / RESULT STATE */}
      {gameState === 'gameover' && (
        <div className="bg-slate-900/95 border border-slate-700/80 rounded-2xl p-6 sm:p-8 max-w-xl w-full shadow-2xl backdrop-blur-md animate-fadeIn text-center">
          <div className="w-16 h-16 rounded-2xl bg-gradient-to-tr from-amber-500 via-yellow-400 to-amber-600 flex items-center justify-center text-slate-950 mx-auto mb-4 shadow-xl shadow-amber-500/20">
            <Trophy size={36} />
          </div>

          <h3 className="text-2xl font-extrabold text-white">Quiz Challenge Complete!</h3>
          <p className="text-xs text-slate-400 mt-1">
            {difficulty.toUpperCase()} Level &bull; {durationLimitMin} Minute Format
          </p>

          {/* Scoreboard Big Badge */}
          <div className="my-6 bg-slate-950 p-6 rounded-2xl border border-slate-800 relative overflow-hidden">
            <div className="text-[11px] font-mono uppercase tracking-widest text-slate-400">
              Final Net Score (+1 / -2 Rule)
            </div>
            <div
              className={`text-5xl font-mono font-black mt-2 tracking-tight ${
                score > 0 ? 'text-emerald-400' : score < 0 ? 'text-red-400' : 'text-slate-300'
              }`}
            >
              {score > 0 ? `+${score}` : score}
            </div>

            <div className="grid grid-cols-3 gap-2 mt-5 pt-4 border-t border-slate-800/80 text-xs">
              <div>
                <span className="text-slate-500 block text-[10px] uppercase">Correct (+1)</span>
                <span className="font-mono font-bold text-emerald-400 text-sm">{correctCount}</span>
              </div>
              <div>
                <span className="text-slate-500 block text-[10px] uppercase">Wrong (-2)</span>
                <span className="font-mono font-bold text-red-400 text-sm">{wrongCount}</span>
              </div>
              <div>
                <span className="text-slate-500 block text-[10px] uppercase">Time Elapsed</span>
                <span className="font-mono font-bold text-cyan-400 text-sm">{formatTime(timeSpentSec)}</span>
              </div>
            </div>
          </div>

          {/* Leaderboard Submission Form */}
          <div className="bg-slate-850 p-4 rounded-xl border border-slate-700/70 mb-6 text-left">
            <label className="block text-xs font-bold text-slate-300 uppercase tracking-wider mb-2">
              Save Your Score to the Global Leaderboard:
            </label>
            <div className="flex gap-2">
              <input
                type="text"
                value={playerName}
                onChange={(e) => setPlayerName(e.target.value)}
                maxLength={20}
                placeholder="Enter your student name..."
                disabled={isSavedToLeaderboard}
                className="flex-1 bg-slate-950 border border-slate-700 rounded-lg px-3 py-2 text-xs text-white focus:outline-none focus:border-cyan-500 font-medium"
              />
              <button
                onClick={handleSaveScore}
                disabled={isSavedToLeaderboard}
                className={`px-4 py-2 rounded-lg text-xs font-bold transition-all cursor-pointer flex items-center gap-1.5 ${
                  isSavedToLeaderboard
                    ? 'bg-emerald-600/30 text-emerald-300 border border-emerald-500/40 cursor-default'
                    : 'bg-cyan-600 hover:bg-cyan-500 text-white shadow-lg active:scale-95'
                }`}
              >
                {isSavedToLeaderboard ? (
                  <>
                    <CheckCircle2 size={14} /> Saved!
                  </>
                ) : (
                  <>
                    <Award size={14} /> Save Rank
                  </>
                )}
              </button>
            </div>
          </div>

          {/* Actions */}
          <div className="flex items-center justify-center gap-3">
            <button
              onClick={startGame}
              className="bg-slate-800 hover:bg-slate-700 active:scale-95 text-slate-200 px-5 py-2.5 rounded-xl text-xs font-bold transition-all flex items-center gap-2 cursor-pointer border border-slate-700"
            >
              <RotateCcw size={15} /> Play Again
            </button>
            <button
              onClick={onNavigateToLeaderboard}
              className="bg-gradient-to-r from-amber-500 to-yellow-500 hover:from-amber-400 hover:to-yellow-400 active:scale-95 text-slate-950 font-bold px-6 py-2.5 rounded-xl text-xs transition-all flex items-center gap-1.5 cursor-pointer shadow-lg shadow-amber-500/20"
            >
              <Trophy size={15} /> View Leaderboard
            </button>
          </div>
        </div>
      )}
    </div>
  );
};
