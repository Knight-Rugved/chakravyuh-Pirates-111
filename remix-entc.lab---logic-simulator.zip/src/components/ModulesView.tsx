import React, { useState } from 'react';
import { 
  BookOpen, Sparkles, HelpCircle, Layers, ArrowRight, 
  TableProperties, Cpu, Award, Zap, Lightbulb, Play, 
  RotateCw, CheckCircle2, ChevronDown, ChevronUp, FileText 
} from 'lucide-react';
import { CHAPTERS_DATA } from '../data/chaptersData';
import { Chapter } from '../types';

interface Props {
  onLoadPreset: (eq: string) => void;
  onNavigateToSimulator: () => void;
  onOpenFlashcards: (chapterId: string) => void;
  onOpenQuiz: (chapterId: string) => void;
}

export const ModulesView: React.FC<Props> = ({
  onLoadPreset,
  onNavigateToSimulator,
  onOpenFlashcards,
  onOpenQuiz
}) => {
  // Mode toggle: 'theory' or 'eli7' (Explain Like I'm 7)
  const [learningMode, setLearningMode] = useState<'theory' | 'eli7'>('theory');
  const [expandedChapterId, setExpandedChapterId] = useState<string | null>('ch1_basic_gates');

  const toggleExpand = (id: string) => {
    setExpandedChapterId((prev) => (prev === id ? null : id));
  };

  return (
    <div className="max-w-5xl mx-auto w-full h-full overflow-y-auto custom-scrollbar pr-2 pb-16 relative z-10">
      {/* Header Banner */}
      <div className="bg-slate-900/90 border border-slate-800 rounded-3xl p-6 md:p-8 shadow-2xl mb-8 backdrop-blur-md">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-6">
          <div>
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-cyan-950/70 border border-cyan-800/50 text-cyan-400 text-xs font-mono font-bold uppercase tracking-wider mb-3">
              <BookOpen size={14} /> Comprehensive Curriculum
            </div>
            <h2 className="text-3xl font-extrabold text-white">
              ENTC Digital Logic Syllabus
            </h2>
            <p className="text-slate-400 text-xs sm:text-sm mt-1.5 max-w-xl leading-relaxed">
              From microscopic silicon switches to full arithmetic adders and space-grade voting computers. Every chapter includes rigorous engineering theory, child-friendly intuitive stories, interactive flashcards, and testing quizzes.
            </p>
          </div>

          {/* Mode Switcher: Theory vs ELI7 */}
          <div className="bg-slate-950 p-1.5 rounded-2xl border border-slate-800 flex items-center shrink-0 self-start md:self-center shadow-inner">
            <button
              onClick={() => setLearningMode('theory')}
              className={`px-4 py-2 rounded-xl text-xs font-bold transition-all flex items-center gap-2 cursor-pointer ${
                learningMode === 'theory'
                  ? 'bg-blue-600 text-white shadow-md'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              <Cpu size={14} /> Engineering Theory
            </button>
            <button
              onClick={() => setLearningMode('eli7')}
              className={`px-4 py-2 rounded-xl text-xs font-bold transition-all flex items-center gap-2 cursor-pointer ${
                learningMode === 'eli7'
                  ? 'bg-gradient-to-r from-amber-500 to-pink-500 text-slate-950 shadow-md font-extrabold'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              <Sparkles size={14} className={learningMode === 'eli7' ? 'text-slate-950' : 'text-amber-400'} />
              Explain Like I'm 7 (ELI7)
            </button>
          </div>
        </div>

        {/* Mode Description Bar */}
        <div className="mt-6 pt-4 border-t border-slate-800/80 flex items-center justify-between text-xs text-slate-400">
          <span className="flex items-center gap-2">
            <span className="w-2 h-2 rounded-full bg-emerald-400" />
            {learningMode === 'theory'
              ? 'Active: Rigorous Boolean proofs, TTL IC chip codes (74xx), truth tables & gate stage diagrams.'
              : 'Active: Fun real-world analogies, toy metaphors, opposite robots & storybook explanations!'}
          </span>
          <span className="font-mono text-cyan-400 hidden sm:inline">7 Chapters Available</span>
        </div>
      </div>

      {/* Chapters Accordion / Card List */}
      <div className="space-y-5">
        {CHAPTERS_DATA.map((ch) => {
          const isExpanded = expandedChapterId === ch.id;

          return (
            <div
              key={ch.id}
              className={`bg-slate-900/90 border rounded-2xl transition-all shadow-xl backdrop-blur-md overflow-hidden ${
                isExpanded ? 'border-cyan-500/60 ring-1 ring-cyan-500/20' : 'border-slate-800 hover:border-slate-700'
              }`}
            >
              {/* Chapter Card Header */}
              <div
                onClick={() => toggleExpand(ch.id)}
                className="p-5 sm:p-6 cursor-pointer flex flex-col sm:flex-row sm:items-center justify-between gap-4 select-none hover:bg-slate-850/50 transition-colors"
              >
                <div className="flex items-start sm:items-center gap-4">
                  <div className="w-12 h-12 rounded-xl bg-slate-800 border border-slate-700 flex items-center justify-center font-mono font-extrabold text-lg text-cyan-400 shrink-0 shadow-md">
                    0{ch.number}
                  </div>
                  <div>
                    <div className="flex flex-wrap items-center gap-2 mb-1">
                      <span className="text-[10px] font-bold uppercase tracking-wider text-cyan-400 bg-cyan-950/80 border border-cyan-800/50 px-2.5 py-0.5 rounded-full">
                        {ch.category}
                      </span>
                      <span className="text-[11px] text-slate-500 font-medium">
                        {ch.badge}
                      </span>
                    </div>
                    <h3 className="text-lg sm:text-xl font-bold text-white">
                      {ch.title}
                    </h3>
                    <p className="text-xs text-slate-400 mt-0.5">
                      {ch.subtitle}
                    </p>
                  </div>
                </div>

                {/* Chapter Quick Actions in Header */}
                <div className="flex items-center gap-2 self-end sm:self-center shrink-0">
                  <button
                    type="button"
                    onClick={(e) => {
                      e.stopPropagation();
                      onOpenFlashcards(ch.id);
                    }}
                    className="bg-purple-950/80 hover:bg-purple-900 text-purple-300 border border-purple-800/60 px-3 py-1.5 rounded-xl text-xs font-bold transition-all flex items-center gap-1.5 cursor-pointer shadow-sm"
                    title="Open 3D Flashcards for this chapter"
                  >
                    <RotateCw size={13} /> Flashcards
                  </button>

                  <button
                    type="button"
                    onClick={(e) => {
                      e.stopPropagation();
                      onOpenQuiz(ch.id);
                    }}
                    className="bg-amber-950/80 hover:bg-amber-900 text-amber-300 border border-amber-800/60 px-3 py-1.5 rounded-xl text-xs font-bold transition-all flex items-center gap-1.5 cursor-pointer shadow-sm"
                    title="Take Mini-Quiz for this chapter"
                  >
                    <Award size={13} /> Chapter Quiz
                  </button>

                  <button
                    type="button"
                    onClick={(e) => {
                      e.stopPropagation();
                      onLoadPreset(ch.defaultEquation);
                      onNavigateToSimulator();
                    }}
                    className="bg-blue-600 hover:bg-blue-500 text-white px-3.5 py-1.5 rounded-xl text-xs font-bold transition-all flex items-center gap-1.5 cursor-pointer shadow-md"
                    title="Load Boolean schematic directly into Logic Simulator"
                  >
                    <Play size={13} fill="currentColor" /> Simulate
                  </button>

                  <div className="text-slate-400 p-1">
                    {isExpanded ? <ChevronUp size={20} /> : <ChevronDown size={20} />}
                  </div>
                </div>
              </div>

              {/* Expanded Chapter Content */}
              {isExpanded && (
                <div className="px-5 pb-6 sm:px-6 pt-2 border-t border-slate-800/80 animate-fadeIn">
                  
                  {/* --- 1. ENGINEERING THEORY VIEW --- */}
                  {learningMode === 'theory' && (
                    <div className="space-y-5">
                      <div className="bg-slate-950/70 p-4 rounded-xl border border-slate-800 text-xs sm:text-sm text-slate-300 leading-relaxed">
                        <strong className="text-cyan-400 font-semibold block mb-1">Theoretical Overview:</strong>
                        {ch.theory.summary}
                      </div>

                      {/* Bullet points & Principles */}
                      <div>
                        <h4 className="text-xs font-mono font-bold text-slate-400 uppercase tracking-wider mb-2.5 flex items-center gap-1.5">
                          <Cpu size={14} className="text-cyan-400" /> Key Technical Principles
                        </h4>
                        <ul className="grid grid-cols-1 md:grid-cols-2 gap-2.5 text-xs text-slate-300">
                          {ch.theory.bulletPoints.map((pt, i) => (
                            <li
                              key={i}
                              className="bg-slate-850/80 p-3 rounded-xl border border-slate-700/60 flex items-start gap-2.5"
                            >
                              <span className="w-1.5 h-1.5 rounded-full bg-cyan-400 mt-1.5 shrink-0" />
                              <span>{pt}</span>
                            </li>
                          ))}
                        </ul>
                      </div>

                      {/* IC Chips & Formula */}
                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                        <div className="bg-slate-950 p-3.5 rounded-xl border border-slate-800">
                          <span className="text-[10px] font-mono uppercase tracking-wider text-slate-500 block mb-1">
                            Standard 74xx TTL IC Chips:
                          </span>
                          <div className="flex flex-wrap gap-2">
                            {ch.theory.icNumbers.map((ic, i) => (
                              <span
                                key={i}
                                className="bg-cyan-950 text-cyan-300 border border-cyan-800 px-2.5 py-1 rounded-lg text-xs font-mono font-bold"
                              >
                                {ic}
                              </span>
                            ))}
                          </div>
                        </div>

                        <div className="bg-slate-950 p-3.5 rounded-xl border border-slate-800">
                          <span className="text-[10px] font-mono uppercase tracking-wider text-slate-500 block mb-1">
                            Canonical Boolean Formula:
                          </span>
                          <code className="text-emerald-400 font-mono text-xs sm:text-sm font-bold block truncate">
                            {ch.theory.booleanFormula}
                          </code>
                        </div>
                      </div>

                      {/* Truth Table Preview */}
                      {ch.theory.truthTableHeaders.length > 0 && (
                        <div>
                          <h4 className="text-xs font-mono font-bold text-slate-400 uppercase tracking-wider mb-2.5 flex items-center gap-1.5">
                            <TableProperties size={14} className="text-emerald-400" /> Truth Table
                          </h4>
                          <div className="overflow-x-auto rounded-xl border border-slate-800 bg-slate-950">
                            <table className="w-full text-center text-xs font-mono">
                              <thead className="bg-slate-800/80 text-cyan-300 border-b border-slate-700">
                                <tr>
                                  {ch.theory.truthTableHeaders.map((head, i) => (
                                    <th key={i} className="py-2.5 px-3 font-bold">
                                      {head}
                                    </th>
                                  ))}
                                </tr>
                              </thead>
                              <tbody className="divide-y divide-slate-800/60">
                                {ch.theory.truthTableRows.map((row, rIdx) => (
                                  <tr key={rIdx} className="hover:bg-slate-900/50">
                                    {row.map((cell, cIdx) => (
                                      <td
                                        key={cIdx}
                                        className={`py-2 px-3 ${
                                          cell === 1 || cell === 'YES'
                                            ? 'text-emerald-400 font-bold'
                                            : cell === 0
                                            ? 'text-slate-400'
                                            : 'text-slate-200'
                                        }`}
                                      >
                                        {cell}
                                      </td>
                                    ))}
                                  </tr>
                                ))}
                              </tbody>
                            </table>
                          </div>
                        </div>
                      )}
                    </div>
                  )}

                  {/* --- 2. EXPLAIN LIKE I'M 7 YEARS OLD (ELI7) VIEW --- */}
                  {learningMode === 'eli7' && (
                    <div className="space-y-4 animate-fadeIn">
                      <div className="bg-gradient-to-br from-amber-950/30 via-slate-900 to-pink-950/30 border border-amber-500/40 p-5 rounded-2xl relative overflow-hidden">
                        <div className="flex items-center gap-2 text-amber-400 font-bold text-sm mb-3">
                          <Lightbulb size={18} />
                          <span>{ch.eli7.storyTitle}</span>
                        </div>

                        <div className="text-slate-200 text-xs sm:text-sm leading-relaxed whitespace-pre-line font-sans">
                          {ch.eli7.story}
                        </div>

                        {/* Key Takeaway & Fun Fact */}
                        <div className="mt-5 pt-4 border-t border-amber-500/20 grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
                          <div className="bg-slate-950/70 p-3 rounded-xl border border-amber-500/20">
                            <span className="text-[10px] font-mono uppercase tracking-wider text-amber-400 font-bold block mb-1">
                              🎯 Easy Rule to Remember:
                            </span>
                            <span className="text-slate-300 font-medium">
                              {ch.eli7.keyTakeaway}
                            </span>
                          </div>

                          <div className="bg-slate-950/70 p-3 rounded-xl border border-pink-500/20">
                            <span className="text-[10px] font-mono uppercase tracking-wider text-pink-400 font-bold block mb-1">
                              🚀 Mind-Blowing Fact:
                            </span>
                            <span className="text-slate-300 font-medium">
                              {ch.eli7.funFact}
                            </span>
                          </div>
                        </div>
                      </div>
                    </div>
                  )}

                  {/* Chapter Footer Actions */}
                  <div className="mt-5 pt-4 border-t border-slate-800/80 flex flex-wrap items-center justify-between gap-3">
                    <div className="flex items-center gap-2">
                      <button
                        onClick={() => onOpenFlashcards(ch.id)}
                        className="bg-slate-800 hover:bg-slate-700 active:scale-95 text-purple-300 border border-purple-800/50 px-4 py-2 rounded-xl text-xs font-bold transition-all flex items-center gap-1.5 cursor-pointer shadow-sm"
                      >
                        <RotateCw size={14} /> Practice 4 Flashcards
                      </button>

                      <button
                        onClick={() => onOpenQuiz(ch.id)}
                        className="bg-slate-800 hover:bg-slate-700 active:scale-95 text-amber-300 border border-amber-800/50 px-4 py-2 rounded-xl text-xs font-bold transition-all flex items-center gap-1.5 cursor-pointer shadow-sm"
                      >
                        <Award size={14} /> Test in Chapter Quiz
                      </button>
                    </div>

                    <button
                      onClick={() => {
                        onLoadPreset(ch.defaultEquation);
                        onNavigateToSimulator();
                      }}
                      className="bg-cyan-600 hover:bg-cyan-500 active:scale-95 text-white px-5 py-2 rounded-xl text-xs font-bold transition-all flex items-center gap-1.5 cursor-pointer shadow-lg shadow-cyan-600/20"
                    >
                      Load <code className="font-mono bg-cyan-900/60 px-1 rounded">{ch.defaultEquation}</code> in Simulator <ArrowRight size={14} />
                    </button>
                  </div>
                </div>
              )}
            </div>
          );
        })}
      </div>
    </div>
  );
};
