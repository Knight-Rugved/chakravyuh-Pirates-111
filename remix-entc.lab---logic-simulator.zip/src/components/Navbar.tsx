import React, { useState } from 'react';
import { 
  Cpu, Menu, X, BrainCircuit, BookOpen, Bot, User, 
  Trophy, Zap, Sparkles, ChevronRight, Home 
} from 'lucide-react';

export type ViewType = 'home' | 'simulator' | 'modules' | 'jarvis' | 'quiz' | 'leaderboard' | 'profile';

interface Props {
  currentView: ViewType;
  onNavigate: (view: ViewType) => void;
  quizHighScore?: number;
}

export const Navbar: React.FC<Props> = ({ currentView, onNavigate, quizHighScore = 0 }) => {
  const [isMenuOpen, setIsMenuOpen] = useState(false);

  const navItems: Array<{
    id: ViewType;
    label: string;
    icon: React.ReactNode;
    badge?: string;
    color: string;
  }> = [
    { id: 'home', label: 'Home Page', icon: <Home size={18} />, color: 'text-cyan-400' },
    { id: 'simulator', label: 'Logic Simulator', icon: <BrainCircuit size={18} />, color: 'text-blue-400' },
    { id: 'modules', label: 'Modules & Syllabus', icon: <BookOpen size={18} />, badge: '7 Ch.', color: 'text-emerald-400' },
    { id: 'jarvis', label: 'J.A.R.V.I.S. AI', icon: <Bot size={18} />, badge: 'AI Copilot', color: 'text-purple-400' },
    { id: 'quiz', label: 'Quiz Arena (10-Q)', icon: <Zap size={18} />, badge: '+1 / -2', color: 'text-amber-400' },
    { id: 'leaderboard', label: 'Leaderboard', icon: <Trophy size={18} />, color: 'text-yellow-400' },
    { id: 'profile', label: 'Student Profile', icon: <User size={18} />, color: 'text-slate-300' }
  ];

  const handleSelectView = (view: ViewType) => {
    onNavigate(view);
    setIsMenuOpen(false);
  };

  return (
    <>
      <header className="h-16 border-b border-slate-800/90 bg-slate-950/80 backdrop-blur-xl px-4 sm:px-6 flex items-center justify-between shrink-0 z-40 sticky top-0">
        {/* Left: Brand Logo & Title */}
        <div className="flex items-center gap-3">
          <button
            onClick={() => onNavigate('home')}
            className="flex items-center gap-2.5 text-left group cursor-pointer"
          >
            <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-cyan-600 to-blue-600 flex items-center justify-center text-white shadow-lg shadow-cyan-500/20 group-hover:scale-105 transition-transform">
              <Cpu size={22} className="text-white" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="font-extrabold text-white text-base tracking-tight font-mono">
                  ENTC<span className="text-cyan-400">.lab</span>
                </span>
                <span className="text-[10px] font-mono font-bold bg-cyan-950 text-cyan-400 border border-cyan-800 px-1.5 py-0.2 rounded">
                  v2.4
                </span>
              </div>
              <div className="text-[10px] text-slate-400 uppercase tracking-widest font-semibold hidden sm:block">
                Digital Logic Circuit Studio
              </div>
            </div>
          </button>
        </div>

        {/* Center: Desktop Nav Tabs */}
        <nav className="hidden lg:flex items-center gap-1 bg-slate-900/90 p-1 rounded-2xl border border-slate-800">
          {navItems.map((item) => (
            <button
              key={item.id}
              onClick={() => onNavigate(item.id)}
              className={`flex items-center gap-2 px-3 py-1.5 rounded-xl text-xs font-bold transition-all cursor-pointer ${
                currentView === item.id
                  ? 'bg-cyan-950 text-cyan-300 border border-cyan-800/80 shadow-sm'
                  : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/60'
              }`}
            >
              <span className={item.color}>{item.icon}</span>
              <span>{item.label}</span>
              {item.badge && (
                <span className="text-[9px] font-mono px-1.5 py-0.2 rounded-full bg-slate-800 text-slate-300">
                  {item.badge}
                </span>
              )}
            </button>
          ))}
        </nav>

        {/* Right: Quick Action & Menu Button */}
        <div className="flex items-center gap-2.5">
          {/* Quick Quiz / High Score indicator */}
          <button
            onClick={() => onNavigate('quiz')}
            className="hidden sm:flex items-center gap-1.5 bg-amber-950/60 border border-amber-500/40 hover:bg-amber-900/40 px-3 py-1.5 rounded-xl text-xs text-amber-300 font-mono font-bold transition-colors cursor-pointer"
            title="Start 10-Question Quiz Game"
          >
            <Zap size={14} className="text-amber-400" />
            <span>Quiz Game</span>
            {quizHighScore !== undefined && (
              <span className="bg-amber-900/80 px-1.5 py-0.5 rounded text-[10px] text-amber-200">
                Best: {quizHighScore > 0 ? `+${quizHighScore}` : quizHighScore}
              </span>
            )}
          </button>

          {/* Quick J.A.R.V.I.S. Copilot Button */}
          <button
            onClick={() => onNavigate('jarvis')}
            className="hidden md:flex items-center gap-1.5 bg-purple-950/60 border border-purple-500/40 hover:bg-purple-900/40 px-3 py-1.5 rounded-xl text-xs text-purple-300 font-mono font-bold transition-colors cursor-pointer"
          >
            <Bot size={14} className="text-purple-400" />
            <span>J.A.R.V.I.S.</span>
          </button>

          {/* Primary MENU BUTTON */}
          <button
            onClick={() => setIsMenuOpen(!isMenuOpen)}
            className="bg-slate-800 hover:bg-slate-700 active:scale-95 text-slate-200 border border-slate-700 px-3.5 py-2 rounded-xl text-xs font-bold transition-all flex items-center gap-2 cursor-pointer shadow-md"
            aria-label="Toggle navigation menu"
          >
            {isMenuOpen ? <X size={17} /> : <Menu size={17} />}
            <span>Menu</span>
          </button>
        </div>
      </header>

      {/* DROPDOWN / DRAWER MENU MODAL */}
      {isMenuOpen && (
        <div className="fixed inset-0 z-50 bg-slate-950/80 backdrop-blur-md flex justify-end animate-fadeIn">
          {/* Background backdrop click to close */}
          <div
            className="flex-1"
            onClick={() => setIsMenuOpen(false)}
          />

          {/* Drawer container */}
          <div className="w-80 sm:w-96 bg-slate-900 border-l border-slate-800 h-full p-6 flex flex-col justify-between shadow-2xl relative z-10 overflow-y-auto custom-scrollbar">
            <div>
              {/* Header */}
              <div className="flex items-center justify-between pb-5 border-b border-slate-800">
                <div className="flex items-center gap-2.5">
                  <div className="w-9 h-9 rounded-xl bg-cyan-950 border border-cyan-800 flex items-center justify-center text-cyan-400">
                    <Cpu size={20} />
                  </div>
                  <div>
                    <h3 className="font-bold text-white text-sm">ENTC Studio Menu</h3>
                    <p className="text-[10px] text-slate-400">Navigate all workbench apps</p>
                  </div>
                </div>

                <button
                  onClick={() => setIsMenuOpen(false)}
                  className="p-1.5 text-slate-400 hover:text-white hover:bg-slate-800 rounded-lg transition-colors cursor-pointer"
                >
                  <X size={18} />
                </button>
              </div>

              {/* Menu Navigation Options */}
              <div className="py-4 space-y-1.5">
                <div className="text-[10px] font-mono uppercase tracking-wider text-slate-500 font-bold px-3 py-1">
                  Primary Platforms
                </div>

                {navItems.map((item) => (
                  <button
                    key={item.id}
                    onClick={() => handleSelectView(item.id)}
                    className={`w-full flex items-center justify-between p-3 rounded-xl text-xs font-bold transition-all text-left cursor-pointer border ${
                      currentView === item.id
                        ? 'bg-cyan-950/80 text-cyan-300 border-cyan-800/80 shadow-md ring-1 ring-cyan-500/20'
                        : 'bg-slate-850 hover:bg-slate-800 text-slate-300 border-slate-800/80 hover:border-slate-700'
                    }`}
                  >
                    <div className="flex items-center gap-3">
                      <span className={`p-1.5 rounded-lg bg-slate-800 ${item.color}`}>
                        {item.icon}
                      </span>
                      <span>{item.label}</span>
                    </div>

                    <div className="flex items-center gap-2">
                      {item.badge && (
                        <span className="text-[10px] font-mono px-2 py-0.5 rounded-full bg-slate-800 text-slate-300 border border-slate-700">
                          {item.badge}
                        </span>
                      )}
                      <ChevronRight size={14} className="text-slate-500" />
                    </div>
                  </button>
                ))}
              </div>

              {/* Quick Jump to Leaderboard & Profile */}
              <div className="pt-2 border-t border-slate-800 space-y-2">
                <div className="text-[10px] font-mono uppercase tracking-wider text-slate-500 font-bold px-3">
                  Quick Access
                </div>

                <div className="grid grid-cols-2 gap-2">
                  <button
                    onClick={() => handleSelectView('leaderboard')}
                    className="p-3 bg-slate-950 hover:bg-slate-800 rounded-xl border border-slate-800 text-left transition-colors cursor-pointer"
                  >
                    <Trophy size={16} className="text-amber-400 mb-1" />
                    <div className="text-xs font-bold text-slate-200">Leaderboard</div>
                    <div className="text-[10px] text-slate-500">Global Ranks</div>
                  </button>

                  <button
                    onClick={() => handleSelectView('profile')}
                    className="p-3 bg-slate-950 hover:bg-slate-800 rounded-xl border border-slate-800 text-left transition-colors cursor-pointer"
                  >
                    <User size={16} className="text-blue-400 mb-1" />
                    <div className="text-xs font-bold text-slate-200">Profile</div>
                    <div className="text-[10px] text-slate-500">Badges & Stats</div>
                  </button>
                </div>
              </div>
            </div>

            {/* Footer */}
            <div className="pt-4 border-t border-slate-800 text-[11px] text-slate-500 font-mono">
              <div>Department of ENTC</div>
              <div className="text-slate-600 mt-0.5">Connected to J.A.R.V.I.S. AI Core</div>
            </div>
          </div>
        </div>
      )}
    </>
  );
};
