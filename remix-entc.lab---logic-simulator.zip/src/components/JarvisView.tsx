import React, { useState } from 'react';
import { 
  Bot, Send, Sparkles, Wand2, BrainCircuit, TableProperties, 
  Cpu, Zap, ArrowRight, CheckCircle2, RefreshCw, Terminal, Lightbulb 
} from 'lucide-react';
import { ChatMessage } from '../types';

interface Props {
  onLoadEquationToSimulator: (eq: string) => void;
  onNavigateToSimulator: () => void;
}

export const JarvisView: React.FC<Props> = ({ 
  onLoadEquationToSimulator, 
  onNavigateToSimulator 
}) => {
  const [messages, setMessages] = useState<ChatMessage[]>([
    {
      id: 'jarvis_init',
      sender: 'ai',
      text: "Greetings, Cadet. I am **J.A.R.V.I.S.** (Joint Advanced Real-time Virtual Intelligence Simulator), your ENTC Digital Circuit Co-pilot.\n\nI can minimize Boolean equations via Karnaugh Maps, prove De Morgan equivalences, optimize universal NAND-only architectures, and analyze gate propagation delays. How can I assist your laboratory research today?",
      timestamp: 'Active'
    }
  ]);
  const [input, setInput] = useState('');
  const [isProcessing, setIsProcessing] = useState(false);
  const [activeEquation, setActiveEquation] = useState('Y = A*B + B*C + A*C');

  const handleSend = (textToSend?: string) => {
    const query = textToSend || input;
    if (!query.trim()) return;

    const userMsg: ChatMessage = {
      id: Date.now().toString(),
      sender: 'user',
      text: query,
      timestamp: 'Now'
    };

    setMessages((prev) => [...prev, userMsg]);
    if (!textToSend) setInput('');
    setIsProcessing(true);

    setTimeout(() => {
      let reply = '';
      const q = query.toLowerCase();

      if (q.includes('k-map') || q.includes('karnaugh') || q.includes('majority')) {
        reply = `🧠 **J.A.R.V.I.S. K-Map Matrix Analysis**:\n\n` +
          `• Target Expression: \`Y = AB + BC + AC\`\n` +
          `• Number of Variables: 3 (A, B, C) -> 2³ = 8 Cells\n` +
          `• Minterm Expansion: Σm(3, 5, 6, 7)\n\n` +
          `| BC \\ A | 0 (A') | 1 (A) |\n` +
          `|--------|--------|-------|\n` +
          `| 00     |   0    |   0   |\n` +
          `| 01     |   0    |   1   | -> m(5)\n` +
          `| 11     |   1    |   1   | -> m(3), m(7)\n` +
          `| 10     |   0    |   1   | -> m(6)\n\n` +
          `**Grouping Strategy**:\n` +
          `1. Group 1 [m(3,7)]: Eliminates A -> yields **BC**\n` +
          `2. Group 2 [m(5,7)]: Eliminates B -> yields **AC**\n` +
          `3. Group 3 [m(6,7)]: Eliminates C -> yields **AB**\n\n` +
          `✅ **Minimized SOP Form:** \`Y = AB + BC + AC\` (Minimal Consensus Form).`;
      } else if (q.includes('universal') || q.includes('nand only')) {
        reply = `⚡ **Universal NAND Gate Synthesis Protocol**:\n\n` +
          `Converting \`Y = A*B + C\` using only 2-input NAND gates:\n\n` +
          `1. Apply double complement: \`Y = ~(~((A · B) + C))\`\n` +
          `2. Apply De Morgan's Law: \`Y = ~((~(A · B)) · ~C)\`\n` +
          `3. Invert C using NAND: \`C_inv = ~(C · C)\`\n` +
          `4. Calculate NAND(A, B): \`N1 = ~(A · B)\`\n` +
          `5. Feed N1 and C_inv into final NAND: \`Y = ~(N1 · C_inv)\`\n\n` +
          `💡 **Silicon Efficiency**: Total required chips = 1x **IC 7400** (Quad 2-input NAND), saving 65% PCB trace area.`;
      } else if (q.includes('full adder') || q.includes('adder')) {
        reply = `🔬 **Full Adder Architectural Specification**:\n\n` +
          `• Input Bits: \`A\`, \`B\`, \`C_in\` (Carry-In from lower stage)\n` +
          `• Sum Output: \`Sum = A ⊕ B ⊕ C_in\` (Odd Parity)\n` +
          `• Carry Output: \`C_out = A·B + C_in·(A ⊕ B)\`\n\n` +
          `**Hardware Implementation**:\n` +
          `• 2x Half Adders + 1x OR gate\n` +
          `• Propagation Delay: 2 gate delays (XOR) for Sum, 2 gate delays (AND+OR) for Carry.\n\n` +
          `Ready to test this directly on the simulator canvas? Click "Load into Simulator" below.`;
      } else if (q.includes('de morgan') || q.includes('simplify')) {
        reply = `📐 **De Morgan's Theorem Simplifier**:\n\n` +
          `Rule 1: \`~(A · B) = ~A + ~B\` (NAND equivalence)\n` +
          `Rule 2: \`~(A + B) = ~A · ~B\` (NOR equivalence)\n\n` +
          `**Memory Trick**: *"Break the bar, change the operator!"*\n` +
          `If you have \`~(A + B · C)\`, grouping gives: \`~A · ~(B · C) = ~A · (~B + ~C) = ~A·~B + ~A·~C\`.`;
      } else {
        reply = `⚡ **J.A.R.V.I.S. Diagnostic Report**:\n\n` +
          `Query: "${query}"\n` +
          `Active logic circuit target: \`${activeEquation}\`\n\n` +
          `• Signal Integrity: Nominal (5.0V CMOS/TTL)\n` +
          `• Logic Families: Compatible with standard 74xx TTL logic\n` +
          `• Advice: Try asking me to "Generate K-Map", "Convert to NAND-only", or "Explain Full Adder equations".`;
      }

      setMessages((prev) => [
        ...prev,
        {
          id: (Date.now() + 1).toString(),
          sender: 'ai',
          text: reply,
          timestamp: 'Just now'
        }
      ]);
      setIsProcessing(false);
    }, 500);
  };

  return (
    <div className="max-w-5xl mx-auto w-full h-full flex flex-col gap-4 relative z-10 pb-6">
      {/* JARVIS Top HUD */}
      <div className="bg-slate-900/90 border border-slate-800 rounded-2xl p-5 shadow-2xl backdrop-blur-md flex items-center justify-between">
        <div className="flex items-center gap-4">
          <div className="relative">
            <div className="w-12 h-12 rounded-xl bg-gradient-to-tr from-cyan-600 via-blue-600 to-cyan-400 flex items-center justify-center text-white shadow-lg shadow-cyan-500/30">
              <Bot size={26} />
            </div>
            <span className="absolute -bottom-1 -right-1 w-3.5 h-3.5 bg-emerald-500 rounded-full border-2 border-slate-900 animate-pulse" />
          </div>

          <div>
            <div className="flex items-center gap-2">
              <h2 className="text-xl font-bold text-white tracking-wide font-mono">
                J.A.R.V.I.S.
              </h2>
              <span className="text-[10px] font-bold uppercase tracking-wider bg-cyan-950 text-cyan-400 border border-cyan-800 px-2 py-0.5 rounded-full font-mono">
                v4.8 Logic AI Core
              </span>
            </div>
            <p className="text-xs text-slate-400">
              Joint Advanced Real-time Virtual Intelligence Simulator for ENTC
            </p>
          </div>
        </div>

        {/* Quick Simulator Link */}
        <div className="hidden sm:flex items-center gap-2">
          <button
            onClick={() => {
              onLoadEquationToSimulator(activeEquation);
              onNavigateToSimulator();
            }}
            className="bg-blue-600 hover:bg-blue-500 active:scale-95 text-white px-4 py-2 rounded-xl text-xs font-bold transition-all flex items-center gap-2 cursor-pointer shadow-md shadow-blue-600/20"
          >
            <Cpu size={15} /> Load Circuit in Simulator <ArrowRight size={14} />
          </button>
        </div>
      </div>

      {/* Main Terminal Chat Display */}
      <div className="flex-1 bg-slate-900/95 border border-slate-800 rounded-2xl flex flex-col shadow-2xl overflow-hidden backdrop-blur-md">
        {/* Terminal Header */}
        <div className="px-5 py-3 bg-slate-950/90 border-b border-slate-800 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <span className="w-2.5 h-2.5 rounded-full bg-red-500/80" />
            <span className="w-2.5 h-2.5 rounded-full bg-amber-500/80" />
            <span className="w-2.5 h-2.5 rounded-full bg-emerald-500/80" />
            <span className="text-xs font-mono text-slate-400 ml-2">
              jarvis@entc-lab:~/neural-copilot
            </span>
          </div>

          <div className="text-[11px] font-mono text-cyan-400 flex items-center gap-1.5">
            <Zap size={13} /> Real-Time AST Evaluation
          </div>
        </div>

        {/* Messages Scroll Area */}
        <div className="flex-1 p-5 overflow-y-auto custom-scrollbar space-y-4">
          {messages.map((m) => (
            <div
              key={m.id}
              className={`flex flex-col ${
                m.sender === 'user' ? 'items-end' : 'items-start'
              }`}
            >
              <div className="flex items-center gap-1.5 mb-1 px-1">
                <span className="text-[10px] font-mono font-bold uppercase tracking-wider text-slate-400">
                  {m.sender === 'user' ? 'Cadet Student' : 'J.A.R.V.I.S.'}
                </span>
                <span className="text-[9px] text-slate-600">&bull; {m.timestamp}</span>
              </div>

              <div
                className={`max-w-2xl p-4 rounded-2xl text-xs sm:text-sm leading-relaxed ${
                  m.sender === 'user'
                    ? 'bg-gradient-to-r from-blue-600 to-cyan-600 text-white rounded-tr-none shadow-md'
                    : 'bg-slate-950 border border-slate-800 text-slate-200 rounded-tl-none font-sans shadow-lg'
                }`}
              >
                <div className="whitespace-pre-wrap font-sans">{m.text}</div>
              </div>
            </div>
          ))}

          {isProcessing && (
            <div className="flex items-center gap-2 text-xs font-mono text-cyan-400 bg-slate-950 p-3 rounded-xl border border-slate-800 w-fit">
              <RefreshCw size={14} className="animate-spin text-cyan-400" />
              <span>J.A.R.V.I.S. is synthesizing AST minterms...</span>
            </div>
          )}
        </div>

        {/* Quick Suggested Prompts */}
        <div className="p-3 bg-slate-950/80 border-t border-slate-800 flex flex-wrap gap-2">
          <span className="text-[10px] font-mono uppercase tracking-wider text-slate-500 flex items-center gap-1 mr-1">
            <Sparkles size={12} className="text-cyan-400" /> Quick Queries:
          </span>
          <button
            onClick={() => handleSend('Generate Karnaugh Map for Majority Gate Y = AB + BC + AC')}
            className="text-xs bg-slate-900 hover:bg-slate-800 border border-slate-700/80 text-cyan-300 px-3 py-1 rounded-lg transition-colors cursor-pointer"
          >
            📊 Majority K-Map
          </button>
          <button
            onClick={() => handleSend('How to implement Y = A*B + C using only NAND gates?')}
            className="text-xs bg-slate-900 hover:bg-slate-800 border border-slate-700/80 text-emerald-300 px-3 py-1 rounded-lg transition-colors cursor-pointer"
          >
            ⚡ NAND-Only Synthesis
          </button>
          <button
            onClick={() => handleSend('Explain Full Adder Sum and Carry equations and gates')}
            className="text-xs bg-slate-900 hover:bg-slate-800 border border-slate-700/80 text-purple-300 px-3 py-1 rounded-lg transition-colors cursor-pointer"
          >
            ➕ Full Adder Gates
          </button>
          <button
            onClick={() => handleSend('Explain De Morgan theorem with everyday examples')}
            className="text-xs bg-slate-900 hover:bg-slate-800 border border-slate-700/80 text-amber-300 px-3 py-1 rounded-lg transition-colors cursor-pointer"
          >
            💡 De Morgan Laws
          </button>
        </div>

        {/* Input Bar */}
        <div className="p-4 bg-slate-950 border-t border-slate-800">
          <form
            onSubmit={(e) => {
              e.preventDefault();
              handleSend();
            }}
            className="flex gap-2"
          >
            <div className="relative flex-1">
              <input
                type="text"
                value={input}
                onChange={(e) => setInput(e.target.value)}
                placeholder="Ask J.A.R.V.I.S. anything about circuits, equations, or K-Maps..."
                className="w-full bg-slate-900 border border-slate-700 rounded-xl px-4 py-3 text-xs sm:text-sm text-slate-100 placeholder-slate-500 focus:outline-none focus:border-cyan-500 focus:ring-1 focus:ring-cyan-500 transition-all font-sans"
              />
            </div>
            <button
              type="submit"
              disabled={!input.trim() || isProcessing}
              className={`px-5 py-3 rounded-xl font-bold text-xs sm:text-sm transition-all flex items-center gap-2 cursor-pointer ${
                input.trim() && !isProcessing
                  ? 'bg-gradient-to-r from-cyan-600 to-blue-600 hover:from-cyan-500 hover:to-blue-500 text-white shadow-lg shadow-cyan-600/20 active:scale-95'
                  : 'bg-slate-800 text-slate-500 cursor-not-allowed'
              }`}
            >
              <Send size={16} />
              <span className="hidden sm:inline">Ask J.A.R.V.I.S.</span>
            </button>
          </form>
        </div>
      </div>
    </div>
  );
};
