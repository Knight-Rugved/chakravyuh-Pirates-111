import React, { useState } from 'react';
import { ChapterQuizQuestion } from '../types';
import { X, CheckCircle2, AlertCircle, ArrowRight, RotateCcw, Trophy, Sparkles } from 'lucide-react';

interface Props {
  chapterTitle: string;
  chapterNumber: number;
  questions: ChapterQuizQuestion[];
  onClose: () => void;
  onQuizCompleted?: (score: number, total: number) => void;
}

export const ChapterQuizModal: React.FC<Props> = ({
  chapterTitle,
  chapterNumber,
  questions,
  onClose,
  onQuizCompleted
}) => {
  const [currentIndex, setCurrentIndex] = useState(0);
  const [selectedOption, setSelectedOption] = useState<number | null>(null);
  const [isAnswerSubmitted, setIsAnswerSubmitted] = useState(false);
  const [score, setScore] = useState(0);
  const [isFinished, setIsFinished] = useState(false);

  const currentQ = questions[currentIndex];

  const handleSelectOption = (idx: number) => {
    if (isAnswerSubmitted) return;
    setSelectedOption(idx);
  };

  const handleSubmitAnswer = () => {
    if (selectedOption === null) return;
    setIsAnswerSubmitted(true);
    if (selectedOption === currentQ.correctIndex) {
      setScore((prev) => prev + 1);
    }
  };

  const handleNext = () => {
    if (currentIndex + 1 < questions.length) {
      setCurrentIndex((prev) => prev + 1);
      setSelectedOption(null);
      setIsAnswerSubmitted(false);
    } else {
      setIsFinished(true);
      onQuizCompleted?.(score + (selectedOption === currentQ.correctIndex ? 1 : 0), questions.length);
    }
  };

  const handleRestart = () => {
    setCurrentIndex(0);
    setSelectedOption(null);
    setIsAnswerSubmitted(false);
    setScore(0);
    setIsFinished(false);
  };

  return (
    <div className="fixed inset-0 z-50 bg-slate-950/85 backdrop-blur-md flex items-center justify-center p-4 sm:p-6 animate-fadeIn">
      <div className="bg-slate-900 border border-slate-700/80 rounded-2xl w-full max-w-xl shadow-2xl flex flex-col overflow-hidden">
        {/* Header */}
        <div className="px-6 py-4 bg-slate-950/80 border-b border-slate-800 flex items-center justify-between">
          <div>
            <span className="text-[10px] font-bold uppercase tracking-wider text-purple-400 bg-purple-950/60 border border-purple-800/40 px-2 py-0.5 rounded-full">
              Chapter {chapterNumber} Practice Quiz
            </span>
            <h3 className="text-base font-bold text-white mt-1 truncate max-w-sm">
              {chapterTitle}
            </h3>
          </div>
          <button
            onClick={onClose}
            className="p-2 text-slate-400 hover:text-white hover:bg-slate-800 rounded-lg transition-colors cursor-pointer"
          >
            <X size={20} />
          </button>
        </div>

        {/* Progress Bar */}
        <div className="w-full bg-slate-800 h-1">
          <div
            className="bg-gradient-to-r from-purple-500 to-cyan-500 h-1 transition-all duration-300"
            style={{ width: `${((currentIndex + 1) / questions.length) * 100}%` }}
          />
        </div>

        {/* Content */}
        {!isFinished ? (
          <div className="p-6 flex-1 flex flex-col justify-between">
            <div>
              <div className="flex items-center justify-between text-xs text-slate-400 mb-4">
                <span className="font-semibold text-slate-300">
                  Question {currentIndex + 1} of {questions.length}
                </span>
                <span className="font-mono text-cyan-400">Score: {score}</span>
              </div>

              <h4 className="text-lg font-bold text-slate-100 mb-5 leading-snug">
                {currentQ.question}
              </h4>

              <div className="space-y-3">
                {currentQ.options.map((opt, idx) => {
                  let optStyle = 'bg-slate-850 hover:bg-slate-800 border-slate-700/80 text-slate-200';
                  if (selectedOption === idx) {
                    optStyle = 'bg-cyan-950/60 border-cyan-500 text-cyan-300 ring-1 ring-cyan-500/50';
                  }

                  if (isAnswerSubmitted) {
                    if (idx === currentQ.correctIndex) {
                      optStyle = 'bg-emerald-950/80 border-emerald-500 text-emerald-300 ring-2 ring-emerald-500/40';
                    } else if (selectedOption === idx && idx !== currentQ.correctIndex) {
                      optStyle = 'bg-red-950/80 border-red-500 text-red-300 ring-1 ring-red-500/40';
                    } else {
                      optStyle = 'bg-slate-900/60 border-slate-800 text-slate-500 opacity-60';
                    }
                  }

                  return (
                    <button
                      key={idx}
                      type="button"
                      disabled={isAnswerSubmitted}
                      onClick={() => handleSelectOption(idx)}
                      className={`w-full text-left p-3.5 rounded-xl border transition-all text-sm font-medium flex items-center justify-between cursor-pointer ${optStyle}`}
                    >
                      <div className="flex items-center gap-3">
                        <span className="w-6 h-6 rounded-lg bg-slate-800 text-slate-400 text-xs font-mono font-bold flex items-center justify-center shrink-0">
                          {String.fromCharCode(65 + idx)}
                        </span>
                        <span>{opt}</span>
                      </div>
                      {isAnswerSubmitted && idx === currentQ.correctIndex && (
                        <CheckCircle2 size={18} className="text-emerald-400 shrink-0" />
                      )}
                      {isAnswerSubmitted && selectedOption === idx && idx !== currentQ.correctIndex && (
                        <AlertCircle size={18} className="text-red-400 shrink-0" />
                      )}
                    </button>
                  );
                })}
              </div>

              {/* Explanation note when answered */}
              {isAnswerSubmitted && (
                <div
                  className={`mt-4 p-3.5 rounded-xl text-xs leading-relaxed border ${
                    selectedOption === currentQ.correctIndex
                      ? 'bg-emerald-950/40 border-emerald-600/30 text-emerald-300'
                      : 'bg-red-950/30 border-red-600/30 text-slate-300'
                  }`}
                >
                  <p className="font-bold mb-1 flex items-center gap-1.5">
                    {selectedOption === currentQ.correctIndex ? (
                      <>
                        <CheckCircle2 size={14} className="text-emerald-400" /> Correct!
                      </>
                    ) : (
                      <>
                        <AlertCircle size={14} className="text-red-400" /> Incorrect
                      </>
                    )}
                  </p>
                  <p className="text-slate-300">{currentQ.explanation}</p>
                </div>
              )}
            </div>

            {/* Actions */}
            <div className="mt-6 pt-4 border-t border-slate-800 flex justify-end gap-3">
              {!isAnswerSubmitted ? (
                <button
                  onClick={handleSubmitAnswer}
                  disabled={selectedOption === null}
                  className={`px-5 py-2.5 rounded-xl text-xs font-bold transition-all cursor-pointer ${
                    selectedOption !== null
                      ? 'bg-purple-600 hover:bg-purple-500 text-white shadow-lg shadow-purple-600/20 active:scale-95'
                      : 'bg-slate-800 text-slate-500 cursor-not-allowed'
                  }`}
                >
                  Submit Answer
                </button>
              ) : (
                <button
                  onClick={handleNext}
                  className="bg-cyan-600 hover:bg-cyan-500 active:scale-95 text-white px-5 py-2.5 rounded-xl text-xs font-bold transition-all flex items-center gap-2 cursor-pointer shadow-lg shadow-cyan-600/20"
                >
                  {currentIndex + 1 < questions.length ? 'Next Question' : 'View Summary'}{' '}
                  <ArrowRight size={15} />
                </button>
              )}
            </div>
          </div>
        ) : (
          /* Finished State */
          <div className="p-8 text-center flex flex-col items-center justify-center">
            <div className="w-16 h-16 rounded-2xl bg-gradient-to-tr from-purple-600 to-cyan-500 flex items-center justify-center text-white mb-4 shadow-xl shadow-cyan-500/20">
              <Trophy size={32} />
            </div>

            <h4 className="text-2xl font-bold text-white mb-1">Chapter Quiz Completed!</h4>
            <p className="text-slate-400 text-xs mb-5">
              Review of {chapterTitle}
            </p>

            <div className="bg-slate-950 p-4 rounded-xl border border-slate-800 w-full max-w-xs mb-6">
              <div className="text-3xl font-mono font-extrabold text-cyan-400">
                {score} / {questions.length}
              </div>
              <div className="text-xs text-slate-500 mt-1 uppercase font-semibold">
                Accuracy: {Math.round((score / questions.length) * 100)}%
              </div>
            </div>

            <p className="text-xs text-slate-300 max-w-sm mb-6">
              {score === questions.length
                ? '🌟 Flawless Mastery! You answered all logic problems correctly.'
                : score >= questions.length / 2
                ? '👍 Solid progress! Review the flashcards or try the quiz again to get 100%.'
                : '💡 Keep practicing! Read the ELI7 story and flip the flashcards before retrying.'}
            </p>

            <div className="flex gap-3">
              <button
                onClick={handleRestart}
                className="bg-slate-800 hover:bg-slate-700 active:scale-95 text-slate-200 px-4 py-2.5 rounded-xl text-xs font-bold transition-all flex items-center gap-2 cursor-pointer border border-slate-700"
              >
                <RotateCcw size={15} /> Retry Quiz
              </button>
              <button
                onClick={onClose}
                className="bg-cyan-600 hover:bg-cyan-500 active:scale-95 text-white px-5 py-2.5 rounded-xl text-xs font-bold transition-all flex items-center gap-2 cursor-pointer shadow-lg shadow-cyan-600/20"
              >
                Done <Sparkles size={15} />
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
