import React, { useState } from 'react';
import { LeaderboardRecord } from '../types';
import { Trophy, Medal, Filter, Zap, ArrowRight, Clock, Award, ShieldAlert } from 'lucide-react';

interface Props {
  records: LeaderboardRecord[];
  onStartQuiz: () => void;
}

export const LeaderboardView: React.FC<Props> = ({ records, onStartQuiz }) => {
  const [filterDifficulty, setFilterDifficulty] = useState<'all' | 'easy' | 'hard'>('all');
  const [filterDuration, setFilterDuration] = useState<'all' | 1 | 10>('all');

  // Filter records
  const filtered = records
    .filter((r) => filterDifficulty === 'all' || r.difficulty === filterDifficulty)
    .filter((r) => filterDuration === 'all' || r.durationLimitMin === filterDuration)
    .sort((a, b) => {
      if (b.score !== a.score) return b.score - a.score;
      return a.timeSpentSec - b.timeSpentSec; // Faster completion breaks ties
    });

  const getRankBadge = (rank: number) => {
    if (rank === 0) {
      return (
        <span className="w-7 h-7 rounded-full bg-gradient-to-tr from-amber-400 to-yellow-300 text-slate-950 font-bold flex items-center justify-center text-xs shadow-md shadow-yellow-500/20">
          🥇
        </span>
      );
    }
    if (rank === 1) {
      return (
        <span className="w-7 h-7 rounded-full bg-gradient-to-tr from-slate-300 to-slate-400 text-slate-950 font-bold flex items-center justify-center text-xs shadow-md">
          🥈
        </span>
      );
    }
    if (rank === 2) {
      return (
        <span className="w-7 h-7 rounded-full bg-gradient-to-tr from-amber-700 to-amber-600 text-white font-bold flex items-center justify-center text-xs shadow-md">
          🥉
        </span>
      );
    }
    return (
      <span className="w-7 h-7 rounded-full bg-slate-800 text-slate-400 font-mono font-bold flex items-center justify-center text-xs">
        #{rank + 1}
      </span>
    );
  };

  return (
    <div className="max-w-5xl mx-auto w-full h-full overflow-y-auto custom-scrollbar pr-2 pb-12 relative z-10">
      {/* Top Banner */}
      <div className="bg-slate-900/90 border border-slate-800 rounded-2xl p-6 md:p-8 shadow-2xl mb-6 backdrop-blur-md flex flex-col md:flex-row md:items-center justify-between gap-6">
        <div>
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-amber-950/60 border border-amber-600/40 text-amber-400 text-xs font-mono font-bold uppercase tracking-wider mb-2">
            <Trophy size={14} /> Global Hall of Fame
          </div>
          <h2 className="text-3xl font-extrabold text-white">
            ENTC Circuit Leaderboard
          </h2>
          <p className="text-slate-400 text-xs mt-1.5 max-w-xl leading-relaxed">
            Rankings scored on the strict <strong className="text-emerald-400">+1 Point</strong> per correct answer and <strong className="text-red-400">-2 Points</strong> deduction per incorrect answer rule.
          </p>
        </div>

        <button
          onClick={onStartQuiz}
          className="bg-gradient-to-r from-amber-500 to-yellow-500 hover:from-amber-400 hover:to-yellow-400 active:scale-95 text-slate-950 px-6 py-3 rounded-xl font-bold text-sm shadow-xl shadow-amber-500/20 transition-all flex items-center gap-2 shrink-0 cursor-pointer"
        >
          <Zap size={16} fill="currentColor" /> Play 10-Question Game
        </button>
      </div>

      {/* Filters Bar */}
      <div className="bg-slate-900/80 border border-slate-800 rounded-xl p-3.5 mb-6 flex flex-wrap items-center justify-between gap-3">
        <div className="flex items-center gap-2 text-xs text-slate-400">
          <Filter size={15} className="text-cyan-400" />
          <span className="font-semibold uppercase tracking-wider">Difficulty:</span>
          <div className="flex gap-1">
            {(['all', 'easy', 'hard'] as const).map((mode) => (
              <button
                key={mode}
                onClick={() => setFilterDifficulty(mode)}
                className={`px-3 py-1 rounded-lg text-xs font-semibold capitalize transition-all cursor-pointer ${
                  filterDifficulty === mode
                    ? 'bg-cyan-600 text-white shadow-sm'
                    : 'bg-slate-800 text-slate-400 hover:text-white'
                }`}
              >
                {mode}
              </button>
            ))}
          </div>
        </div>

        <div className="flex items-center gap-2 text-xs text-slate-400">
          <Clock size={15} className="text-purple-400" />
          <span className="font-semibold uppercase tracking-wider">Time Mode:</span>
          <div className="flex gap-1">
            <button
              onClick={() => setFilterDuration('all')}
              className={`px-3 py-1 rounded-lg text-xs font-semibold transition-all cursor-pointer ${
                filterDuration === 'all'
                  ? 'bg-purple-600 text-white shadow-sm'
                  : 'bg-slate-800 text-slate-400 hover:text-white'
              }`}
            >
              All
            </button>
            <button
              onClick={() => setFilterDuration(1)}
              className={`px-3 py-1 rounded-lg text-xs font-semibold transition-all cursor-pointer ${
                filterDuration === 1
                  ? 'bg-purple-600 text-white shadow-sm'
                  : 'bg-slate-800 text-slate-400 hover:text-white'
              }`}
            >
              1 Min Blitz
            </button>
            <button
              onClick={() => setFilterDuration(10)}
              className={`px-3 py-1 rounded-lg text-xs font-semibold transition-all cursor-pointer ${
                filterDuration === 10
                  ? 'bg-purple-600 text-white shadow-sm'
                  : 'bg-slate-800 text-slate-400 hover:text-white'
              }`}
            >
              10 Min Study
            </button>
          </div>
        </div>
      </div>

      {/* Leaderboard Table */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl shadow-2xl overflow-hidden">
        <table className="w-full text-left border-collapse">
          <thead>
            <tr className="bg-slate-950/80 border-b border-slate-800 text-[11px] font-mono uppercase tracking-wider text-slate-400">
              <th className="py-3.5 px-4 w-14 text-center">Rank</th>
              <th className="py-3.5 px-4">Student / Cadet</th>
              <th className="py-3.5 px-4 text-center">Net Score</th>
              <th className="py-3.5 px-4 text-center">Accuracy</th>
              <th className="py-3.5 px-4 text-center">Mode</th>
              <th className="py-3.5 px-4 text-center">Time Taken</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-800/60 text-sm">
            {filtered.map((item, idx) => (
              <tr
                key={item.id}
                className="hover:bg-slate-800/40 transition-colors group"
              >
                {/* Rank */}
                <td className="py-3 px-4 text-center">
                  <div className="flex justify-center">{getRankBadge(idx)}</div>
                </td>

                {/* Name */}
                <td className="py-3 px-4">
                  <div className="flex items-center gap-3">
                    <div className="w-8 h-8 rounded-full bg-slate-800 border border-slate-700 flex items-center justify-center font-bold text-xs text-cyan-400">
                      {item.name.charAt(0).toUpperCase()}
                    </div>
                    <div>
                      <div className="font-bold text-slate-200 group-hover:text-cyan-300 transition-colors">
                        {item.name}
                      </div>
                      <div className="text-[10px] text-slate-500 font-mono">
                        {item.correctCount} correct &bull; {item.wrongCount} wrong
                      </div>
                    </div>
                  </div>
                </td>

                {/* Net Score */}
                <td className="py-3 px-4 text-center">
                  <span
                    className={`font-mono font-extrabold text-base px-2.5 py-0.5 rounded-lg ${
                      item.score > 0
                        ? 'text-emerald-400 bg-emerald-950/50 border border-emerald-500/30'
                        : item.score < 0
                        ? 'text-red-400 bg-red-950/50 border border-red-500/30'
                        : 'text-slate-400 bg-slate-800'
                    }`}
                  >
                    {item.score > 0 ? `+${item.score}` : item.score}
                  </span>
                </td>

                {/* Accuracy */}
                <td className="py-3 px-4 text-center">
                  <span className="font-mono text-xs text-slate-300">
                    {Math.round((item.correctCount / item.totalQuestions) * 100)}%
                  </span>
                </td>

                {/* Mode & Difficulty */}
                <td className="py-3 px-4 text-center">
                  <div className="flex items-center justify-center gap-1.5">
                    <span
                      className={`text-[10px] font-bold uppercase px-2 py-0.5 rounded-full ${
                        item.difficulty === 'hard'
                          ? 'bg-purple-950/80 text-purple-300 border border-purple-800/50'
                          : 'bg-cyan-950/80 text-cyan-300 border border-cyan-800/50'
                      }`}
                    >
                      {item.difficulty}
                    </span>
                    <span className="text-[10px] text-slate-400 font-mono">
                      {item.durationLimitMin}m
                    </span>
                  </div>
                </td>

                {/* Time Taken */}
                <td className="py-3 px-4 text-center font-mono text-xs text-slate-400">
                  {Math.floor(item.timeSpentSec / 60)}:
                  {(item.timeSpentSec % 60).toString().padStart(2, '0')}
                </td>
              </tr>
            ))}

            {filtered.length === 0 && (
              <tr>
                <td colSpan={6} className="text-center py-10 text-slate-500 text-xs">
                  No records matching the selected filter. Play a quiz round to rank first!
                </td>
              </tr>
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
};
