import React from 'react';
import { 
  BrainCircuit, BookOpen, Bot, User, Trophy, Zap, 
  ArrowRight, Sparkles, Cpu, Layers, ShieldCheck, Flame, 
  Play, HelpCircle, Lightbulb, Compass, Award 
} from 'lucide-react';
import { CHAPTERS_DATA } from '../data/chaptersData';

interface Props {
  onNavigate: (view: 'home' | 'simulator' | 'modules' | 'jarvis' | 'quiz' | 'leaderboard' | 'profile') => void;
  onLoadPreset: (eq: string) => void;
  onOpenChapterFlashcards: (chapterId: string) => void;
  onOpenChapterQuiz: (chapterId: string) => void;
  quizHighScore?: number;
}

export const HomeView: React.FC<Props> = ({ 
  onNavigate, 
  onLoadPreset,
  onOpenChapterFlashcards,
  onOpenChapterQuiz,
  quizHighScore = 8
}) => {
  return (
    <div className="max-w-6xl mx-auto w-full h-full overflow-y-auto custom-scrollbar pb-16 relative z-10 px-2 sm:px-4">
      {/* Hero Header */}
      <div className="text-center pt-4 pb-8 max-w-3xl mx-auto">
        <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-cyan-950/80 border border-cyan-500/40 text-cyan-300 text-xs font-mono font-bold uppercase tracking-wider mb-4 shadow-lg shadow-cyan-500/10 backdrop-blur-sm animate-pulse">
          <Sparkles size={14} className="text-cyan-400" /> ENTC.lab Next-Gen Studio
        </div>
        <h1 className="text-3xl sm:text-5xl font-extrabold text-white tracking-tight leading-tight">
          Master Digital Electronics & <br />
          <span className="bg-gradient-to-r from-cyan-400 via-blue-400 to-purple-400 bg-clip-text text-transparent">
            Synthesize Logic Circuits
          </span>
        </h1>
        <p className="text-slate-400 text-sm sm:text-base mt-3.5 leading-relaxed">
          The all-in-one laboratory suite for Electronics & Telecommunication Engineering.
          Build live schematics, explore the 7-chapter syllabus with ELI7 kid explanations, consult <strong className="text-cyan-300 font-mono">J.A.R.V.I.S.</strong>, and compete in the Quiz Arena.
        </p>
      </div>

      {/* THE 4 PRIMARY DESTINATION CARDS */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-5 mb-10">
        
        {/* OPTION 1: LOGIC SIMULATOR */}
        <div
          onClick={() => onNavigate('simulator')}
          className="group relative bg-slate-900/90 hover:bg-slate-850/90 border border-slate-700/80 hover:border-cyan-500/70 rounded-3xl p-6 sm:p-7 shadow-2xl transition-all duration-300 cursor-pointer overflow-hidden backdrop-blur-md flex flex-col justify-between hover:shadow-cyan-500/10 hover:-translate-y-1"
        >
          <div className="absolute top-0 right-0 w-36 h-36 bg-cyan-500/10 rounded-full blur-3xl pointer-events-none group-hover:bg-cyan-500/20 transition-all" />
          
          <div>
            <div className="flex items-center justify-between mb-4">
              <div className="w-13 h-13 rounded-2xl bg-cyan-950/80 border border-cyan-500/40 flex items-center justify-center text-cyan-400 shadow-lg group-hover:scale-110 transition-transform">
                <BrainCircuit size={28} />
              </div>
              <span className="text-[11px] font-mono font-bold uppercase tracking-wider text-cyan-400 bg-cyan-950/70 border border-cyan-800/60 px-3 py-1 rounded-full">
                Interactive Canvas
              </span>
            </div>

            <h3 className="text-2xl font-bold text-white group-hover:text-cyan-300 transition-colors">
              Logic Simulator
            </h3>
            <p className="text-slate-400 text-xs sm:text-sm mt-2 leading-relaxed">
              Design and wire gates in real time with intuitive Bezier drag-and-drop connections. Automatically synthesize schematics from Boolean expressions and generate instantaneous Truth Tables.
            </p>

            <div className="mt-4 flex flex-wrap gap-2 text-[11px] font-mono">
              <span className="bg-slate-950 px-2.5 py-1 rounded-lg border border-slate-800 text-slate-300">
                AST Expression Parser
              </span>
              <span className="bg-slate-950 px-2.5 py-1 rounded-lg border border-slate-800 text-slate-300">
                Real-Time Propagation
              </span>
              <span className="bg-slate-950 px-2.5 py-1 rounded-lg border border-slate-800 text-slate-300">
                Truth Table Engine
              </span>
            </div>
          </div>

          <div className="mt-6 pt-4 border-t border-slate-800/80 flex items-center justify-between">
            <span className="text-xs text-cyan-400 font-bold group-hover:underline flex items-center gap-1.5">
              Launch Simulator <ArrowRight size={15} />
            </span>
            <span className="text-[11px] font-mono text-slate-500">v2.4 Engine</span>
          </div>
        </div>

        {/* OPTION 2: COURSE MODULES & SYLLABUS */}
        <div
          onClick={() => onNavigate('modules')}
          className="group relative bg-slate-900/90 hover:bg-slate-850/90 border border-slate-700/80 hover:border-emerald-500/70 rounded-3xl p-6 sm:p-7 shadow-2xl transition-all duration-300 cursor-pointer overflow-hidden backdrop-blur-md flex flex-col justify-between hover:shadow-emerald-500/10 hover:-translate-y-1"
        >
          <div className="absolute top-0 right-0 w-36 h-36 bg-emerald-500/10 rounded-full blur-3xl pointer-events-none group-hover:bg-emerald-500/20 transition-all" />

          <div>
            <div className="flex items-center justify-between mb-4">
              <div className="w-13 h-13 rounded-2xl bg-emerald-950/80 border border-emerald-500/40 flex items-center justify-center text-emerald-400 shadow-lg group-hover:scale-110 transition-transform">
                <BookOpen size={28} />
              </div>
              <span className="text-[11px] font-mono font-bold uppercase tracking-wider text-emerald-400 bg-emerald-950/70 border border-emerald-800/60 px-3 py-1 rounded-full">
                7 Core Chapters
              </span>
            </div>

            <h3 className="text-2xl font-bold text-white group-hover:text-emerald-300 transition-colors">
              Modules & Syllabus
            </h3>
            <p className="text-slate-400 text-xs sm:text-sm mt-2 leading-relaxed">
              Complete curriculum from Basic Gates to Universal Gates, XOR, Full Adders, Multiplexers, and Majority Gates. Features formal Engineering Theory, <strong>ELI7 7-Year-Old Kid Mode</strong>, 3D Flashcards, and Chapter Quizzes.
            </p>

            <div className="mt-4 flex flex-wrap gap-2 text-[11px] font-mono">
              <span className="bg-slate-950 px-2.5 py-1 rounded-lg border border-slate-800 text-slate-300">
                Kid-Friendly Metaphors
              </span>
              <span className="bg-slate-950 px-2.5 py-1 rounded-lg border border-slate-800 text-slate-300">
                Flip Flashcard Decks
              </span>
              <span className="bg-slate-950 px-2.5 py-1 rounded-lg border border-slate-800 text-slate-300">
                Direct Simulator Presets
              </span>
            </div>
          </div>

          <div className="mt-6 pt-4 border-t border-slate-800/80 flex items-center justify-between">
            <span className="text-xs text-emerald-400 font-bold group-hover:underline flex items-center gap-1.5">
              Explore Syllabus <ArrowRight size={15} />
            </span>
            <span className="text-[11px] font-mono text-slate-500">Chapters 1 — 7</span>
          </div>
        </div>

        {/* OPTION 3: J.A.R.V.I.S. AI */}
        <div
          onClick={() => onNavigate('jarvis')}
          className="group relative bg-slate-900/90 hover:bg-slate-850/90 border border-slate-700/80 hover:border-purple-500/70 rounded-3xl p-6 sm:p-7 shadow-2xl transition-all duration-300 cursor-pointer overflow-hidden backdrop-blur-md flex flex-col justify-between hover:shadow-purple-500/10 hover:-translate-y-1"
        >
          <div className="absolute top-0 right-0 w-36 h-36 bg-purple-500/10 rounded-full blur-3xl pointer-events-none group-hover:bg-purple-500/20 transition-all" />

          <div>
            <div className="flex items-center justify-between mb-4">
              <div className="w-13 h-13 rounded-2xl bg-purple-950/80 border border-purple-500/40 flex items-center justify-center text-purple-400 shadow-lg group-hover:scale-110 transition-transform">
                <Bot size={28} />
              </div>
              <span className="text-[11px] font-mono font-bold uppercase tracking-wider text-purple-400 bg-purple-950/70 border border-purple-800/60 px-3 py-1 rounded-full">
                Circuit Copilot
              </span>
            </div>

            <h3 className="text-2xl font-bold text-white group-hover:text-purple-300 transition-colors font-mono">
              J.A.R.V.I.S. AI
            </h3>
            <p className="text-slate-400 text-xs sm:text-sm mt-2 leading-relaxed">
              Your intelligent digital logic companion. Solve Karnaugh Maps (K-Maps), simplify Boolean expressions, convert circuits to NAND-only universal implementations, and ask complex ENTC questions.
            </p>

            <div className="mt-4 flex flex-wrap gap-2 text-[11px] font-mono">
              <span className="bg-slate-950 px-2.5 py-1 rounded-lg border border-slate-800 text-slate-300">
                K-Map Solver
              </span>
              <span className="bg-slate-950 px-2.5 py-1 rounded-lg border border-slate-800 text-slate-300">
                Boolean Simplifier
              </span>
              <span className="bg-slate-950 px-2.5 py-1 rounded-lg border border-slate-800 text-slate-300">
                Universal Gate Converter
              </span>
            </div>
          </div>

          <div className="mt-6 pt-4 border-t border-slate-800/80 flex items-center justify-between">
            <span className="text-xs text-purple-400 font-bold group-hover:underline flex items-center gap-1.5">
              Consult J.A.R.V.I.S. <ArrowRight size={15} />
            </span>
            <span className="text-[11px] font-mono text-emerald-400 flex items-center gap-1">
              <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse" /> Online
            </span>
          </div>
        </div>

        {/* OPTION 4: STUDENT PROFILE & PROGRESS */}
        <div
          onClick={() => onNavigate('profile')}
          className="group relative bg-slate-900/90 hover:bg-slate-850/90 border border-slate-700/80 hover:border-blue-500/70 rounded-3xl p-6 sm:p-7 shadow-2xl transition-all duration-300 cursor-pointer overflow-hidden backdrop-blur-md flex flex-col justify-between hover:shadow-blue-500/10 hover:-translate-y-1"
        >
          <div className="absolute top-0 right-0 w-36 h-36 bg-blue-500/10 rounded-full blur-3xl pointer-events-none group-hover:bg-blue-500/20 transition-all" />

          <div>
            <div className="flex items-center justify-between mb-4">
              <div className="w-13 h-13 rounded-2xl bg-blue-950/80 border border-blue-500/40 flex items-center justify-center text-blue-400 shadow-lg group-hover:scale-110 transition-transform">
                <User size={28} />
              </div>
              <span className="text-[11px] font-mono font-bold uppercase tracking-wider text-blue-400 bg-blue-950/70 border border-blue-800/60 px-3 py-1 rounded-full">
                Cadet Portfolio
              </span>
            </div>

            <h3 className="text-2xl font-bold text-white group-hover:text-blue-300 transition-colors">
              Student Profile
            </h3>
            <p className="text-slate-400 text-xs sm:text-sm mt-2 leading-relaxed">
              Track your synthesized circuits, earned laboratory credentials, AST master badges, and historical quiz performance across semesters.
            </p>

            <div className="mt-4 flex flex-wrap gap-2 text-[11px] font-mono">
              <span className="bg-slate-950 px-2.5 py-1 rounded-lg border border-slate-800 text-slate-300">
                14 Circuits Built
              </span>
              <span className="bg-slate-950 px-2.5 py-1 rounded-lg border border-slate-800 text-slate-300">
                AST Certified Badge
              </span>
              <span className="bg-slate-950 px-2.5 py-1 rounded-lg border border-slate-800 text-slate-300">
                Quiz Record: +{quizHighScore} pts
              </span>
            </div>
          </div>

          <div className="mt-6 pt-4 border-t border-slate-800/80 flex items-center justify-between">
            <span className="text-xs text-blue-400 font-bold group-hover:underline flex items-center gap-1.5">
              View Profile & Badges <ArrowRight size={15} />
            </span>
            <span className="text-[11px] font-mono text-slate-500">UID: Active</span>
          </div>
        </div>
      </div>

      {/* QUIZ GAME & LEADERBOARD PROMO BANNER */}
      <div className="bg-gradient-to-r from-amber-950/50 via-slate-900 to-purple-950/50 border border-amber-500/40 rounded-3xl p-6 sm:p-8 shadow-2xl mb-12 backdrop-blur-md flex flex-col md:flex-row items-center justify-between gap-6">
        <div className="max-w-xl">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-amber-500/10 border border-amber-500/30 text-amber-400 text-xs font-mono font-bold uppercase tracking-wider mb-2">
            <Flame size={14} /> High-Stakes Quiz Slot Game
          </div>
          <h3 className="text-2xl font-extrabold text-white">
            10-Question Logic Battle
          </h3>
          <p className="text-slate-300 text-xs sm:text-sm mt-1 leading-relaxed">
            Test your skills under pressure! Choose <strong>1 Minute (Speed Blitz)</strong> or <strong>10 Minutes (Deep Calculation)</strong> with Easy or Hard difficulty.
            <span className="block mt-1 text-amber-300 font-mono">
              Scoring Rule: +1 Point for Correct &bull; -2 Points for Incorrect!
            </span>
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-3 shrink-0">
          <button
            onClick={() => onNavigate('quiz')}
            className="bg-gradient-to-r from-amber-500 to-yellow-500 hover:from-amber-400 hover:to-yellow-400 active:scale-95 text-slate-950 font-bold px-6 py-3 rounded-xl text-xs sm:text-sm shadow-xl shadow-amber-500/20 transition-all flex items-center gap-2 cursor-pointer"
          >
            <Play size={16} fill="currentColor" /> Play 10-Q Quiz Arena
          </button>
          <button
            onClick={() => onNavigate('leaderboard')}
            className="bg-slate-800 hover:bg-slate-700 active:scale-95 text-slate-200 border border-slate-700 px-5 py-3 rounded-xl text-xs sm:text-sm font-bold transition-all flex items-center gap-2 cursor-pointer"
          >
            <Trophy size={16} className="text-amber-400" /> Leaderboard
          </button>
        </div>
      </div>

      {/* QUICK SYLLABUS CHAPTERS PREVIEW */}
      <div className="mb-8">
        <div className="flex items-center justify-between mb-4">
          <div>
            <h3 className="text-xl font-bold text-white flex items-center gap-2">
              <Layers className="text-cyan-400" size={22} />
              ENTC Syllabus at a Glance
            </h3>
            <p className="text-xs text-slate-400 mt-0.5">
              Click any chapter to study the theory, open flashcards, or load its schematic into the simulator.
            </p>
          </div>

          <button
            onClick={() => onNavigate('modules')}
            className="text-xs text-cyan-400 hover:underline font-semibold flex items-center gap-1 cursor-pointer"
          >
            View All 7 Chapters <ArrowRight size={14} />
          </button>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
          {CHAPTERS_DATA.slice(0, 6).map((ch) => (
            <div
              key={ch.id}
              className="bg-slate-900/80 border border-slate-800 hover:border-slate-700 rounded-2xl p-4 flex flex-col justify-between transition-all group"
            >
              <div>
                <div className="flex items-center justify-between text-[11px] mb-2">
                  <span className="font-mono text-cyan-400 font-bold">Chapter {ch.number}</span>
                  <span className="text-slate-500">{ch.category}</span>
                </div>
                <h4 className="font-bold text-slate-100 group-hover:text-cyan-300 transition-colors text-sm">
                  {ch.title}
                </h4>
                <p className="text-slate-400 text-xs mt-1 line-clamp-2">
                  {ch.subtitle}
                </p>
              </div>

              <div className="mt-4 pt-3 border-t border-slate-800/80 flex items-center justify-between gap-1 text-[11px]">
                <button
                  onClick={() => onOpenChapterFlashcards(ch.id)}
                  className="text-purple-400 hover:text-purple-300 font-semibold cursor-pointer"
                >
                  Flashcards
                </button>
                <span className="text-slate-600">&bull;</span>
                <button
                  onClick={() => onOpenChapterQuiz(ch.id)}
                  className="text-amber-400 hover:text-amber-300 font-semibold cursor-pointer"
                >
                  Quiz
                </button>
                <span className="text-slate-600">&bull;</span>
                <button
                  onClick={() => {
                    onLoadPreset(ch.defaultEquation);
                    onNavigate('simulator');
                  }}
                  className="text-cyan-400 hover:text-cyan-300 font-bold cursor-pointer"
                >
                  Simulate &rarr;
                </button>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
