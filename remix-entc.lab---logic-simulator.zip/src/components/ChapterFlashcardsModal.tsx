import React, { useState } from 'react';
import { Flashcard } from '../types';
import { X, ArrowLeft, ArrowRight, RotateCw, Lightbulb, CheckCircle2, Shuffle, Sparkles } from 'lucide-react';

interface Props {
  chapterTitle: string;
  flashcards: Flashcard[];
  onClose: () => void;
}

export const ChapterFlashcardsModal: React.FC<Props> = ({ chapterTitle, flashcards, onClose }) => {
  const [cards, setCards] = useState<Flashcard[]>(flashcards);
  const [currentIndex, setCurrentIndex] = useState(0);
  const [isFlipped, setIsFlipped] = useState(false);
  const [showHint, setShowHint] = useState(false);
  const [masteredIds, setMasteredIds] = useState<Set<string>>(new Set());

  const currentCard = cards[currentIndex];

  const handleNext = () => {
    setIsFlipped(false);
    setShowHint(false);
    setCurrentIndex((prev) => (prev + 1) % cards.length);
  };

  const handlePrev = () => {
    setIsFlipped(false);
    setShowHint(false);
    setCurrentIndex((prev) => (prev - 1 + cards.length) % cards.length);
  };

  const handleShuffle = () => {
    const shuffled = [...cards].sort(() => Math.random() - 0.5);
    setCards(shuffled);
    setCurrentIndex(0);
    setIsFlipped(false);
    setShowHint(false);
  };

  const toggleMastered = () => {
    setMasteredIds((prev) => {
      const next = new Set(prev);
      if (next.has(currentCard.id)) next.delete(currentCard.id);
      else next.add(currentCard.id);
      return next;
    });
  };

  return (
    <div className="fixed inset-0 z-50 bg-slate-950/85 backdrop-blur-md flex items-center justify-center p-4 sm:p-6 animate-fadeIn">
      <div className="bg-slate-900 border border-slate-700/80 rounded-2xl w-full max-w-xl shadow-2xl flex flex-col overflow-hidden">
        {/* Header */}
        <div className="px-6 py-4 bg-slate-950/80 border-b border-slate-800 flex items-center justify-between">
          <div>
            <div className="flex items-center gap-2">
              <span className="text-[10px] font-bold uppercase tracking-wider text-cyan-400 bg-cyan-950/60 border border-cyan-800/40 px-2 py-0.5 rounded-full">
                Interactive Flashcards
              </span>
              <span className="text-xs text-slate-400">
                Card {currentIndex + 1} of {cards.length}
              </span>
            </div>
            <h3 className="text-base font-bold text-white mt-1 truncate max-w-sm">
              {chapterTitle}
            </h3>
          </div>
          <div className="flex items-center gap-2">
            <button
              onClick={handleShuffle}
              className="p-2 text-slate-400 hover:text-cyan-300 hover:bg-slate-800 rounded-lg transition-colors cursor-pointer"
              title="Shuffle Cards"
            >
              <Shuffle size={18} />
            </button>
            <button
              onClick={onClose}
              className="p-2 text-slate-400 hover:text-white hover:bg-slate-800 rounded-lg transition-colors cursor-pointer"
            >
              <X size={20} />
            </button>
          </div>
        </div>

        {/* Progress Bar */}
        <div className="w-full bg-slate-800 h-1">
          <div
            className="bg-gradient-to-r from-cyan-500 to-blue-500 h-1 transition-all duration-300"
            style={{ width: `${((currentIndex + 1) / cards.length) * 100}%` }}
          />
        </div>

        {/* Card Body with 3D Flip */}
        <div className="p-6 flex-1 flex flex-col items-center justify-center min-h-[300px]">
          <div
            onClick={() => setIsFlipped(!isFlipped)}
            className="w-full h-64 relative cursor-pointer [perspective:1000px] select-none group"
          >
            <div
              className={`w-full h-full rounded-2xl p-6 border transition-all duration-500 [transform-style:preserve-3d] flex flex-col justify-between shadow-xl relative ${
                isFlipped
                  ? '[transform:rotateY(180deg)] bg-gradient-to-br from-slate-900 to-slate-800 border-cyan-500/50 shadow-cyan-500/10'
                  : 'bg-gradient-to-br from-slate-900 via-slate-850 to-slate-900 border-slate-700/80 group-hover:border-slate-600'
              }`}
            >
              {/* Front Side */}
              <div
                className={`absolute inset-0 p-6 flex flex-col justify-between [backface-visibility:hidden] ${
                  isFlipped ? 'pointer-events-none opacity-0' : 'opacity-100'
                }`}
              >
                <div className="flex items-center justify-between">
                  <span className="text-[11px] font-mono text-cyan-400 uppercase tracking-widest font-semibold flex items-center gap-1.5">
                    <Sparkles size={13} /> Question / Concept
                  </span>
                  {masteredIds.has(currentCard.id) && (
                    <span className="text-[11px] text-emerald-400 bg-emerald-950/60 border border-emerald-500/30 px-2 py-0.5 rounded-full font-bold flex items-center gap-1">
                      <CheckCircle2 size={12} /> Mastered
                    </span>
                  )}
                </div>

                <div className="my-auto py-2">
                  <p className="text-lg md:text-xl font-semibold text-slate-100 text-center leading-relaxed">
                    {currentCard.question}
                  </p>

                  {showHint && currentCard.hint && (
                    <div className="mt-3 bg-amber-950/30 border border-amber-600/30 p-2.5 rounded-xl text-amber-300 text-xs flex items-center gap-2">
                      <Lightbulb size={16} className="shrink-0" />
                      <span><strong>Hint:</strong> {currentCard.hint}</span>
                    </div>
                  )}
                </div>

                <div className="flex items-center justify-between text-xs text-slate-500 pt-2 border-t border-slate-800/80">
                  {currentCard.hint ? (
                    <button
                      type="button"
                      onClick={(e) => {
                        e.stopPropagation();
                        setShowHint(!showHint);
                      }}
                      className="text-amber-400 hover:text-amber-300 flex items-center gap-1 cursor-pointer font-medium"
                    >
                      <Lightbulb size={14} /> {showHint ? 'Hide Hint' : 'Show Hint'}
                    </button>
                  ) : <span />}
                  <span className="flex items-center gap-1 text-slate-400">
                    <RotateCw size={13} /> Click card to flip
                  </span>
                </div>
              </div>

              {/* Back Side */}
              <div
                className={`absolute inset-0 p-6 flex flex-col justify-between [transform:rotateY(180deg)] [backface-visibility:hidden] ${
                  isFlipped ? 'opacity-100' : 'pointer-events-none opacity-0'
                }`}
              >
                <div className="flex items-center justify-between">
                  <span className="text-[11px] font-mono text-emerald-400 uppercase tracking-widest font-semibold flex items-center gap-1.5">
                    <CheckCircle2 size={13} /> Verified Answer & Explanation
                  </span>
                  <span className="text-xs text-slate-500">Back</span>
                </div>

                <div className="my-auto py-2">
                  <p className="text-base md:text-lg text-emerald-300 font-medium leading-relaxed bg-emerald-950/20 p-4 rounded-xl border border-emerald-500/20">
                    {currentCard.answer}
                  </p>
                </div>

                <div className="flex items-center justify-between text-xs text-slate-400 pt-2 border-t border-slate-800/80">
                  <span className="text-slate-500">{currentCard.category}</span>
                  <span className="flex items-center gap-1 text-cyan-400">
                    <RotateCw size={13} /> Click to flip back
                  </span>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Footer Navigation */}
        <div className="px-6 py-4 bg-slate-950/80 border-t border-slate-800 flex items-center justify-between gap-3">
          <button
            onClick={toggleMastered}
            className={`px-3.5 py-2 rounded-xl text-xs font-bold transition-all flex items-center gap-1.5 cursor-pointer border ${
              masteredIds.has(currentCard.id)
                ? 'bg-emerald-600/20 border-emerald-500 text-emerald-300'
                : 'bg-slate-800 hover:bg-slate-700 border-slate-700 text-slate-300'
            }`}
          >
            <CheckCircle2 size={15} />
            {masteredIds.has(currentCard.id) ? 'Mastered' : 'Mark Mastered'}
          </button>

          <div className="flex items-center gap-2">
            <button
              onClick={handlePrev}
              className="bg-slate-800 hover:bg-slate-700 active:scale-95 text-slate-200 px-4 py-2 rounded-xl text-xs font-bold transition-all flex items-center gap-1.5 cursor-pointer border border-slate-700"
            >
              <ArrowLeft size={15} /> Prev
            </button>
            <button
              onClick={handleNext}
              className="bg-cyan-600 hover:bg-cyan-500 active:scale-95 text-white px-5 py-2 rounded-xl text-xs font-bold transition-all flex items-center gap-1.5 cursor-pointer shadow-lg shadow-cyan-600/20"
            >
              Next <ArrowRight size={15} />
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
