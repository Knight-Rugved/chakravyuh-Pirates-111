import React, { useEffect, useRef } from 'react';

interface Particle {
  x: number;
  y: number;
  targetX: number;
  targetY: number;
  progress: number;
  speed: number;
  size: number;
  color: string;
}

interface CircuitTrace {
  points: { x: number; y: number }[];
  color: string;
}

export const MovingBackground: React.FC<{ intensity?: 'subtle' | 'vibrant' }> = ({ intensity = 'vibrant' }) => {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    let animationFrameId: number;
    let width = (canvas.width = window.innerWidth);
    let height = (canvas.height = window.innerHeight);

    const handleResize = () => {
      if (!canvas) return;
      width = canvas.width = window.innerWidth;
      height = canvas.height = window.innerHeight;
      initNetwork();
    };

    window.addEventListener('resize', handleResize);

    // Grid nodes
    const gridSize = 70;
    let traces: CircuitTrace[] = [];
    let particles: Particle[] = [];

    const colors = [
      'rgba(6, 182, 212, 0.7)', // cyan
      'rgba(16, 185, 129, 0.7)', // emerald
      'rgba(139, 92, 246, 0.7)', // purple
      'rgba(59, 130, 246, 0.7)', // blue
    ];

    const initNetwork = () => {
      traces = [];
      particles = [];

      const cols = Math.floor(width / gridSize) + 2;
      const rows = Math.floor(height / gridSize) + 2;

      // Generate circuit wire traces with 90-degree PCB bends
      for (let i = 0; i < 28; i++) {
        let currentX = Math.floor(Math.random() * cols) * gridSize;
        let currentY = Math.floor(Math.random() * rows) * gridSize;
        const points: { x: number; y: number }[] = [{ x: currentX, y: currentY }];
        const numSegments = 3 + Math.floor(Math.random() * 4);

        for (let j = 0; j < numSegments; j++) {
          const moveHorizontal = Math.random() > 0.5;
          const step = (Math.random() > 0.5 ? 1 : -1) * (1 + Math.floor(Math.random() * 3)) * gridSize;

          if (moveHorizontal) {
            currentX += step;
          } else {
            currentY += step;
          }
          points.push({ x: currentX, y: currentY });
        }

        traces.push({
          points,
          color: colors[Math.floor(Math.random() * colors.length)],
        });

        // Spawn pulsing logic packets along traces
        particles.push({
          x: points[0].x,
          y: points[0].y,
          targetX: points[1].x,
          targetY: points[1].y,
          progress: Math.random(),
          speed: 0.005 + Math.random() * 0.009,
          size: 2.5 + Math.random() * 2,
          color: colors[Math.floor(Math.random() * colors.length)],
        });
      }
    };

    initNetwork();

    // Floating binary digits (0 and 1) in the background
    const binaryBits: Array<{ x: number; y: number; val: string; opacity: number; vy: number }> = [];
    for (let i = 0; i < 35; i++) {
      binaryBits.push({
        x: Math.random() * width,
        y: Math.random() * height,
        val: Math.random() > 0.5 ? '1' : '0',
        opacity: 0.08 + Math.random() * 0.18,
        vy: 0.15 + Math.random() * 0.35,
      });
    }

    let time = 0;

    const render = () => {
      time += 0.02;
      ctx.clearRect(0, 0, width, height);

      // 1. Subtle glowing grid dots
      ctx.fillStyle = intensity === 'vibrant' ? 'rgba(51, 65, 85, 0.3)' : 'rgba(30, 41, 59, 0.2)';
      const step = 45;
      for (let x = 0; x < width; x += step) {
        for (let y = 0; y < height; y += step) {
          ctx.beginPath();
          ctx.arc(x, y, 1, 0, Math.PI * 2);
          ctx.fill();
        }
      }

      // 2. Draw circuit traces
      ctx.lineWidth = 1.2;
      traces.forEach((trace) => {
        ctx.strokeStyle = trace.color.replace('0.7', '0.12');
        ctx.beginPath();
        trace.points.forEach((pt, idx) => {
          if (idx === 0) ctx.moveTo(pt.x, pt.y);
          else ctx.lineTo(pt.x, pt.y);
        });
        ctx.stroke();

        // Draw solder pads at ends and corners
        trace.points.forEach((pt) => {
          ctx.fillStyle = trace.color.replace('0.7', '0.22');
          ctx.beginPath();
          ctx.arc(pt.x, pt.y, 2.5, 0, Math.PI * 2);
          ctx.fill();
        });
      });

      // 3. Render moving signal packets
      particles.forEach((p, idx) => {
        p.progress += p.speed;
        const trace = traces[idx % traces.length];
        if (!trace || trace.points.length < 2) return;

        const totalSegments = trace.points.length - 1;
        const currentSegIndex = Math.min(Math.floor(p.progress * totalSegments), totalSegments - 1);
        const p1 = trace.points[currentSegIndex];
        const p2 = trace.points[currentSegIndex + 1];

        if (!p1 || !p2) {
          p.progress = 0;
          return;
        }

        const segmentProgress = (p.progress * totalSegments) - currentSegIndex;
        const curX = p1.x + (p2.x - p1.x) * segmentProgress;
        const curY = p1.y + (p2.y - p1.y) * segmentProgress;

        // Glow aura
        const gradient = ctx.createRadialGradient(curX, curY, 0, curX, curY, p.size * 3.5);
        gradient.addColorStop(0, p.color);
        gradient.addColorStop(1, 'transparent');

        ctx.fillStyle = gradient;
        ctx.beginPath();
        ctx.arc(curX, curY, p.size * 3.5, 0, Math.PI * 2);
        ctx.fill();

        // Bright core
        ctx.fillStyle = '#ffffff';
        ctx.beginPath();
        ctx.arc(curX, curY, p.size * 0.7, 0, Math.PI * 2);
        ctx.fill();

        if (p.progress >= 1) {
          p.progress = 0;
        }
      });

      // 4. Floating subtle binary bits
      ctx.font = '12px "JetBrains Mono", monospace';
      binaryBits.forEach((bit) => {
        bit.y -= bit.vy;
        if (bit.y < -20) {
          bit.y = height + 20;
          bit.x = Math.random() * width;
        }
        ctx.fillStyle = `rgba(6, 182, 212, ${bit.opacity * (0.6 + 0.4 * Math.sin(time + bit.x))})`;
        ctx.fillText(bit.val, bit.x, bit.y);
      });

      animationFrameId = requestAnimationFrame(render);
    };

    render();

    return () => {
      cancelAnimationFrame(animationFrameId);
      window.removeEventListener('resize', handleResize);
    };
  }, [intensity]);

  return (
    <canvas
      ref={canvasRef}
      className="absolute inset-0 pointer-events-none w-full h-full z-0 opacity-80"
      style={{ filter: 'contrast(1.1) brightness(1.05)' }}
    />
  );
};
