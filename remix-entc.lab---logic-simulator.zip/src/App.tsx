/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect, useRef, useCallback } from 'react';
import { initializeApp, getApps } from 'firebase/app';
import { 
  getAuth, 
  signInAnonymously, 
  signInWithCustomToken, 
  onAuthStateChanged, 
  User as FirebaseUser 
} from 'firebase/auth';
import { 
  getFirestore, 
  doc, 
  setDoc, 
  onSnapshot 
} from 'firebase/firestore';
import { 
  BookOpen, Cpu, Bot, User, CheckCircle2, 
  Play, RefreshCw, Send, BrainCircuit, 
  Trash2, X, TableProperties, Wand2, ArrowRight,
  Sparkles, Award, ShieldCheck, Zap, Trophy, Flame
} from 'lucide-react';

import { NodeType, CircuitNode, Connection, ChatMessage, LeaderboardRecord } from './types';
import { CHAPTERS_DATA } from './data/chaptersData';
import { MovingBackground } from './components/MovingBackground';
import { Navbar, ViewType } from './components/Navbar';
import { HomeView } from './components/HomeView';
import { ModulesView } from './components/ModulesView';
import { JarvisView } from './components/JarvisView';
import { QuizArena } from './components/QuizArena';
import { LeaderboardView } from './components/LeaderboardView';
import { ChapterFlashcardsModal } from './components/ChapterFlashcardsModal';
import { ChapterQuizModal } from './components/ChapterQuizModal';

// Declarations for runtime environment variables
declare const __firebase_config: string | undefined;
declare const __app_id: string | undefined;
declare const __initial_auth_token: string | undefined;

// --- FIREBASE SETUP ---
let firebaseConfig: Record<string, any> = {
  apiKey: "demo",
  projectId: "demo"
};

try {
  if (typeof __firebase_config !== 'undefined' && __firebase_config) {
    firebaseConfig = JSON.parse(__firebase_config);
  }
} catch (e) {
  console.warn("Could not parse __firebase_config", e);
}

let app: any;
let auth: any;
let db: any;

try {
  if (!getApps().length) {
    app = initializeApp(firebaseConfig);
  } else {
    app = getApps()[0];
  }
  auth = getAuth(app);
  db = getFirestore(app);
} catch (e) {
  console.warn("Firebase not initialized in this environment", e);
}

// --- UTILITY: EQUATION PARSER & AST BUILDER ---
const tokenize = (expr: string) => {
  const str = expr.replace(/\s+/g, '').replace(/([A-Z)])([A-Z(~])/gi, '$1*$2');
  const tokens: Array<{ type: string; val: string }> = [];
  for (let i = 0; i < str.length; i++) {
    const c = str[i];
    if (/[A-Z]/i.test(c)) tokens.push({ type: 'VAR', val: c.toUpperCase() });
    else if (c === '+') tokens.push({ type: 'OR', val: '+' });
    else if (c === '*' || c === '·' || c === '.') tokens.push({ type: 'AND', val: '*' });
    else if (c === '~' || c === "'") tokens.push({ type: 'NOT', val: '~' });
    else if (c === '(') tokens.push({ type: 'LPAREN', val: '(' });
    else if (c === ')') tokens.push({ type: 'RPAREN', val: ')' });
    else if (c === '⊕') tokens.push({ type: 'XOR', val: '⊕' });
  }
  return tokens;
};

const toPostfix = (tokens: Array<{ type: string; val: string }>) => {
  const output: Array<{ type: string; val: string }> = [];
  const ops: Array<{ type: string; val: string }> = [];
  const precedence: Record<string, number> = { '~': 3, '*': 2, '⊕': 2, '+': 1 };
  
  for (const t of tokens) {
    if (t.type === 'VAR') {
      output.push(t);
    } else if (t.type === 'NOT') {
      ops.push(t);
    } else if (t.type === 'LPAREN') {
      ops.push(t);
    } else if (t.type === 'RPAREN') {
      while (ops.length > 0 && ops[ops.length - 1].type !== 'LPAREN') {
        output.push(ops.pop()!);
      }
      ops.pop();
    } else {
      while (
        ops.length > 0 && 
        ops[ops.length - 1].type !== 'LPAREN' && 
        (precedence[ops[ops.length - 1].val] || 0) >= (precedence[t.val] || 0)
      ) {
        output.push(ops.pop()!);
      }
      ops.push(t);
    }
  }
  while (ops.length > 0) {
    output.push(ops.pop()!);
  }
  return output;
};

interface ASTNode {
  type: string;
  label?: string;
  children?: ASTNode[];
}

const buildAST = (postfix: Array<{ type: string; val: string }>): ASTNode | null => {
  const stack: ASTNode[] = [];
  for (const t of postfix) {
    if (t.type === 'VAR') {
      stack.push({ type: 'INPUT', label: t.val });
    } else if (t.type === 'NOT') {
      const child = stack.pop();
      if (child) {
        stack.push({ type: 'NOT', children: [child] });
      }
    } else {
      const right = stack.pop();
      const left = stack.pop();
      if (left && right) {
        stack.push({ type: t.type, children: [left, right] });
      }
    }
  }
  return stack[0] || null;
};

// --- CUSTOM KEYBOARD ---
const ENTCKeyboard: React.FC<{ onKeyPress: (key: string) => void }> = ({ onKeyPress }) => {
  const keys = [
    { label: 'A', val: 'A' }, 
    { label: 'B', val: 'B' }, 
    { label: 'C', val: 'C' }, 
    { label: 'AND (*)', val: '*' }, 
    { label: 'OR (+)', val: '+' }, 
    { label: 'NOT (~)', val: '~' },
    { label: 'XOR (⊕)', val: '⊕' }, 
    { label: '(', val: '(' }, 
    { label: ')', val: ')' }
  ];

  return (
    <div className="bg-slate-800 p-2.5 rounded-lg border border-slate-700 flex flex-wrap gap-2 items-center shrink-0">
      {keys.map(k => (
        <button 
          key={k.val} 
          onClick={() => onKeyPress(k.val)} 
          className="bg-slate-700 hover:bg-slate-600 active:scale-95 text-slate-200 px-3 py-1.5 rounded text-sm font-mono font-bold transition-all shadow-sm cursor-pointer"
        >
          {k.label}
        </button>
      ))}
      <button 
        onClick={() => onKeyPress('BACKSPACE')} 
        className="bg-red-900/40 hover:bg-red-600/80 active:scale-95 text-red-200 px-3 py-1.5 rounded text-sm font-bold transition-all ml-auto border border-red-800/40 cursor-pointer"
      >
        Del
      </button>
    </div>
  );
};

// --- ADVANCED LOGIC SIMULATOR COMPONENT ---
const AdvancedLogicSimulator: React.FC<{ 
  user: FirebaseUser | null;
  presetEquation?: string | null;
  onClearPreset?: () => void;
}> = ({ presetEquation, onClearPreset }) => {
  const [nodes, setNodes] = useState<CircuitNode[]>([
    { id: 'node_in_A', type: 'INPUT', label: 'A', value: 1, x: 60, y: 80 },
    { id: 'node_in_B', type: 'INPUT', label: 'B', value: 1, x: 60, y: 170 },
    { id: 'node_in_C', type: 'INPUT', label: 'C', value: 0, x: 60, y: 260 },
    { id: 'node_and_1', type: 'AND', label: '', value: 0, x: 250, y: 70 },
    { id: 'node_and_2', type: 'AND', label: '', value: 0, x: 250, y: 170 },
    { id: 'node_and_3', type: 'AND', label: '', value: 0, x: 250, y: 270 },
    { id: 'node_or_main', type: 'OR', label: '', value: 0, x: 440, y: 170 },
    { id: 'node_out_Y', type: 'OUTPUT', label: 'Y', value: 0, x: 620, y: 170 }
  ]);

  const [connections, setConnections] = useState<Connection[]>([
    { from: 'node_in_A', to: 'node_and_1' },
    { from: 'node_in_B', to: 'node_and_1' },
    { from: 'node_in_B', to: 'node_and_2' },
    { from: 'node_in_C', to: 'node_and_2' },
    { from: 'node_in_A', to: 'node_and_3' },
    { from: 'node_in_C', to: 'node_and_3' },
    { from: 'node_and_1', to: 'node_or_main' },
    { from: 'node_and_2', to: 'node_or_main' },
    { from: 'node_and_3', to: 'node_or_main' },
    { from: 'node_or_main', to: 'node_out_Y' }
  ]);

  const [equation, setEquation] = useState('Y = A*B + B*C + A*C');
  const [isTyping, setIsTyping] = useState(false);
  const [showTruthTable, setShowTruthTable] = useState(false);
  
  // Drag State
  const [dragNode, setDragNode] = useState<{ id: string; startX: number; startY: number } | null>(null);
  const [connectingFrom, setConnectingFrom] = useState<string | null>(null);
  const [isHoveringTrash, setIsHoveringTrash] = useState(false);
  const containerRef = useRef<HTMLDivElement>(null);
  const trashRef = useRef<HTMLDivElement>(null);

  // JARVIS Tutor Messages (Renamed from AI Tutor)
  const [messages, setMessages] = useState<ChatMessage[]>([
    {
      id: '1',
      sender: 'ai',
      text: "Greetings, Cadet. I am J.A.R.V.I.S., monitoring your ENTC logic circuit workbench. Currently evaluating the Majority Gate: Y = A*B + B*C + A*C.",
      timestamp: 'Just now'
    }
  ]);
  const [chatInput, setChatInput] = useState('');
  const [isAiThinking, setIsAiThinking] = useState(false);

  // Constants
  const ioTypes: NodeType[] = ['INPUT', 'OUTPUT'];
  const gateTypes: NodeType[] = ['AND', 'OR', 'NOT', 'XOR'];

  // 1. EVALUATION (Circuit -> Values)
  const evaluateCircuit = useCallback(() => {
    const nodeValues: Record<string, number | null> = {};
    nodes.forEach(n => {
      if (n.type === 'INPUT') nodeValues[n.id] = n.value;
      else nodeValues[n.id] = null;
    });

    let changed = true;
    let iters = 0;
    while (changed && iters < 100) {
      changed = false;
      iters++;
      nodes.forEach(node => {
        if (node.type === 'INPUT') return;
        const inputConns = connections.filter(c => c.to === node.id);
        const inputVals = inputConns
          .map(c => nodeValues[c.from])
          .filter((v): v is number => v !== null && v !== undefined);

        let newVal: number | null = null;
        if (node.type === 'NOT' && inputVals.length > 0) {
          newVal = inputVals[0] === 1 ? 0 : 1;
        } else if (inputVals.length > 0) {
          if (node.type === 'AND') newVal = inputVals.every(v => v === 1) ? 1 : 0;
          if (node.type === 'OR') newVal = inputVals.some(v => v === 1) ? 1 : 0;
          if (node.type === 'XOR') newVal = inputVals.reduce((a, b) => a ^ b, 0);
          if (node.type === 'OUTPUT') newVal = inputVals[0];
        }

        if (newVal !== nodeValues[node.id]) {
          nodeValues[node.id] = newVal;
          changed = true;
        }
      });
    }
    return nodeValues;
  }, [nodes, connections]);

  const currentValues = evaluateCircuit();

  // 2. AUTO-DERIVE EQUATION (Circuit -> Eq)
  useEffect(() => {
    if (isTyping) return;

    const outputNode = nodes.find(n => n.type === 'OUTPUT');
    if (!outputNode) return;

    const buildExpr = (nodeId: string, visited = new Set<string>()): string => {
      if (visited.has(nodeId)) return "?";
      visited.add(nodeId);
      
      const node = nodes.find(n => n.id === nodeId);
      if (!node) return "";
      if (node.type === 'INPUT') return node.label || "?";

      const inputs = connections.filter(c => c.to === nodeId).map(c => c.from);
      if (inputs.length === 0) return "";

      if (node.type === 'NOT') return `~(${buildExpr(inputs[0], new Set(visited))})`;
      if (node.type === 'OUTPUT') return buildExpr(inputs[0], new Set(visited));

      const exprs = inputs.map(id => buildExpr(id, new Set(visited))).filter(Boolean);
      if (exprs.length === 0) return "";
      
      const opMap: Record<string, string> = { 'AND': '*', 'OR': '+', 'XOR': '⊕' };
      const op = opMap[node.type] || '*';
      
      if (exprs.length === 1) return exprs[0];
      return `(${exprs.join(` ${op} `)})`;
    };

    const derived = buildExpr(outputNode.id);
    if (derived) {
      setEquation(`Y = ${derived}`);
    }
  }, [nodes, connections, isTyping]);

  // 3. AUTO-GENERATE CIRCUIT (Eq -> Circuit)
  const generateCircuitFromEquation = () => {
    try {
      const eq = equation.includes('=') ? equation.split('=')[1].trim() : equation.trim();
      if (!eq) return;

      const tokens = tokenize(eq);
      const postfix = toPostfix(tokens);
      const ast = buildAST(postfix);

      if (!ast) {
        alert("Please enter a valid Boolean expression, e.g. Y = A*B + C");
        return;
      }

      const newNodes: CircuitNode[] = [];
      const newConns: Connection[] = [];
      const inputsMap: Record<string, CircuitNode> = {};

      const traverse = (node: ASTNode | null | undefined, depth: number, yOffset: number): string | null => {
        if (!node) return null;
        if (node.type === 'INPUT') {
          const varLabel = node.label || 'A';
          if (!inputsMap[varLabel]) {
            const id = `node_in_${varLabel}`;
            const inputNode: CircuitNode = { 
              id, 
              type: 'INPUT', 
              label: varLabel, 
              value: 0, 
              x: 60, 
              y: 80 + Object.keys(inputsMap).length * 80 
            };
            inputsMap[varLabel] = inputNode;
            newNodes.push(inputNode);
          }
          return inputsMap[varLabel].id;
        }

        const id = `node_${Math.random().toString(36).substring(2, 9)}`;
        const n: CircuitNode = { 
          id, 
          type: node.type as NodeType, 
          label: '',
          value: 0,
          x: 200 + depth * 150, 
          y: Math.max(50, yOffset) 
        };
        newNodes.push(n);

        if (node.children) {
          node.children.forEach((child, i) => {
            const childId = traverse(child, depth - 1, yOffset + (i - 0.5) * 80);
            if (childId) {
              newConns.push({ from: childId, to: id });
            }
          });
        }
        return id;
      };

      const rootId = traverse(ast, 3, 200);
      if (rootId) {
        const outId = `node_out_Y`;
        newNodes.push({ 
          id: outId, 
          type: 'OUTPUT', 
          label: 'Y', 
          value: 0,
          x: 200 + 4 * 140, 
          y: 200 
        });
        newConns.push({ from: rootId, to: outId });
      }

      setNodes(newNodes);
      setConnections(newConns);
      setIsTyping(false);
    } catch {
      alert("Invalid Boolean Equation format. Use variables (A, B, C) and operators (* for AND, + for OR, ~ for NOT, ⊕ for XOR).");
    }
  };

  // Load preset equation
  useEffect(() => {
    if (presetEquation) {
      setEquation(presetEquation);
      setIsTyping(false);
      try {
        const eq = presetEquation.includes('=') ? presetEquation.split('=')[1].trim() : presetEquation.trim();
        if (eq) {
          const tokens = tokenize(eq);
          const postfix = toPostfix(tokens);
          const ast = buildAST(postfix);
          if (ast) {
            const newNodes: CircuitNode[] = [];
            const newConns: Connection[] = [];
            const inputsMap: Record<string, CircuitNode> = {};

            const traverse = (node: ASTNode | null | undefined, depth: number, yOffset: number): string | null => {
              if (!node) return null;
              if (node.type === 'INPUT') {
                const varLabel = node.label || 'A';
                if (!inputsMap[varLabel]) {
                  const id = `node_in_${varLabel}`;
                  const inputNode: CircuitNode = { 
                    id, 
                    type: 'INPUT', 
                    label: varLabel, 
                    value: 0, 
                    x: 60, 
                    y: 80 + Object.keys(inputsMap).length * 80 
                  };
                  inputsMap[varLabel] = inputNode;
                  newNodes.push(inputNode);
                }
                return inputsMap[varLabel].id;
              }

              const id = `node_${Math.random().toString(36).substring(2, 9)}`;
              const n: CircuitNode = { 
                id, 
                type: node.type as NodeType, 
                label: '',
                value: 0,
                x: 200 + depth * 150, 
                y: Math.max(50, yOffset) 
              };
              newNodes.push(n);

              if (node.children) {
                node.children.forEach((child, i) => {
                  const childId = traverse(child, depth - 1, yOffset + (i - 0.5) * 80);
                  if (childId) {
                    newConns.push({ from: childId, to: id });
                  }
                });
              }
              return id;
            };

            const rootId = traverse(ast, 3, 200);
            if (rootId) {
              const outId = `node_out_Y`;
              newNodes.push({ 
                id: outId, 
                type: 'OUTPUT', 
                label: 'Y', 
                value: 0,
                x: 200 + 4 * 140, 
                y: 200 
              });
              newConns.push({ from: rootId, to: outId });
            }
            setNodes(newNodes);
            setConnections(newConns);
          }
        }
      } catch (err) {
        console.error("Failed to parse preset equation:", err);
      }
      onClearPreset?.();
    }
  }, [presetEquation, onClearPreset]);

  // Node Management
  const addNode = (type: NodeType) => {
    const id = `node_${Date.now()}`;
    const isInput = type === 'INPUT';
    const isOutput = type === 'OUTPUT';
    const currentInputCount = nodes.filter(n => n.type === 'INPUT').length;
    
    const charCode = 65 + currentInputCount;
    const defaultLabel = String.fromCharCode(charCode <= 90 ? charCode : 65);

    setNodes([
      ...nodes, 
      { 
        id, 
        type, 
        label: isInput ? defaultLabel : (isOutput ? 'Y' : ''),
        value: 0, 
        x: 100 + Math.floor(Math.random() * 120), 
        y: 100 + Math.floor(Math.random() * 140) 
      }
    ]);
  };

  const removeNode = (id: string) => {
    setNodes(nodes.filter(n => n.id !== id));
    setConnections(connections.filter(c => c.from !== id && c.to !== id));
  };

  const clearAll = () => { 
    setNodes([]); 
    setConnections([]); 
    setEquation(''); 
  };

  const resetInputs = () => {
    setNodes(nodes.map(n => n.type === 'INPUT' ? { ...n, value: 0 } : n));
  };

  // Drag & Wire Events
  const handlePointerDown = (e: React.PointerEvent, id: string) => {
    const target = e.target as HTMLElement;
    if (target.closest('.port') || target.closest('.interactive-btn')) return;
    setDragNode({ id, startX: e.clientX, startY: e.clientY });
    (e.currentTarget as HTMLElement).setPointerCapture(e.pointerId);
  };

  const handlePointerMove = (e: React.PointerEvent, id: string) => {
    if (dragNode && dragNode.id === id) {
      const dx = e.clientX - dragNode.startX;
      const dy = e.clientY - dragNode.startY;
      setNodes(nodes.map(n => n.id === id ? { ...n, x: Math.max(10, n.x + dx), y: Math.max(10, n.y + dy) } : n));
      setDragNode({ id, startX: e.clientX, startY: e.clientY });

      if (trashRef.current) {
        const rect = trashRef.current.getBoundingClientRect();
        if (
          e.clientX >= rect.left && 
          e.clientX <= rect.right && 
          e.clientY >= rect.top && 
          e.clientY <= rect.bottom
        ) {
          setIsHoveringTrash(true);
        } else {
          setIsHoveringTrash(false);
        }
      }
    }
  };

  const handlePointerUp = (e: React.PointerEvent) => {
    if (dragNode && isHoveringTrash) {
      removeNode(dragNode.id);
    }
    setDragNode(null);
    setIsHoveringTrash(false);
    try {
      (e.currentTarget as HTMLElement).releasePointerCapture(e.pointerId);
    } catch {
      // Ignored
    }
  };

  // Truth Table Generator
  const generateTruthTable = () => {
    const inputs = nodes.filter(n => n.type === 'INPUT').sort((a, b) => a.label.localeCompare(b.label));
    const outputs = nodes.filter(n => n.type === 'OUTPUT');
    if (inputs.length === 0 || outputs.length === 0) return null;

    const rows: Array<Record<string, number>> = [];
    const numRows = Math.pow(2, inputs.length);
    
    const originalValues: Record<string, number> = {};
    inputs.forEach(i => originalValues[i.id] = i.value);

    for (let i = 0; i < numRows; i++) {
      const row: Record<string, number> = {};
      inputs.forEach((inp, idx) => {
        const val = (i >> (inputs.length - 1 - idx)) & 1;
        inp.value = val;
        row[inp.label] = val;
      });
      
      const evaluated = evaluateCircuit();
      outputs.forEach(out => {
        row[out.label || 'Out'] = evaluated[out.id] ?? 0;
      });
      rows.push(row);
    }

    inputs.forEach(i => i.value = originalValues[i.id]);
    return { 
      inputs: inputs.map(i => i.label), 
      outputs: outputs.map(o => o.label || 'Out'), 
      rows 
    };
  };

  // JARVIS Copilot Prompts
  const handleSendPrompt = (promptText?: string) => {
    const textToSend = promptText || chatInput;
    if (!textToSend.trim()) return;

    const userMsg: ChatMessage = {
      id: Date.now().toString(),
      sender: 'user',
      text: textToSend,
      timestamp: 'Now'
    };
    setMessages(prev => [...prev, userMsg]);
    if (!promptText) setChatInput('');
    setIsAiThinking(true);

    setTimeout(() => {
      let aiReply = "";
      const lower = textToSend.toLowerCase();

      if (lower.includes('k-map') || lower.includes('karnaugh')) {
        aiReply = `📊 **J.A.R.V.I.S. K-Map Analysis for "${equation || 'Active Circuit'}"**:\n\n` +
          `• Active Variables: 3 Variables (A, B, C)\n` +
          `• Minterms Σm(3, 5, 6, 7): [011, 101, 110, 111]\n` +
          `• Minimal 2-cell groupings:\n` +
          `   - Group 1: m(3,7) = B·C\n` +
          `   - Group 2: m(5,7) = A·C\n` +
          `   - Group 3: m(6,7) = A·B\n\n` +
          `✅ Minimal Sum of Products: **Y = AB + BC + AC** (Majority Function).`;
      } else if (lower.includes('explain') || lower.includes('circuit')) {
        aiReply = `💡 **J.A.R.V.I.S. Circuit Telemetry**:\n\n` +
          `This schematic is a classic **3-input Majority Gate**. The output Y is HIGH (1) if and only if **2 or more inputs are HIGH (1)**.\n\n` +
          `• **Gate Stage 1**: Three 2-input AND gates calculating pair combinations (A·B, B·C, A·C).\n` +
          `• **Gate Stage 2**: A 3-input OR gate that sums the pair products.\n` +
          `• **Practical Use**: Fault-tolerant avionics, triple modular redundancy (TMR), and Full Adder Carry-Out (C_out).`;
      } else if (lower.includes('simplify') || lower.includes('boolean')) {
        aiReply = `📐 **Boolean Algebra Simplification**:\n` +
          `Target Expression: ${equation}\n` +
          `Using Boolean consensus theorem and idempotent law (X + X = X), this expression is in its prime minimal Sum-of-Products (SOP) canonical form. No further 2-level reduction is possible.`;
      } else {
        aiReply = `⚡ **J.A.R.V.I.S. Diagnostic for ${equation || 'Circuit'}**:\n` +
          `• Active Nodes: ${nodes.length} (${nodes.filter(n => n.type === 'INPUT').length} inputs, ${nodes.filter(n => n.type === 'OUTPUT').length} outputs)\n` +
          `• Signal Traces: ${connections.length} active wires\n` +
          `• Current Output State: ${currentValues[nodes.find(n => n.type === 'OUTPUT')?.id || ''] ?? 'Unconnected'}\n\n` +
          `Toggle input switches on the canvas to observe real-time signal propagation!`;
      }

      setMessages(prev => [
        ...prev,
        {
          id: (Date.now() + 1).toString(),
          sender: 'ai',
          text: aiReply,
          timestamp: 'Just now'
        }
      ]);
      setIsAiThinking(false);
    }, 500);
  };

  return (
    <div className="flex h-full gap-4 relative z-10">
      {/* Main Simulator Area */}
      <div className="flex-1 flex flex-col bg-slate-900/90 border border-slate-800 rounded-2xl overflow-hidden shadow-2xl relative backdrop-blur-md">
        
        {/* Top Control Bar */}
        <div className="p-4 bg-slate-800/80 border-b border-slate-700 flex flex-col gap-3 shrink-0 z-20">
          <div className="flex items-center gap-3">
            <div className="relative flex-1">
              <input 
                type="text" 
                value={equation} 
                onChange={(e) => { setEquation(e.target.value); setIsTyping(true); }}
                placeholder="e.g. Y = A*B + B*C + A*C"
                className="w-full bg-slate-950 border border-slate-600 rounded-lg px-4 py-2.5 text-cyan-400 font-mono text-base focus:outline-none focus:border-cyan-400 focus:ring-1 focus:ring-cyan-400 transition-all shadow-inner"
              />
            </div>
            <button 
              onClick={generateCircuitFromEquation} 
              className="bg-blue-600 hover:bg-blue-500 active:scale-95 text-white px-4 py-2.5 rounded-lg font-bold shadow-md transition-all flex items-center gap-2 shrink-0 cursor-pointer"
              title="Build schematic layout automatically from Boolean equation"
            >
              <RefreshCw size={17} /> Build Circuit
            </button>
            <button 
              onClick={() => setShowTruthTable(true)} 
              className="bg-emerald-600 hover:bg-emerald-500 active:scale-95 text-white px-5 py-2.5 rounded-lg font-bold shadow-lg shadow-emerald-600/20 transition-all flex items-center gap-2 shrink-0 cursor-pointer"
              title="Generate full Truth Table for current circuit"
            >
              <Play size={17} fill="currentColor" /> Run / Test
            </button>
          </div>
          
          <div className="flex justify-between items-center gap-4">
            <ENTCKeyboard onKeyPress={(key) => {
              setIsTyping(true);
              if (key === 'BACKSPACE') {
                setEquation(prev => prev.slice(0, -1));
              } else {
                setEquation(prev => {
                  if (prev === 'Y = A*B + B*C + A*C' && !isTyping) return key;
                  return prev + key;
                });
              }
            }}/>
            
            <div className="flex gap-2 shrink-0">
              <button 
                onClick={resetInputs} 
                className="text-slate-300 hover:text-white hover:bg-slate-700 px-3 py-1.5 text-xs font-semibold border border-slate-700 rounded-lg transition-colors cursor-pointer"
              >
                Reset Inputs (0)
              </button>
              <button 
                onClick={clearAll} 
                className="text-red-400 hover:text-white hover:bg-red-900/40 px-3 py-1.5 text-xs font-semibold border border-red-900/50 rounded-lg transition-colors cursor-pointer"
              >
                Erase All
              </button>
            </div>
          </div>
        </div>

        {/* Toolbar - Add Nodes */}
        <div className="absolute top-[138px] left-4 bg-slate-800/90 backdrop-blur border border-slate-700 p-2 rounded-xl flex flex-col gap-2 z-20 shadow-xl">
          <div className="text-[10px] text-cyan-400 font-bold uppercase tracking-wider text-center mb-0.5">Add</div>
          {[...ioTypes, ...gateTypes].map(type => (
            <button 
              key={type} 
              onClick={() => addNode(type)} 
              className="bg-slate-700 hover:bg-cyan-600 active:scale-95 text-slate-200 text-xs px-2.5 py-1.5 rounded-lg transition-all font-mono font-bold shadow-sm cursor-pointer"
            >
              {type}
            </button>
          ))}
        </div>

        {/* Interactive Canvas Area */}
        <div 
          className="flex-1 relative overflow-hidden bg-slate-950/90 bg-[radial-gradient(#1e293b_1.5px,transparent_1.5px)] [background-size:24px_24px]" 
          ref={containerRef}
          onClick={() => connectingFrom && setConnectingFrom(null)}
        >
          {connectingFrom && (
            <div className="absolute top-4 right-20 bg-yellow-400/90 text-slate-950 text-xs font-bold px-3 py-1.5 rounded-full z-20 shadow-lg animate-bounce flex items-center gap-1.5">
              <Zap size={14} /> Click target node port to complete wire (or click empty space to cancel)
            </div>
          )}

          {/* SVG Wires */}
          <svg className="absolute inset-0 pointer-events-none w-full h-full z-0">
            <defs>
              <filter id="wire-glow" x="-20%" y="-20%" width="140%" height="140%">
                <feGaussianBlur stdDeviation="3" result="blur" />
                <feComposite in="SourceGraphic" in2="blur" operator="over" />
              </filter>
            </defs>
            {connections.map((conn, idx) => {
              const fromNode = nodes.find(n => n.id === conn.from);
              const toNode = nodes.find(n => n.id === conn.to);
              if (!fromNode || !toNode) return null;
              
              const startX = fromNode.x + (fromNode.type === 'INPUT' ? 68 : 88);
              const startY = fromNode.y + 20;
              const endX = toNode.x - 4;
              const endY = toNode.y + 20;
              const isActive = currentValues[conn.from] === 1;

              return (
                <g key={`${conn.from}-${conn.to}-${idx}`}>
                  <path 
                    d={`M ${startX} ${startY} C ${startX + 50} ${startY}, ${endX - 50} ${endY}, ${endX} ${endY}`}
                    fill="none"
                    stroke="transparent"
                    strokeWidth="16"
                    className="pointer-events-auto cursor-pointer"
                    onClick={(e) => { 
                      e.stopPropagation(); 
                      setConnections(connections.filter((_, i) => i !== idx)); 
                    }}
                  />
                  <path 
                    d={`M ${startX} ${startY} C ${startX + 50} ${startY}, ${endX - 50} ${endY}, ${endX} ${endY}`}
                    fill="none"
                    stroke={isActive ? '#10b981' : '#475569'}
                    strokeWidth={isActive ? '3.5' : '2.5'}
                    filter={isActive ? 'url(#wire-glow)' : undefined}
                    className="transition-colors duration-200 pointer-events-none"
                  />
                </g>
              );
            })}
          </svg>

          {/* Schematic Nodes */}
          {nodes.map(node => {
            const isInput = node.type === 'INPUT';
            const isOutput = node.type === 'OUTPUT';
            const val = currentValues[node.id];
            const isActive = val === 1;

            return (
              <div 
                key={node.id}
                className={`absolute select-none flex flex-col items-center justify-center p-2 h-[42px] rounded-lg border-2 shadow-lg cursor-grab active:cursor-grabbing backdrop-blur-md z-10 transition-shadow
                  ${isInput || isOutput ? 'bg-slate-800 min-w-[70px]' : 'bg-cyan-950/90 min-w-[88px]'}
                  ${isActive ? 'border-emerald-500 shadow-emerald-500/25 shadow-md' : 'border-slate-600'}
                  ${dragNode?.id === node.id ? 'scale-105 shadow-2xl ring-2 ring-cyan-400' : ''}
                `}
                style={{ left: node.x, top: node.y, touchAction: 'none' }}
                onPointerDown={(e) => handlePointerDown(e, node.id)}
                onPointerMove={(e) => handlePointerMove(e, node.id)}
                onPointerUp={handlePointerUp}
                onPointerCancel={handlePointerUp}
              >
                {!isInput && (
                  <button 
                    type="button"
                    aria-label={`Connect input to ${node.type}`}
                    className="port absolute -left-3 top-1/2 -translate-y-1/2 w-4 h-4 bg-slate-700 border-2 border-slate-500 rounded-full cursor-pointer hover:bg-yellow-400 hover:border-yellow-200 transition-all z-20"
                    onClick={(e) => { 
                      e.stopPropagation(); 
                      if (connectingFrom && connectingFrom !== node.id) {
                        setConnections(prev => [...prev, { from: connectingFrom, to: node.id }]);
                        setConnectingFrom(null);
                      }
                    }}
                  />
                )}
                
                <div className="flex items-center justify-between w-full gap-2 relative z-10 px-1">
                  <span className={`text-xs font-mono font-bold tracking-wider ${isActive ? 'text-emerald-400' : 'text-slate-300'}`}>
                    {isInput || isOutput ? node.label : node.type}
                  </span>

                  {isInput && (
                    <button 
                      type="button"
                      className={`interactive-btn w-6 h-6 rounded text-xs font-mono font-bold cursor-pointer transition-all shadow-inner
                        ${node.value === 1 ? 'bg-emerald-500 text-slate-950 ring-2 ring-emerald-300 shadow-[0_0_8px_#10b981]' : 'bg-slate-700 hover:bg-slate-600 text-slate-300'}
                      `} 
                      onClick={(e) => { 
                        e.stopPropagation(); 
                        setNodes(nodes.map(n => n.id === node.id ? { ...n, value: n.value === 1 ? 0 : 1 } : n)); 
                      }}
                      title="Click to toggle logic level (0 or 1)"
                    >
                      {node.value}
                    </button>
                  )}

                  {isOutput && (
                    <div className={`w-6 h-6 rounded-full flex items-center justify-center text-xs font-mono font-bold text-white transition-all
                      ${isActive ? 'bg-emerald-500 shadow-[0_0_12px_#10b981] border border-emerald-300' : 'bg-slate-700 text-slate-400 border border-slate-600'}
                    `}>
                      {val !== null && val !== undefined ? val : '?'}
                    </div>
                  )}
                </div>

                {!isOutput && (
                  <button 
                    type="button"
                    aria-label={`Connect output from ${node.type}`}
                    className={`port absolute -right-3 top-1/2 -translate-y-1/2 w-4 h-4 rounded-full border-2 cursor-pointer transition-all z-20
                      ${connectingFrom === node.id 
                        ? 'bg-yellow-400 border-yellow-200 animate-pulse scale-125 shadow-[0_0_8px_#facc15]' 
                        : (isActive ? 'bg-emerald-500 border-emerald-300' : 'bg-slate-700 border-slate-500 hover:bg-yellow-400')}
                    `}
                    onClick={(e) => { 
                      e.stopPropagation(); 
                      setConnectingFrom(node.id); 
                    }}
                    title="Click to start wiring to another gate"
                  />
                )}
              </div>
            );
          })}
        </div>

        {/* Trash Can Drop Area */}
        <div 
          ref={trashRef}
          className={`absolute bottom-4 right-4 p-5 rounded-2xl border-2 flex flex-col items-center justify-center transition-all z-20 shadow-xl backdrop-blur select-none
            ${isHoveringTrash ? 'bg-red-500/25 border-red-500 scale-110 text-red-400' : 'bg-slate-900/80 border-slate-700 text-slate-500'}
          `}
        >
          <Trash2 size={26} />
          <span className="text-[10px] font-bold mt-1 uppercase tracking-wider">Drag to Trash</span>
        </div>

        {/* Truth Table Modal */}
        {showTruthTable && (
          <div className="absolute inset-0 bg-slate-950/90 z-50 flex items-center justify-center p-6 backdrop-blur-md">
            <div className="bg-slate-900 border border-slate-700 rounded-2xl shadow-2xl p-6 w-full max-w-2xl max-h-[85vh] flex flex-col">
              <div className="flex justify-between items-center mb-5">
                <h3 className="text-xl font-bold text-emerald-400 flex items-center gap-2">
                  <TableProperties size={22} /> Truth Table Verification
                </h3>
                <button 
                  onClick={() => setShowTruthTable(false)} 
                  className="text-slate-400 hover:text-white p-2 bg-slate-800 rounded-full transition-colors cursor-pointer"
                >
                  <X size={20}/>
                </button>
              </div>

              <div className="text-xs text-slate-400 mb-3 flex items-center justify-between">
                <span>Equation: <strong className="text-cyan-400 font-mono">{equation}</strong></span>
                <span>Combinations: <strong className="text-slate-200">{Math.pow(2, nodes.filter(n => n.type === 'INPUT').length)} states</strong></span>
              </div>
              
              <div className="flex-1 overflow-auto custom-scrollbar border border-slate-700 rounded-xl">
                <table className="w-full text-center text-sm">
                  <thead className="bg-slate-800 sticky top-0 text-slate-200">
                    <tr>
                      {generateTruthTable()?.inputs.map(h => (
                        <th key={h} className="p-3 border-b border-slate-700 font-mono font-bold text-cyan-300">
                          {h}
                        </th>
                      ))}
                      <th className="p-3 border-b border-slate-700 border-l border-slate-600/50 bg-slate-800/90 font-mono font-bold text-emerald-400">
                        Output (Y)
                      </th>
                    </tr>
                  </thead>
                  <tbody>
                    {generateTruthTable()?.rows.map((row, i) => (
                      <tr key={i} className="border-b border-slate-800/60 hover:bg-slate-800/40 text-slate-300 font-mono">
                        {generateTruthTable()?.inputs.map(h => (
                          <td key={h} className="p-2.5">
                            <span className={row[h] === 1 ? 'text-emerald-400 font-bold' : 'text-slate-500'}>
                              {row[h]}
                            </span>
                          </td>
                        ))}
                        <td className="p-2.5 border-l border-slate-700 font-bold bg-emerald-950/20">
                          <span className={`px-2 py-0.5 rounded ${
                            generateTruthTable()?.outputs.map(o => row[o])[0] === 1
                              ? 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/30'
                              : 'bg-slate-800 text-slate-500'
                          }`}>
                            {generateTruthTable()?.outputs.map(o => row[o]).join(', ')}
                          </span>
                        </td>
                      </tr>
                    )) || (
                      <tr>
                        <td colSpan={10} className="p-8 text-slate-500 text-center">
                          No complete circuit detected. Add at least one Input and one Output node to generate the truth table.
                        </td>
                      </tr>
                    )}
                  </tbody>
                </table>
              </div>

              <div className="mt-5 flex justify-end">
                <button 
                  onClick={() => setShowTruthTable(false)}
                  className="bg-slate-800 hover:bg-slate-700 text-slate-200 px-5 py-2 rounded-lg font-bold text-sm transition-colors cursor-pointer"
                >
                  Close
                </button>
              </div>
            </div>
          </div>
        )}
      </div>

      {/* Embedded J.A.R.V.I.S. Copilot Panel */}
      <div className="w-80 bg-slate-900/95 border border-slate-800 rounded-2xl flex flex-col shadow-2xl shrink-0 z-20 overflow-hidden backdrop-blur-md">
        <div className="p-4 border-b border-slate-800 bg-slate-950 flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="bg-purple-600/20 p-2 rounded-xl border border-purple-500/30">
              <Bot className="text-purple-400" size={19}/>
            </div>
            <div>
              <h3 className="font-bold text-white text-sm leading-tight font-mono">J.A.R.V.I.S.</h3>
              <p className="text-[11px] text-emerald-400 flex items-center gap-1 font-mono">
                <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse"></span> Telemetry Active
              </p>
            </div>
          </div>
        </div>

        {/* Message Log */}
        <div className="flex-1 p-3.5 flex flex-col gap-3 overflow-y-auto text-sm text-slate-300 custom-scrollbar">
          <div className="bg-slate-800/80 p-3 rounded-lg border border-slate-700">
            <div className="text-[11px] uppercase tracking-wider text-slate-400 font-bold mb-1">Live Expression</div>
            <code className="text-cyan-400 font-mono block bg-slate-950 p-2 rounded text-xs break-all border border-slate-800">
              {equation || "No active equation"}
            </code>
          </div>

          {messages.map(m => (
            <div 
              key={m.id} 
              className={`p-3 rounded-xl text-xs leading-relaxed ${
                m.sender === 'user' 
                  ? 'bg-blue-600 text-white ml-4 rounded-tr-none' 
                  : 'bg-slate-800 border border-slate-700/80 mr-2 rounded-tl-none text-slate-200 font-sans'
              }`}
            >
              <div className="whitespace-pre-wrap">{m.text}</div>
            </div>
          ))}

          {isAiThinking && (
            <div className="bg-slate-800 border border-slate-700/80 p-3 rounded-xl rounded-tl-none mr-2 text-xs flex items-center gap-2 text-slate-400">
              <RefreshCw size={13} className="animate-spin text-cyan-400" /> J.A.R.V.I.S. is calculating...
            </div>
          )}

          {/* Quick Prompts */}
          <div className="space-y-2 mt-auto pt-2 border-t border-slate-800">
            <p className="text-[10px] text-slate-500 font-bold uppercase tracking-wider">Quick Directives:</p>
            <button 
              onClick={() => handleSendPrompt("Generate K-Map for this equation")}
              className="w-full text-left bg-slate-800/90 hover:bg-slate-700 p-2 rounded-lg text-xs text-slate-300 transition-colors border border-slate-700 flex items-center gap-2 cursor-pointer"
            >
              <Wand2 size={13} className="text-cyan-400 shrink-0"/> Generate K-Map Matrix
            </button>
            <button 
              onClick={() => handleSendPrompt("Explain this logic circuit architecture")}
              className="w-full text-left bg-slate-800/90 hover:bg-slate-700 p-2 rounded-lg text-xs text-slate-300 transition-colors border border-slate-700 flex items-center gap-2 cursor-pointer"
            >
              <BrainCircuit size={13} className="text-emerald-400 shrink-0"/> Explain Circuit Architecture
            </button>
            <button 
              onClick={() => handleSendPrompt("Simplify equation using Boolean laws")}
              className="w-full text-left bg-slate-800/90 hover:bg-slate-700 p-2 rounded-lg text-xs text-slate-300 transition-colors border border-slate-700 flex items-center gap-2 cursor-pointer"
            >
              <Sparkles size={13} className="text-amber-400 shrink-0"/> Minimize via De Morgan
            </button>
          </div>
        </div>

        {/* Chat Input */}
        <div className="p-3 border-t border-slate-800 bg-slate-950">
          <form 
            onSubmit={(e) => { e.preventDefault(); handleSendPrompt(); }}
            className="flex gap-2"
          >
            <input 
              type="text" 
              value={chatInput}
              onChange={(e) => setChatInput(e.target.value)}
              placeholder="Ask J.A.R.V.I.S..." 
              className="flex-1 bg-slate-900 border border-slate-700 rounded-lg px-3 py-2 text-xs focus:border-cyan-500 focus:outline-none text-slate-200 placeholder-slate-500" 
            />
            <button 
              type="submit" 
              className="bg-cyan-600 hover:bg-cyan-500 active:scale-95 text-white p-2 rounded-lg transition-all cursor-pointer"
              title="Send to J.A.R.V.I.S."
            >
              <Send size={14}/>
            </button>
          </form>
        </div>
      </div>
    </div>
  );
};

// --- STUDENT PROFILE VIEW ---
const ProfileView: React.FC<{ 
  user: FirebaseUser | null;
  quizHighScore: number;
  onNavigateToQuiz: () => void;
}> = ({ user, quizHighScore, onNavigateToQuiz }) => {
  return (
    <div className="max-w-4xl mx-auto w-full h-full overflow-y-auto custom-scrollbar pb-16 relative z-10">
      <div className="bg-slate-900/90 border border-slate-800 rounded-3xl p-8 shadow-2xl mb-6 backdrop-blur-md">
        <div className="flex flex-col sm:flex-row items-start sm:items-center gap-6">
          <div className="w-20 h-20 rounded-2xl bg-gradient-to-tr from-cyan-600 via-blue-600 to-purple-600 flex items-center justify-center text-white shadow-xl border-2 border-cyan-400/40">
            <User size={38} />
          </div>
          <div>
            <div className="flex flex-wrap items-center gap-3">
              <h2 className="text-2xl font-bold text-white">ENTC Lab Student</h2>
              <span className="bg-emerald-950/80 border border-emerald-500/40 text-emerald-400 text-xs px-3 py-0.5 rounded-full font-semibold flex items-center gap-1">
                <CheckCircle2 size={13} /> Active Session
              </span>
            </div>
            <p className="text-slate-400 text-xs mt-1.5 font-mono">
              UID: {user?.uid || 'cadet-entc-session-active'} &bull; Dept: Electronics & Telecommunication Engineering
            </p>
          </div>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-4 gap-4 mt-8">
          <div className="bg-slate-950 p-4 rounded-2xl border border-slate-800">
            <span className="text-xs text-slate-500 uppercase tracking-wider font-semibold">Circuits Built</span>
            <div className="text-2xl font-mono font-bold text-cyan-400 mt-1">14</div>
          </div>
          <div className="bg-slate-950 p-4 rounded-2xl border border-slate-800">
            <span className="text-xs text-slate-500 uppercase tracking-wider font-semibold">Truth Tables Run</span>
            <div className="text-2xl font-mono font-bold text-emerald-400 mt-1">32</div>
          </div>
          <div className="bg-slate-950 p-4 rounded-2xl border border-slate-800">
            <span className="text-xs text-slate-500 uppercase tracking-wider font-semibold">Syllabus Progress</span>
            <div className="text-2xl font-mono font-bold text-purple-400 mt-1">100%</div>
          </div>
          <div className="bg-slate-950 p-4 rounded-2xl border border-slate-800">
            <span className="text-xs text-slate-500 uppercase tracking-wider font-semibold">Quiz High Score</span>
            <div className="text-2xl font-mono font-bold text-amber-400 mt-1 flex items-center gap-1">
              {quizHighScore > 0 ? `+${quizHighScore}` : quizHighScore} pts
            </div>
          </div>
        </div>
      </div>

      {/* Badges */}
      <div className="bg-slate-900/90 border border-slate-800 rounded-3xl p-6 sm:p-8 shadow-2xl backdrop-blur-md mb-6">
        <h3 className="text-lg font-bold text-white mb-4 flex items-center gap-2">
          <Award className="text-amber-400" size={20} />
          Earned Skill Badges & Certifications
        </h3>
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
          <div className="flex items-center gap-3 bg-slate-950 p-3.5 rounded-xl border border-slate-800">
            <div className="w-10 h-10 rounded-lg bg-emerald-500/10 border border-emerald-500/20 flex items-center justify-center text-emerald-400">
              <ShieldCheck size={20} />
            </div>
            <div>
              <div className="text-xs font-bold text-slate-200">AST Boolean Parser</div>
              <div className="text-[10px] text-slate-500">Constructed postfix AST trees</div>
            </div>
          </div>

          <div className="flex items-center gap-3 bg-slate-950 p-3.5 rounded-xl border border-slate-800">
            <div className="w-10 h-10 rounded-lg bg-cyan-500/10 border border-cyan-500/20 flex items-center justify-center text-cyan-400">
              <Zap size={20} />
            </div>
            <div>
              <div className="text-xs font-bold text-slate-200">Wiring Mastery</div>
              <div className="text-[10px] text-slate-500">Connected 10+ Bezier signal traces</div>
            </div>
          </div>

          <div className="flex items-center gap-3 bg-slate-950 p-3.5 rounded-xl border border-slate-800">
            <div className="w-10 h-10 rounded-lg bg-purple-500/10 border border-purple-500/20 flex items-center justify-center text-purple-400">
              <Bot size={20} />
            </div>
            <div>
              <div className="text-xs font-bold text-slate-200">J.A.R.V.I.S. Copilot</div>
              <div className="text-[10px] text-slate-500">Authorized telemetry link</div>
            </div>
          </div>
        </div>
      </div>

      {/* Quiz Promotion */}
      <div className="bg-gradient-to-r from-amber-950/40 via-slate-900 to-slate-950 border border-amber-500/30 rounded-3xl p-6 flex items-center justify-between gap-4">
        <div>
          <div className="text-xs text-amber-400 font-mono font-bold uppercase tracking-wider">
            10-Question Arena Game
          </div>
          <h4 className="text-base font-bold text-white mt-0.5">
            Ready to test your speed & precision under the +1 / -2 scoring rule?
          </h4>
        </div>
        <button
          onClick={onNavigateToQuiz}
          className="bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold px-5 py-2.5 rounded-xl text-xs transition-all shadow-lg shadow-amber-500/20 cursor-pointer shrink-0"
        >
          Play Quiz Challenge &rarr;
        </button>
      </div>
    </div>
  );
};

// --- INITIAL SEED LEADERBOARD DATA ---
const INITIAL_LEADERBOARD: LeaderboardRecord[] = [
  {
    id: 'rec_1',
    name: 'Aarav Sharma (ENTC)',
    score: 10,
    totalQuestions: 10,
    correctCount: 10,
    wrongCount: 0,
    timeSpentSec: 42,
    difficulty: 'hard',
    durationLimitMin: 1,
    timestamp: Date.now() - 3600000,
    avatarSeed: 'seed1'
  },
  {
    id: 'rec_2',
    name: 'Priya Deshmukh (NIT)',
    score: 9,
    totalQuestions: 10,
    correctCount: 9,
    wrongCount: 0,
    timeSpentSec: 51,
    difficulty: 'hard',
    durationLimitMin: 1,
    timestamp: Date.now() - 7200000,
    avatarSeed: 'seed2'
  },
  {
    id: 'rec_3',
    name: 'Rohan Patel (COEP)',
    score: 7,
    totalQuestions: 10,
    correctCount: 9,
    wrongCount: 1,
    timeSpentSec: 28,
    difficulty: 'easy',
    durationLimitMin: 1,
    timestamp: Date.now() - 10800000,
    avatarSeed: 'seed3'
  },
  {
    id: 'rec_4',
    name: 'Sneha Kulkarni',
    score: 8,
    totalQuestions: 10,
    correctCount: 8,
    wrongCount: 0,
    timeSpentSec: 320,
    difficulty: 'hard',
    durationLimitMin: 10,
    timestamp: Date.now() - 14400000,
    avatarSeed: 'seed4'
  },
  {
    id: 'rec_5',
    name: 'Vikramaditya Roy',
    score: 6,
    totalQuestions: 10,
    correctCount: 8,
    wrongCount: 1,
    timeSpentSec: 45,
    difficulty: 'easy',
    durationLimitMin: 1,
    timestamp: Date.now() - 18000000,
    avatarSeed: 'seed5'
  }
];

// --- MAIN APP WRAPPER ---
export default function App() {
  const [user, setUser] = useState<FirebaseUser | null>(null);
  
  // Default to 'home' view as requested: "there is no home page for the site give where i can chose in between those options..."
  const [currentView, setCurrentView] = useState<ViewType>('home');
  const [presetEquation, setPresetEquation] = useState<string | null>(null);

  // Modals for Flashcards & Chapter Quizzes
  const [activeFlashcardChapterId, setActiveFlashcardChapterId] = useState<string | null>(null);
  const [activeQuizChapterId, setActiveQuizChapterId] = useState<string | null>(null);

  // Leaderboard Records stored locally + memory
  const [leaderboardRecords, setLeaderboardRecords] = useState<LeaderboardRecord[]>(() => {
    try {
      const saved = localStorage.getItem('entc_leaderboard');
      if (saved) return JSON.parse(saved);
    } catch {
      // Ignored
    }
    return INITIAL_LEADERBOARD;
  });

  const quizHighScore = Math.max(0, ...leaderboardRecords.map(r => r.score));

  useEffect(() => {
    if (!auth) return;
    const initAuth = async () => {
      try {
        if (typeof __initial_auth_token !== 'undefined' && __initial_auth_token) {
          await signInWithCustomToken(auth, __initial_auth_token);
        } else {
          await signInAnonymously(auth);
        }
      } catch (err) { 
        console.warn("Auth initialization note:", err); 
      }
    };
    initAuth();
    const unsub = onAuthStateChanged(auth, setUser);
    return () => unsub();
  }, []);

  const handleSaveToLeaderboard = (record: Omit<LeaderboardRecord, 'id' | 'timestamp'>) => {
    const newRecord: LeaderboardRecord = {
      ...record,
      id: `rec_${Date.now()}`,
      timestamp: Date.now()
    };
    setLeaderboardRecords(prev => {
      const updated = [newRecord, ...prev];
      try {
        localStorage.setItem('entc_leaderboard', JSON.stringify(updated));
      } catch {
        // Ignored
      }
      return updated;
    });
  };

  const activeFlashcardChapter = CHAPTERS_DATA.find(c => c.id === activeFlashcardChapterId);
  const activeQuizChapter = CHAPTERS_DATA.find(c => c.id === activeQuizChapterId);

  return (
    <div className="h-screen w-full bg-slate-950 text-slate-200 font-sans flex flex-col overflow-hidden relative">
      {/* Dynamic Moving Circuit Background */}
      <MovingBackground intensity={currentView === 'home' ? 'vibrant' : 'subtle'} />

      {/* Top Navigation Bar with Menu Button */}
      <Navbar 
        currentView={currentView}
        onNavigate={(view) => setCurrentView(view)}
        quizHighScore={quizHighScore}
      />

      {/* Main Content Area */}
      <main className="flex-1 relative p-3 sm:p-6 h-[calc(100vh-4rem)] overflow-hidden flex flex-col">
        {currentView === 'home' && (
          <HomeView 
            onNavigate={(view) => setCurrentView(view)}
            onLoadPreset={(eq) => setPresetEquation(eq)}
            onOpenChapterFlashcards={(id) => setActiveFlashcardChapterId(id)}
            onOpenChapterQuiz={(id) => setActiveQuizChapterId(id)}
            quizHighScore={quizHighScore}
          />
        )}

        {currentView === 'simulator' && (
          <AdvancedLogicSimulator 
            user={user} 
            presetEquation={presetEquation}
            onClearPreset={() => setPresetEquation(null)}
          />
        )}
        
        {currentView === 'modules' && (
          <ModulesView 
            onLoadPreset={(eq) => setPresetEquation(eq)}
            onNavigateToSimulator={() => setCurrentView('simulator')}
            onOpenFlashcards={(id) => setActiveFlashcardChapterId(id)}
            onOpenQuiz={(id) => setActiveQuizChapterId(id)}
          />
        )}

        {currentView === 'jarvis' && (
          <JarvisView 
            onLoadEquationToSimulator={(eq) => setPresetEquation(eq)}
            onNavigateToSimulator={() => setCurrentView('simulator')}
          />
        )}

        {currentView === 'quiz' && (
          <QuizArena 
            onSaveToLeaderboard={handleSaveToLeaderboard}
            onNavigateToLeaderboard={() => setCurrentView('leaderboard')}
          />
        )}

        {currentView === 'leaderboard' && (
          <LeaderboardView 
            records={leaderboardRecords}
            onStartQuiz={() => setCurrentView('quiz')}
          />
        )}

        {currentView === 'profile' && (
          <ProfileView 
            user={user} 
            quizHighScore={quizHighScore}
            onNavigateToQuiz={() => setCurrentView('quiz')}
          />
        )}
      </main>

      {/* Interactive Flashcards Modal */}
      {activeFlashcardChapter && (
        <ChapterFlashcardsModal 
          chapterTitle={activeFlashcardChapter.title}
          flashcards={activeFlashcardChapter.flashcards}
          onClose={() => setActiveFlashcardChapterId(null)}
        />
      )}

      {/* Interactive Chapter Quiz Modal */}
      {activeQuizChapter && (
        <ChapterQuizModal 
          chapterTitle={activeQuizChapter.title}
          chapterNumber={activeQuizChapter.number}
          questions={activeQuizChapter.quiz}
          onClose={() => setActiveQuizChapterId(null)}
        />
      )}
    </div>
  );
}
